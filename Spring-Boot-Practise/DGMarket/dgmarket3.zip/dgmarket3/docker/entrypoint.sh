#!/bin/sh
java  -jar  $JAVA_OPTS  /opt/dashspring.jar
