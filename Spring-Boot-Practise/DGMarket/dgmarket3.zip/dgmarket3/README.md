# dgmarket3


#Git commands for developer reference


#for checkout branch 
git checkout  branch_name

#Start new task 
1. got to develop branch
2. Pull the lattest code from develop

#for pull lattest code from develop
git pull origin develop

#for creation new branch and checkout to the branch

git checkout  -b taskid_task_title

#After the task done 

1. add you code to your branch ---> git add .

2. commit the changes ---> git commit -m'your message'

3. sync your code from develop--> git pull origin develop

4. push your branch to remote--> git push origin your_branch_name

#Merge request
start title with #issueid(eg #Registration form changes)