

alter table dg_faq add column faq_type varchar(20)  not null;