create table notices(
notice_id     serial      not null
        constraint notices_pk
            primary key,
notice_no varchar(100),
notice_type varchar(5)   not null
	constraint notices_notice_types_fk
            references notice_types,
notice_title  varchar(160),
main_language  varchar(5) not null,
performance_country  varchar(5) not null,
city  varchar(60),
est_amount  BIGINT null default null,
currency  varchar(5),
end_date  timestamp null default null,
procurement_method  integer         not null
        constraint notices_procurement_methods_fk
            references procurement_methods,
qualification text null default null,
notice_deadline  timestamp null default null,		   
publish_date  timestamp null default null,
notice_source  varchar(10),     						----------  external/internal
creator_id     integer  not null,                    ----------  if external it will be superadmin id, if internaly added then userid	
is_publish_on_sibutu boolean not null default false 	
);


create table notice_fundings(
id          serial      not null
        constraint notice_fundings_pk
            primary key,
notice_id  integer  not null
		constraint notice_fundings_notice_id_fk
            references notices,
funding_agency integer not null
		constraint notice_fundings_funding_agencies_fk
            references funding_agencies
);


create table notice_contacts(
id          serial      not null
        constraint notice_contacts_pk
            primary key, 
org_id    integer  not null 
		constraint notice_contacts_organization_id_fk
            references organizations,
notice_id  integer  not null
		constraint notice_contacts_notice_id_fk
            references notices,
title   varchar(10),
first_name  varchar(150) not null,
last_name   varchar(150),
address     varchar(150),
city        varchar(40),
state       varchar(40),
postal_code varchar(20),
country varchar(5),
phone varchar(15),
fax varchar(15),
email varchar(150),
website varchar(150)
);

create table notice_detail(
id          serial      not null
        constraint notice_detail_pk
            primary key, 
notice_id  integer  not null
		constraint notice_detail_notice_id_fk
            references notices,
official_text   text,
external_url    varchar(150)
);


create table notice_documents(
id          serial      not null
        constraint notice_documents_pk
            primary key, 
notice_id  integer  not null
		constraint notice_documents_notice_id_fk
            references notices,
file_type   varchar(60),
file_name   varchar(160),
file_description   varchar(160),
file_size   bigint,
external_url    varchar(150),
created_time timestamp default now() not null
);

create table notice_cpv_mapping(
id          serial      not null
        constraint notice_cpv_mapping_pk
            primary key, 
notice_id  integer  not null
		constraint notice_cpv_mapping_notice_id_fk
            references notices,
cpv_code  varchar(8) not null 
		constraint notice_cpv_mapping_cpv_code_fk
            references cpv_master
);



