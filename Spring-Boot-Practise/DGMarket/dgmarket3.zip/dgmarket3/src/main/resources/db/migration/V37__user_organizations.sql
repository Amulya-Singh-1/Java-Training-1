create table user_organizations
(
    id           serial                 not null
        constraint user_organizations_pk
            primary key,
    user_id      integer                 not null
        constraint user_organizations_user_id_fk
            references users,
	org_id    	integer     not null
			constraint user_organizations_org_id_fk
			references organizations,
    created_time timestamp default now() not null
);