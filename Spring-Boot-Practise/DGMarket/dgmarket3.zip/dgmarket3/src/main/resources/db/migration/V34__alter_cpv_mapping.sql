ALTER TABLE notice_cpv_mapping
	ADD column is_primary boolean DEFAULT false;