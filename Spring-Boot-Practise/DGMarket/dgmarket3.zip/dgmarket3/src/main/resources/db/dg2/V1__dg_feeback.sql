CREATE TABLE dg_feedback
(
    id bigint NOT NULL,
    name character varying(255) COLLATE pg_catalog."default",
    email character varying(255) COLLATE pg_catalog."default",
    category character varying(255) COLLATE pg_catalog."default",
    sub_category character varying(255) COLLATE pg_catalog."default",
    message character varying(255) COLLATE pg_catalog."default",
    CONSTRAINT dg_feedback_pkey PRIMARY KEY (id)
);