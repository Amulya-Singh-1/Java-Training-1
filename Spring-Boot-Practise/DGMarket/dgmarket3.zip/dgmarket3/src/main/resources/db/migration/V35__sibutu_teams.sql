create table sibutu_team(
id          serial      not null
        constraint notice_team_pk
            primary key,
notice_id  integer  not null
		constraint notice_team_notice_id_fk
            references notices,
user_id integer not null
		constraint notice_team_user_id_fk
            references users,
role    varchar(16)  	not null
);