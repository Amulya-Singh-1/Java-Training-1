alter table users add column registration_source varchar(60) null default null;

create table user_reset_password (
	id            serial       not null
    constraint user_reset_password_pk
            primary key,
	user_id     integer         not null,
	reset_date timestamp null default null,
	code varchar(60) null default null
);


CREATE TABLE categories(
	id            serial       not null
    constraint categories_pk
            primary key,
	category_name varchar(100) NULL DEFAULT NULL,
	category_code varchar(20) unique NULL DEFAULT NULL
);


CREATE TABLE regions (
	id            serial       not null
    constraint regions_pk
            primary key,
	region_code varchar(5) NOT NULL,
	name varchar(50) NOT NULL,
	countries varchar(300) NOT NULL
);


CREATE TABLE cpv_to_category (
	id            serial       not null
    constraint cpv_to_category_pk
            primary key,
	cpv_code VARCHAR(8) NOT NULL,
	category_code VARCHAR(20) NOT NULL
);