create table notice_downloads (
	id           serial        not null
        constraint notice_downloads_pk
            primary key,
	user_id      integer                 not null
        constraint notice_downloads_users_id_fk
            references users,
	notice_id  integer  not null
		constraint notice_downloads_notice_id_fk
            references notices,
	seen_time timestamp null default 'now()'
);