alter table cpv_master
drop constraint cpv_master_cpv_master_code_fk;


update cpv_master set parent_code=NULL where code in(SELECT code FROM cpv_master WHERE parent_code = code);

