ALTER TABLE award_informations
	ADD column status SMALLINT NULL DEFAULT 1;
