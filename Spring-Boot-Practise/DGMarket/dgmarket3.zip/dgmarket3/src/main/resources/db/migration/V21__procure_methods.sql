create table procurement_methods (
	method_id    serial      not null
        constraint procure_methods_pk
            primary key,
	method_name VARCHAR(100) not null
);

INSERT INTO procurement_methods (method_name) VALUES
	('International Competitive Bidding (ICB)'),
	('National Competitive Bidding'),
	('Other');
