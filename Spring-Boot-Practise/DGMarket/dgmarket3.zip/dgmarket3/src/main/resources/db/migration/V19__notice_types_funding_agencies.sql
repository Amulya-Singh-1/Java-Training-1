create table funding_agencies (
	agency_id BIGINT not null,
	short_name varchar(20),
	name varchar(100),
	primary key (agency_id)
)

INSERT INTO funding_agencies (agency_id, short_name, name) VALUES
	(509, 'IBRD', 'International Bank for Reconstruction and Development'),
	(541, 'IDA', 'International Development Association'),
	(1081, 'NADB', 'North American Development Bank'),
	(493, 'IDB', 'Interamerican Development Bank'),
	(46, 'AfDF', 'African Development Bank'),
	(330, 'EBRD', 'European Bank for Reconstruction and Development'),
	(44, 'AfDB', 'African Development Bank'),
	(1101, 'ADF', 'Asian Development Fund'),
	(106, 'ADB', 'Asian Development Bank'),
	(267, 'CDB', 'Caribbean Development Bank'),
	(1121, 'PHARE, TACIS, ISPA', 'PHARE, TACIS, ISPA and countries of Central and Eastern Europe'),
	(1122, 'EuropeAID', 'EuropeAID'),
	(348, 'EIB', 'European Investment Bank'),
	(1141, 'GEF', 'Global Environment Facility'),
	(0, 'Other', 'Other');



CREATE TABLE notice_types (
	code varchar(5) not null,
	name varchar(100),
	PRIMARY KEY (code)
);

INSERT INTO notice_types (code,name) VALUES
	('ca', 'Contract Award'),
	('spn', 'Invitation for Bids'),
	('ppn', 'Invitation for Prequalification'),
	('rei', 'Invitation for Expressions of Interest'),
	('gpn', 'General Procurement Notice'),
	('other', 'Other'),
	('acn', 'Auction'),
	('rfc', 'Request for Public Consultations'),
	('prj', 'Project'),
	('pp', 'Procurment Plan');

