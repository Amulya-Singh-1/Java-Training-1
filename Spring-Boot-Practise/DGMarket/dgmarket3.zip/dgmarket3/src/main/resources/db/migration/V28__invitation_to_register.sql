create table invitation_to_register (
	id    serial      not null
        constraint invitation_to_register_pk
            primary key,
	inviter_id integer                 not null
        constraint invitation_to_register_inviter_id_fk
            references users,		
	invitee_email   varchar(100)     not null,
	confirmation_code   varchar(100)     not null,
	role_id    	integer     not null
			constraint invitation_to_register_role_id_roles_master_id_fk
			references roles_master,
	org_id    	integer     not null
			constraint invitation_to_register_org_id_fk
			references organizations,
	created_time timestamp default now() not null
);

