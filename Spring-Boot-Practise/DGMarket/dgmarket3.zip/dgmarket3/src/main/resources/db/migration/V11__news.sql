CREATE TABLE news (
	id            serial       not null
    constraint news_pk
            primary key,
	headline VARCHAR(100) NOT NULL,
	text TEXT NOT NULL,
	create_date TIMESTAMP NULL DEFAULT NULL,
	source VARCHAR(100) NULL DEFAULT NULL,
	news_type VARCHAR(30) NULL DEFAULT 'procurement',
	country_iso VARCHAR(10) NULL DEFAULT NULL
);

INSERT INTO news (id, headline, text, create_date, source, news_type, country_iso) VALUES
	(51005, 'hello news 3', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh. The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh. The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-03 22:49:07.212', '', 'procurement', 'iq'),
	(52004, 'Headline no hello5', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.
The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-02 23:05:47.505', '', 'procurement', 'kp'),
	(1060, 'COMORES - Ministère de la Santé', 'COMORES - Ministère de la Santé', '2018-11-14 14:42:32.996', '', 'procurement', 'in'),
	(50000, 'hello news 1', 'This is samples eee', '2018-10-05 22:48:08.838', '', 'procurement', 'jp'),
	(51000, 'hello news 2', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-05 22:49:07.212', '', 'procurement', 'iq'),
	(52000, 'Headline no hello4', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-05 23:05:47.505', '', 'procurement', 'kp'),
	(51001, 'hello3 news form procurement department', 'hello world hello world hello world', '2018-10-05 22:54:00.543', '', 'procurement', 'in'),
	(51006, 'hello news 4', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-05 22:49:07.212', '', 'procurement', 'iq'),
	(51007, 'hello news 5', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-05 22:49:07.212', '', 'procurement', 'iq'),
	(51008, 'hello news 6', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-05 22:49:07.212', '', 'procurement', 'iq'),
	(51009, 'hello news 7', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-05 22:49:07.212', '', 'procurement', 'iq'),
	(51002, 'hello4 news form procurement department', 'hello world hello world hello world', '2018-10-05 22:54:00.543', '', 'procurement', 'in'),
	(52005, 'Headline no hello6', 'The European Commission is today delivering on its pledge to contribute an additional €10 million in humanitarian aid, including some very early recovery to help civilians affected by the recent conflict in and around Nagorno Karabakh.', '2018-10-04 23:05:47.505', '', 'procurement', 'kp');

