alter table notices 
add notice_status varchar(20);