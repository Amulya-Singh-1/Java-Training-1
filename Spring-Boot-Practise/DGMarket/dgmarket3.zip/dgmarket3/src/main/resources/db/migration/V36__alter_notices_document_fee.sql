ALTER TABLE notices 
	ADD column document_fee varchar(20) null default null,
	ADD column completed_steps varchar(20) null default null;
	