ALTER TABLE organizations_draft
    ADD CONSTRAINT fk_organizations_draft FOREIGN KEY (user_id) REFERENCES users(id);




create table user_preferences
(
    id           serial                 not null
        constraint user_preferences_pk
            primary key,
    user_id      integer                 not null
        constraint user_preferences_users_id_fk
            references users,
	user_data_key   varchar(100)  not null,
	
	user_data_value   text  not null  
);