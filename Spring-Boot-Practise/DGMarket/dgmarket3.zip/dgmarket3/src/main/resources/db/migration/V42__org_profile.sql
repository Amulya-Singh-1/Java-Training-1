create table organization_profile (
	id           serial        not null
        constraint organization_profile_pk
            primary key,
	org_id    integer  not null 
		constraint organization_profile_organization_id_fk
            references organizations,
	org_acronym varchar(250) null default null,
	establishment_year  date null default null,
	org_size bigint null default null,
	annual_ternover bigint null default null,
	org_logo  varchar(120) null default null,
	other_staff varchar(40) null default null
);