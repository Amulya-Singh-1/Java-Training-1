create table faq (
	id           serial        not null
        constraint faq_pk
		primary key,
	name varchar(100) not null,
	description varchar(120) null default null,
	org_id    	integer, 
	active boolean not null default true,
	created_time timestamp default now() not null
);


create table faq_items (
	id           serial        not null
        constraint faq_items_pk
		primary key,
	faq_id  integer            not null
        constraint faq_items_faq_id_fk
            references faq,
	question varchar(160) not null,
	answer   text  not null,
	active boolean not null default true,
	created_time timestamp default now() not null
);