CREATE TABLE email_logs (
	id            serial       not null
    constraint email_logs_pk
            primary key,
	recipient VARCHAR(100) NOT NULL,
	subject VARCHAR(100) NULL DEFAULT NULL,
	time_sent TIMESTAMP NULL DEFAULT NULL,
	channel VARCHAR(20) NULL DEFAULT NULL,
	message_id VARCHAR(10) NULL DEFAULT NULL,
	body TEXT NULL DEFAULT NULL,
	email_type VARCHAR(20) NULL DEFAULT NULL
);
CREATE INDEX idx_email_logs_recipient 
ON email_logs(recipient);
CREATE INDEX idx_email_logs_subject 
ON email_logs(subject);
CREATE INDEX idx_email_logs_time_sent 
ON email_logs(time_sent);

CREATE TABLE feedback (
	id            serial       not null
    constraint feedback_pk
            primary key,
	name VARCHAR(100) NULL DEFAULT NULL,
	email VARCHAR(100) NULL DEFAULT NULL,
	category VARCHAR(30) NULL DEFAULT NULL,
	sub_category VARCHAR(30) NULL DEFAULT NULL,
	message VARCHAR(255) NULL DEFAULT NULL
);