
alter table ep_news
    add country_iso   varchar(10)    null,
    add constraint ep_news_dg_countries_iso_fk
        foreign key (country_iso) references dg_countries;