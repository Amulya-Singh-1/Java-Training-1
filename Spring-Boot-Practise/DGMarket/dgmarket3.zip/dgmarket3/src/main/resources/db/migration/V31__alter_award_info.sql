alter table award_informations 
	add org_id  integer  not null default 1
		constraint award_informations_org_id_fk
            references organizations;