ALTER TABLE organizations
	ALTER COLUMN org_description TYPE VARCHAR(255),
	ALTER COLUMN org_description SET DEFAULT NULL;
