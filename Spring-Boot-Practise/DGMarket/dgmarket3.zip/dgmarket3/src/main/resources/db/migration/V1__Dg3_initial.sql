/*
database name - dg3web
user - dgmarket
pass- dgmarket
*/
create table org_types_master
(
    id           serial        not null
        constraint organization_type_pk
            primary key,
    name         varchar(100) not null
);

/*
insert
*/
INSERT INTO org_types_master (name) VALUES ('Government'),('Public Company'),('Private Company'),('Public Sector Undertaking'),('NGO'),('LLP'),('Corporation');

create table organizations
(
    org_id            serial       not null
        constraint organizations_pk
            primary key,
    org_type          integer
		constraint org_types_master_organizations_id_fk
            references org_types_master,    				---organization type table that is list of org type
    org_name          varchar(80) not null,
	org_description         varchar(80),
	org_email         varchar(80),
	org_reference_no         varchar(80),
    org_address       varchar(120),
    org_state         varchar(100),
    org_country  varchar(3),                   -- foreign key
	org_language  varchar(4),                      --- foreign key
	org_phone        varchar(15),
	org_fax        varchar(15),
	org_website        varchar(30),
	org_parent_id   integer default 0,                     ---organization child mapping  would be index
	org_creator_id   integer, 					---userid 
    org_status        integer,      ---- 1=> approved, 2=>rejected, 3=>suspended
	created_time timestamp default now() not null	
    
);

create table roles_master
(
    id           serial                 not null
        constraint roles_master_pk
            primary key,
	name   varchar(30)                not null,
  
	active boolean default true not null
);


create table users
(
    id             serial        not null
        constraint users_pk
            primary key,
    email              varchar(150)            not null,
    password           varchar(250)            not null,
    first_name          varchar(150)            not null,
	last_name          varchar(150)            not null,
    mobile             varchar(20),
    organization_id    integer
        constraint users_organizations_id_fk
            references organizations,
    created_time       timestamp default now() not null,
    last_modified_time timestamp default now() not null,
    active             boolean                 not null
);


create table user_roles
(
    id           serial                 not null
        constraint user_roles_pk
            primary key,
    user_id      integer                 not null
        constraint user_roles_users_id_fk
            references users,
	role_id    	integer     not null
			constraint user_roles_role_id_roles_master_id_fk
			references roles_master,
			
	org_id    	integer     not null
			constraint user_roles_organizations_id_fk
			references organizations,
    created_time timestamp default now() not null
);
