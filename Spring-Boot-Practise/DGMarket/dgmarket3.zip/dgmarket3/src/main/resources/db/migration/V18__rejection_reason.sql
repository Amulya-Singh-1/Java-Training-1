create table org_rejection_detail
(
    id           serial        not null
        constraint org_rejection_detail_pk
            primary key,
    reason         varchar(200) not null,
	org_id         integer
        constraint org_rejection_detail_org_draft_id_fk
            references organizations_draft,
	rejected_by    integer      not null
        constraint org_rejection_detail_users_id_fk
            references users,
	created_time timestamp default now() not null
);