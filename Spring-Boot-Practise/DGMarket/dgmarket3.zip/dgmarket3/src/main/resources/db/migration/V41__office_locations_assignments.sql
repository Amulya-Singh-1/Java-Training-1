create table office_locations (
	id           serial        not null
        constraint office_locations_pk
            primary key,
	name varchar(250) not null,
	type varchar(40) null default null,
	org_id  integer not null,
	country varchar(5) 
	constraint office_locations_country_iso_fk
			references countries,
	pincode varchar(10) null default null,
	city varchar(40) null default null,
	state varchar(40) null default null,
	flat_no varchar(40) null default null,
	locality varchar(40) null default null,
	contact_number varchar(20) null default null,
	email varchar(60) null default null
);


create table assignments (
	id           serial        not null
        constraint assignments_pk
            primary key,
	org_id  integer not null,
	assignment_title varchar(250) not null,
	project_title varchar(250) not null,
	contract_number varchar(20) null default null,
	country varchar(5) 
	constraint office_locations_country_iso_fk
			references countries,
	client_name varchar(40) null default null,
	start_date DATE null default null,
	end_date DATE null default null,
	staff_months varchar(40) null default null,
	contract_value varchar(20) null default null,
	funding_agency varchar(5) null default null,
	description text null default null
);