ALTER TABLE organizations_draft
ADD CONSTRAINT org_name_unique UNIQUE(org_name);


ALTER TABLE organizations
ADD CONSTRAINT org_name_organizations_unique UNIQUE(org_name);