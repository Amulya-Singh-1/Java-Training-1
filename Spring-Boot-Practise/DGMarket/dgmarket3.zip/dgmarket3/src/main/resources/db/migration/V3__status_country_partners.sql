create table org_status_master
(
    id           serial                 not null
        constraint org_status_master_pk
            primary key,
	name   varchar(30)                not null,
	code varchar(5) UNIQUE
  
);

INSERT INTO org_status_master (name,code) VALUES ('Waiting for Approval','0'),('Approved','1'),('Rejected','2'),('Suspended','3');

CREATE TABLE countries (
	iso VARCHAR(5) NOT NULL,
	country_name VARCHAR(100) NULL DEFAULT NULL,
	message_lang_key VARCHAR(20) NULL DEFAULT NULL,
	type VARCHAR(10) NULL DEFAULT NULL,
	country_id BIGINT NULL DEFAULT NULL,
	region_code VARCHAR(5) NULL DEFAULT NULL,
	PRIMARY KEY (iso),
	INDEX countries_dec_mes_lang_key (message_lang_key)
);

CREATE TABLE partners (
	id           serial        not null
    constraint partners_type_pk
		primary key,
	name VARCHAR(120) NOT NULL,
	partner_type VARCHAR(20) NOT NULL,
	logo_image_name VARCHAR(100) NULL DEFAULT NULL,
	sites VARCHAR(50) NULL DEFAULT NULL,
	url VARCHAR(150) NULL DEFAULT NULL,
	country_iso VARCHAR(10) 
	constraint partners_country_iso_fk
			references countries,
	active boolean default true
	
);