/*
table name dg3_org_type master
org_id- serial
org_name- organization name
org_type 1- buyer 2 seller
*/

create table dg3_org_type
(
    org_id           serial        not null
        constraint dg3_org_type_pk
            primary key,
    org_name         varchar(100) not null,

    org_type       integer       not null
);

/*
insert
*/
INSERT INTO dg3_org_type (org_name,org_type) VALUES ('Government',1),('Public Company',1),('Private Company',1),('Public Sector Undertaking',1),('NGO',1),('LLP',2),('Corporation',2);