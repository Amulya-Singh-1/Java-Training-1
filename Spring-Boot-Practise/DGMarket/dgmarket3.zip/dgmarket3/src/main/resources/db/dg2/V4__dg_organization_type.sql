

    INSERT INTO dgf.public.dg_organization_type (id, type) VALUES ('PUBLIC','Public Company');