create table subscription_products (
	id           serial        not null
        constraint subscription_products_pk
            primary key,
	name varchar(250) not null,
	global_notices integer null default null,
	price bigint  null default null,
	currency varchar(3) null default null,
	product_code varchar(30) null default null,
	tax_percent smallint null default '0',
	promotional boolean null default null,
	duration_days integer null default null,
	local_countries text null default null,
	create_time timestamp null default 'now()',
	active boolean default false
);


create table subscriptions (
	id           serial        not null
        constraint subscriptions_pk
            primary key,
	
	org_id    integer  not null 
		constraint subscriptions_organization_id_fk
            references organizations,
	product_id    integer  not null 
		constraint subscriptions_product_id_fk
            references subscription_products,
	total_global_notices integer null default null,
	remaining_global_notices integer not null,
	start_date DATE null default 'now()',
	expiration_date DATE null default null,
	renewal_status varchar(10) null default null,
	transaction_id varchar(60) null default null,
	auto_renew boolean not null default false,
	active boolean not null default false
	);


create table notice_views (
	id           serial        not null
        constraint notice_views_pk
            primary key,
	user_id      integer                 not null
        constraint notice_views_users_id_fk
            references users,
	notice_id  integer  not null
		constraint notice_views_notice_id_fk
            references notices,
	seen_time timestamp null default 'now()'
);