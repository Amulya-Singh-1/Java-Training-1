alter table notices 
	add org_id  integer  not null default 1
		constraint notices_org_id_fk
            references organizations;