alter table organizations
    add constraint organizations_countries_iso_fk foreign key (org_country) references countries(iso),
	add constraint organizations_users_id_fk foreign key (org_creator_id) references users(id),
	add column country_operation varchar(3) null 
	constraint country_operation_contries_iso_fk
            references countries;