ALTER TABLE user_reset_password
    ADD CONSTRAINT user_reset_password_user_id_fk FOREIGN KEY (user_id) REFERENCES users(id);