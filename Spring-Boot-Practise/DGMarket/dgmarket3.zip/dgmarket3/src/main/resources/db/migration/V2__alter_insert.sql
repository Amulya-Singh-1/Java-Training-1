alter table organizations add column is_buyer  boolean  default false,
add column is_seller  boolean  default false;

alter table users add column email_verified boolean default false;


INSERT INTO roles_master (name) VALUES ('Global Admin'),('Admin'),('Editor'),('Viewer');
INSERT INTO organizations (org_id,org_type, org_name,org_description,org_email,org_reference_no,org_address,org_state,org_country,org_language,org_phone,org_fax,org_creator_id) VALUES (1,1, 'Dgmarket', 'dgmarket', 'dg@dgmarket.in', '4648683648', 'address', 'delhi', 'in', 'en', '01178888', '793479',NULL);
	
INSERT INTO users (email,password,first_name,last_name,mobile,organization_id,active) VALUES ('admin@dgmarket.com', '123456', 'global', 'admin', '1234567890', 1, 'true');

INSERT INTO user_roles (user_id,role_id,org_id) VALUES (1,1,1);