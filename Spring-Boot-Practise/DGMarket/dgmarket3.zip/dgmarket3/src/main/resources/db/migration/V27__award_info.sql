create table award_informations
(
    id            serial       not null
        constraint award_informations_pk
            primary key,
    bidder_name       varchar(80) not null,
    address          varchar(255) not null,
	initial_estimated_value         varchar(40),
	final_estimated_value         varchar(40),
	bid_recieved         varchar(10),
    contract_duration       varchar(10),
    award_date       timestamp null default null
);