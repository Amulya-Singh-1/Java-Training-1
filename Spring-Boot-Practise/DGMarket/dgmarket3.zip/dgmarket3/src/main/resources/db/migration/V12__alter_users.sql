alter table users drop column organization_id,
add column email_verificaton_code varchar(60);