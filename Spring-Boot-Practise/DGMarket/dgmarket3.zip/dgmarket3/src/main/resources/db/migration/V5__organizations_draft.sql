alter table organizations add column org_city    varchar(40),
add column last_modified_time timestamp;


create table organizations_draft
(
    org_id            serial       not null
    constraint organizations_draft_pk
            primary key,
    org_name          varchar(80) not null,
	user_id      integer         not null,
	is_buyer  boolean  default false,
	is_seller  boolean  default false,
    org_status        integer   default 0,      ---- 0 =>waiting for approval, 1=> approved
	created_time timestamp default now() not null	
    
);