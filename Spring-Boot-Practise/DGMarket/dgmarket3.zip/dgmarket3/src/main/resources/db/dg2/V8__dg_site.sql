

#to remove foreign key constraint from parent_parent_id column in dg_site.

ALTER TABLE dg_site
DROP CONSTRAINT fk_site_par_parent_id;