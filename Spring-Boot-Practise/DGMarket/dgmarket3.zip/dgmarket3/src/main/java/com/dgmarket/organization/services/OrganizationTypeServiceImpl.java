package com.dgmarket.organization.services;

import com.dgmarket.organization.entities.OrganizationType;
import com.dgmarket.organization.repositories.OrganizationTypeRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class OrganizationTypeServiceImpl implements OrganizationTypeService {

    private final OrganizationTypeRepository organizationTypeRepository;

    @Override
    public List<OrganizationType> getBuyerOrgList() {
        return organizationTypeRepository.findAll();
    }
}
