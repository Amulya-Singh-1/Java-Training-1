package com.dgmarket.sibutu.filters;

import com.dgmarket.sibutu.entities.SibutuTeam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class SibutuTeamSearchFilter {

    private Long id;
    private Long noticeId;
    private Long userId;
    private SibutuTeam.Role role;
}
