package com.dgmarket.web.services;

import com.dgmarket.common.repositories.CountryRepository;
import com.dgmarket.web.dto.request.OfficeLocationRequest;
import com.dgmarket.web.dto.request.OfficeLocationUpdateRequest;
import com.dgmarket.web.entities.OfficeLocation;
import com.dgmarket.web.repositories.OfficeLocationRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class OfficeLocationService {
    private final OfficeLocationRepository officeLocationRepository;
    private final CountryRepository countryRepository;
    private final EntityManagerFactory entityManagerFactory;


    public List<OfficeLocation> findByFilter(OfficeLocation officeLocation) {
        return officeLocationRepository.findAll().stream()
                .filter(
                        e -> (officeLocation.getId() == null || (officeLocation.getId().equals(e.getId())))
                                && (officeLocation.getName() == null || (officeLocation.getName().equals(e.getName())))
                                && (officeLocation.getType() == null || (officeLocation.getType().equals(e.getType())))
                                && (officeLocation.getOrgId() == null || (officeLocation.getOrgId().equals(e.getOrgId())))
                                && (officeLocation.getCountry() == null || (officeLocation.getCountry().equals(e.getCountry())))
                                && (officeLocation.getPincode() == null || (officeLocation.getPincode().equals(e.getPincode())))
                                && (officeLocation.getCity() == null || (officeLocation.getCity().equals(e.getCity())))
                                && (officeLocation.getState() == null || (officeLocation.getState().equals(e.getState())))
                                && (officeLocation.getFlatNo() == null || (officeLocation.getFlatNo().equals(e.getFlatNo())))
                                && (officeLocation.getLocality() == null || (officeLocation.getLocality().equals(e.getLocality())))
                                && (officeLocation.getContactNumber() == null || (officeLocation.getContactNumber().equals(e.getContactNumber())))
                                && (officeLocation.getEmail() == null || (officeLocation.getEmail().equals(e.getEmail())))
                ).collect(Collectors.toList());
    }


    public List filterLocations(OfficeLocation officeLocation) {
        String query = "select * from office_locations o where ";
        if (officeLocation.getId() == null &&
                officeLocation.getLocality() == null &&
                officeLocation.getCity() == null &&
                officeLocation.getState() == null &&
                officeLocation.getType() == null &&
                officeLocation.getContactNumber() == null &&
                officeLocation.getOrgId() == null &&
                officeLocation.getName() == null &&
                officeLocation.getPincode() == null &&
                officeLocation.getEmail() == null &&
                officeLocation.getFlatNo() == null &&
                officeLocation.getCountry() == null) {
            query = "select * from office_locations o";
        }
        if (officeLocation.getId() != null) {
            query = query + "o.id =" + officeLocation.getId();
        }
        if (officeLocation.getEmail() != null) {
            query = query + "o.email =" + "'" + officeLocation.getEmail() + "' &&";
        }
        if (officeLocation.getFlatNo() != null) {
            query = query + "o.flat_no =" + "'" + officeLocation.getFlatNo() + "' &&";
        }
        if (officeLocation.getPincode() != null) {
            query = query + "o.pincode =" + "'" + officeLocation.getPincode() + "' &&";
        }
        if (officeLocation.getCountry() != null) {
            query = query + "o.country =" + "'" + officeLocation.getCountry() + "' &&";
        }
        if (officeLocation.getState() != null) {
            query = query + "o.state =" + "'" + officeLocation.getState() + "' &&";
        }
        if (officeLocation.getLocality() != null) {
            query = query + "o.locality =" + "'" + officeLocation.getLocality() + "' &&";
        }
        if (officeLocation.getName() != null) {
            query = query + "o.name =" + "'" + officeLocation.getName() + "' &&";
        }
        if (officeLocation.getContactNumber() != null) {
            query = query + "o.contact_number =" + "'" + officeLocation.getContactNumber() + "' &&";
        }
        if (officeLocation.getType() != null) {
            query = query + "o.type =" + "'" + officeLocation.getType() + "' &&";
        }
        if (officeLocation.getCity() != null) {
            query = query + "o.city =" + "'" + officeLocation.getCity() + "' &&";
        }
        if (officeLocation.getOrgId() != null) {
            query = query + "o.org_id =" + "'" + officeLocation.getOrgId() + "'";
        }

        EntityManager entityManager = entityManagerFactory.createEntityManager();
        if (query.endsWith("&&")) {
            query = query.substring(0, query.length() - 2);
        }

        List officeLocations = entityManager.createNativeQuery(query, OfficeLocation.class).getResultList();

        return officeLocations;

    }

    public OfficeLocation addOfficeLocation(OfficeLocationRequest officeLocationRequest) {
        OfficeLocation officeLocation = new OfficeLocation(null
                , officeLocationRequest.getName()
                , officeLocationRequest.getType()
                , officeLocationRequest.getOrgId()
                , countryRepository.findById(officeLocationRequest.getCountry()).orElse(null)
                , officeLocationRequest.getPincode()
                , officeLocationRequest.getCity()
                , officeLocationRequest.getState()
                , officeLocationRequest.getFlatNo()
                , officeLocationRequest.getLocality()
                , officeLocationRequest.getContactNumber()
                , officeLocationRequest.getEmail()
        );
        return officeLocationRepository.save(officeLocation);
    }

    public OfficeLocation updateOfficeLocation(OfficeLocationUpdateRequest officeLocationUpdateRequest, Long id) {
        OfficeLocation officeLocation = officeLocationRepository.findById(id).orElse(null);
        officeLocation.setName(officeLocationUpdateRequest.getName() == null ? officeLocation.getName() : officeLocationUpdateRequest.getName());
        officeLocation.setType(officeLocationUpdateRequest.getType() == null ? officeLocation.getType() : officeLocationUpdateRequest.getType());
        officeLocation.setOrgId(officeLocationUpdateRequest.getOrgId() == null ? officeLocation.getOrgId() : officeLocationUpdateRequest.getOrgId());
        if (officeLocationUpdateRequest.getCountry() != null && !officeLocation.getCountry().equals(officeLocationUpdateRequest.getCountry())) {
            officeLocation.setCountry(countryRepository.findById(officeLocationUpdateRequest.getCountry()).orElse(null));
        }
        officeLocation.setPincode(officeLocationUpdateRequest.getPincode() == null ? officeLocation.getPincode() : officeLocationUpdateRequest.getPincode());
        officeLocation.setCity(officeLocationUpdateRequest.getCity() == null ? officeLocation.getCity() : officeLocationUpdateRequest.getCity());
        officeLocation.setState(officeLocationUpdateRequest.getState() == null ? officeLocation.getState() : officeLocationUpdateRequest.getState());
        officeLocation.setFlatNo(officeLocationUpdateRequest.getFlatNo() == null ? officeLocation.getFlatNo() : officeLocationUpdateRequest.getFlatNo());
        officeLocation.setLocality(officeLocationUpdateRequest.getLocality() == null ? officeLocation.getLocality() : officeLocationUpdateRequest.getLocality());
        officeLocation.setContactNumber(officeLocationUpdateRequest.getContactNumber() == null ? officeLocation.getContactNumber() : officeLocationUpdateRequest.getContactNumber());
        officeLocation.setEmail(officeLocationUpdateRequest.getEmail() == null ? officeLocation.getEmail() : officeLocationUpdateRequest.getEmail());

        return officeLocationRepository.save(officeLocation);
    }

    public void deleteOfficeLocation(Long id) {
        officeLocationRepository.deleteById(id);
    }

    public boolean officeLocationExists(Long id) {
        return officeLocationRepository.existsById(id);
    }


}
