package com.dgmarket.web.services;

import com.dgmarket.web.dto.PartnerListDTO;
import com.dgmarket.web.dto.PartnerPageDTO;
import com.dgmarket.web.dto.response.PartnerListResponse;
import com.dgmarket.web.entities.Partner;
import com.dgmarket.web.repositories.PartnerRepository;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class PartnerService{

    private final PartnerRepository partnerRepository;

    public Partner createPartners(Partner partner) {
        return partnerRepository.save(partner);
    }

    public Page<Partner> getAllPartners(int pageNo, int perPage) {
        return  partnerRepository.findAll(PageRequest.of(pageNo - 1, perPage));
    }

    public Partner getPartnerById(long id) {
        return partnerRepository.findById(id).get();
    }

    public void updatePartner(Long id, Partner partner) {
     Partner updatePartner = partnerRepository.findById(id).get();
        updatePartner.setName(partner.getName());
        updatePartner.setPartnerType(partner.getPartnerType());
        updatePartner.setSites(partner.getSites());
        updatePartner.setCountry(partner.getCountry());
        updatePartner.setUrl(partner.getUrl());
        updatePartner.setActive(partner.isActive());
        partnerRepository.save(updatePartner);
    }

    public PartnerListResponse preparePartnerList(PartnerPageDTO partnerPageDTO) {
        Page<Partner> partnerList = getAllPartners(partnerPageDTO.getPageNo(), partnerPageDTO.getPageSize());
        return PartnerListResponse.builder()
                .currentPage(partnerPageDTO.getPageNo())
                .partnerList(preparePartnerDTOList(partnerList.toList()))
                .totalInPage(partnerPageDTO.getPageSize())
                .totalPartnersCount(partnerList.getTotalElements())
                .build();
    }

    private List<PartnerListDTO> preparePartnerDTOList(List<Partner> partnerList) {
        List<PartnerListDTO> partnerListDTOList  = partnerList.stream()
                .map(this::populatePartnerDto)
                .collect(Collectors.toList());

        return partnerListDTOList;
    }

    public PartnerListDTO populatePartnerDto(Partner partner) {
        return PartnerListDTO.builder()
                .id(partner.getId())
                .name(partner.getName())
                .partnerType(partner.getPartnerType())
                .sites(partner.getSites())
                .url(partner.getUrl())
                .country(partner.getCountry() != null ? partner.getCountry().getCountryName() : "")
                .active(partner.isActive())
                .build();
    }

}
