package com.dgmarket.organization.services;

import com.dgmarket.notice.entities.Notice;
import com.dgmarket.notice.service.NoticeService;
import com.dgmarket.organization.dto.response.DashboardStatsResponse;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.web.dto.response.MonthlyStatsResponse;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Month;
import java.time.Year;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@AllArgsConstructor
@Service
public class DashboardService {

    final private NoticeService noticeService;
    final private OrganizationHelper organizationHelper;
    private List<Notice> notices;

    public Long getOnlineTenders(Long orgId) {
        return notices.stream().filter(notice -> notice.isPublishOnSibutu() && notice.getOrganization().getOrgId().equals(orgId == null ? notice.getOrganization().getOrgId() : orgId)).count();
    }

    public Long getOfflineTenders(Long orgId) {
        return notices.stream().filter(notice -> !notice.isPublishOnSibutu() && notice.getOrganization().getOrgId().equals(orgId == null ? notice.getOrganization().getOrgId() : orgId)).count();
    }

    public Long getTotalNotices(Long orgId) {
        return notices.stream().filter(notice -> notice.getOrganization().getOrgId().equals(orgId == null ? notice.getOrganization().getOrgId() : orgId)).count();
    }

    public Long getClosedTenders(Long orgId) {
        return notices.stream().filter(notice -> notice.isPublishOnSibutu() && notice.getOrganization().getOrgId().equals(orgId == null ? notice.getOrganization().getOrgId() : orgId) && (notice.getNoticeDeadline() != null && (notice.getNoticeDeadline().before(new Date())))).count();
    }

    public Long getDraftTenders(Long orgId) {
        return notices.stream().filter(notice -> notice.isPublishOnSibutu() && notice.getOrganization().getOrgId().equals(orgId == null ? notice.getOrganization().getOrgId() : orgId) && notice.getStatus().name().equals("draft")).count();
    }

    public Integer getChildBuyers(Long orgId) {
        return organizationHelper.countAllChildren(organizationHelper.getOrganizationById(orgId), 0);
    }

    public List<DashboardStatsResponse> dashboardResponse(Long orgId) {
        notices = noticeService.findAll();
        List<DashboardStatsResponse> response = new ArrayList<>();
        response.addAll(List.of(
                new DashboardStatsResponse("Total Notices", getTotalNotices(orgId).toString()),
                new DashboardStatsResponse("Online Tenders", getOnlineTenders(orgId).toString()),
                new DashboardStatsResponse("Draft Tenders", getDraftTenders(orgId).toString()),
                new DashboardStatsResponse("Offline Tenders", getOfflineTenders(orgId).toString()),
                new DashboardStatsResponse("Closed Tenders", getClosedTenders(orgId).toString()),
                new DashboardStatsResponse("Child Buyers", getChildBuyers(orgId).toString())
        ));
        return response;
    }


    public List<MonthlyStatsResponse> getMonthlyStats(Long orgId) {
        notices = noticeService.findAll();
        return List.of(
                new MonthlyStatsResponse("January", tenderCountByMonth(Month.JANUARY, Year.now(), orgId)),
                new MonthlyStatsResponse("February", tenderCountByMonth(Month.FEBRUARY, Year.now(), orgId)),
                new MonthlyStatsResponse("March", tenderCountByMonth(Month.MARCH, Year.now(), orgId)),
                new MonthlyStatsResponse("April", tenderCountByMonth(Month.APRIL, Year.now(), orgId)),
                new MonthlyStatsResponse("May", tenderCountByMonth(Month.MAY, Year.now(), orgId)),
                new MonthlyStatsResponse("June", tenderCountByMonth(Month.JUNE, Year.now(), orgId)),
                new MonthlyStatsResponse("July", tenderCountByMonth(Month.JULY, Year.now(), orgId)),
                new MonthlyStatsResponse("August", tenderCountByMonth(Month.AUGUST, Year.now(), orgId)),
                new MonthlyStatsResponse("September", tenderCountByMonth(Month.SEPTEMBER, Year.now(), orgId)),
                new MonthlyStatsResponse("October", tenderCountByMonth(Month.OCTOBER, Year.now(), orgId)),
                new MonthlyStatsResponse("November", tenderCountByMonth(Month.NOVEMBER, Year.now(), orgId)),
                new MonthlyStatsResponse("December", tenderCountByMonth(Month.DECEMBER, Year.now(), orgId))
        );

    }


    private Double tenderCountByMonth(Month month, Year year, Long orgId) {

        return (double) notices.stream().filter(notice -> (
                (notice.getOrganization().getOrgId().equals(orgId))
                &&(month.ordinal() == (notice.getPublishDate().getMonth()))
                && (year.getValue() == (getCurrentYear(notice)))
                )
        ).count();
    }

    private int getCurrentYear(Notice notice) {
        return notice.getPublishDate().getYear() + 1900;
    }
}
