package com.dgmarket.organization.dto.filters;

import com.dgmarket.core.dto.request.BaseFilter;
import lombok.Data;

@Data
public class DraftOrganizationFilter extends BaseFilter {
    OrganizationStatus status;
    Long userId;

    public boolean hasUserId() {
        return userId != null && userId > 0;
    }

    public boolean hasStatus() {
        return (status != null);
    }

    public Integer getStatus() {
        return this.status.val;
    }

    enum OrganizationStatus {
        draft(0), approved(1);
        int val;

        OrganizationStatus(int _st) {
            this.val = _st;
        }
    }
}