package com.dgmarket.notice.service;

import com.dgmarket.notice.entities.FundingAgency;
import com.dgmarket.notice.repositories.FundingAgencyRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class FundingAgencyService {

    private final FundingAgencyRepository fundingAgencyRepository;

    public List<FundingAgency> findAllFundingAgencies() {
        return fundingAgencyRepository.findAll();
    }


    public FundingAgency findFundingAgencyById(Integer fundingAgencyId) {
        return fundingAgencyRepository.getById(fundingAgencyId);
    }
}
