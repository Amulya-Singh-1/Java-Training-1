package com.dgmarket.notice.service;

import com.dgmarket.notice.dto.response.NoticeTypesResponse;
import com.dgmarket.notice.entities.NoticeTypes;
import com.dgmarket.notice.repositories.NoticeTypesRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class NoticeTypesService {

    private final NoticeTypesRepository noticeTypesRepository;

    public List<NoticeTypes> findAllNoticeTypes() {
        return noticeTypesRepository.findAll();
    }

    public NoticeTypes findNoticeTypesByCode(String code){
        return noticeTypesRepository.findByCode(code);
    }

    public NoticeTypesResponse propagateNoticeTypeDTO(NoticeTypes noticeTypes) {
        return NoticeTypesResponse.builder()
                .id(noticeTypes.getCode())
                .name(noticeTypes.getName())
                .build();
    }

}
