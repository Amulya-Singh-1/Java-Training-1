package com.dgmarket.user.enums;

public enum UserPreferenceKeys {
    USER_PREFS_INTERESTED_SECTORS, USER_PREFS_INTERESTED_TENDERS
}
