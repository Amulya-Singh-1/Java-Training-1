package com.dgmarket.notice.dto.response;

import lombok.*;
import org.springframework.stereotype.Component;

@Component
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CPVListDTO {

    private String id;
    private String code;
    private String friendlyName;
    private Long children;
    private Integer indent;

}