package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.NoticeCpvMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NoticeCpvMappingRepository extends JpaRepository<NoticeCpvMapping, Long> {

    List<NoticeCpvMapping> findAllByNotice_Id(Long noticeId);
}
