package com.dgmarket.organization.dto.response;

import com.dgmarket.core.dto.response.BaseResponse;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class DraftOrganizationListResponse extends BaseResponse {

    List<DraftOrganizatonListItemDTO> draftOrganizationList;

    public DraftOrganizationListResponse(String _message, int _currentPage, int _totalInPage, long _total,
                                    List<DraftOrganizatonListItemDTO> _draftOrganizationList) {
        this.message = _message;
        this.currentPage = _currentPage;
        this.perPage = _totalInPage;
        this.total = _total;
        draftOrganizationList = _draftOrganizationList;
    }
}
