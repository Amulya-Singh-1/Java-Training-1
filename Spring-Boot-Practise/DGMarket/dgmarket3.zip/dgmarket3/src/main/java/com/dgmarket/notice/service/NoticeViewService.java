package com.dgmarket.notice.service;

import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.notice.dto.request.NoticeViewsAndDownloadRequest;
import com.dgmarket.notice.entities.NoticeViews;
import com.dgmarket.notice.repositories.NoticeRepository;
import com.dgmarket.notice.repositories.NoticeViewsRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Date;

@AllArgsConstructor
@Service
public class NoticeViewService {

    private final NoticeViewsRepository noticeViewsRepository;
    private final NoticeRepository noticeRepository;
    private final UserRepository userRepository;

    public NoticeViews addNoticeViews(NoticeViewsAndDownloadRequest noticeViewsAndDownloadRequest){

        NoticeViews noticeViews = new NoticeViews(
                null
                ,userRepository.findUserById(noticeViewsAndDownloadRequest.getUserId())
                ,noticeRepository.getById(noticeViewsAndDownloadRequest.getNoticeId())
                ,new Date()
        );
        return noticeViewsRepository.save(noticeViews);
    }
}
