package com.dgmarket.sibutu.entities;

import com.dgmarket.notice.entities.Notice;
import com.dgmarket.user.entities.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "sibutu_team")
@Builder

public class SibutuTeam {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "notice_id")
    @JsonIgnore
    private Notice noticeId;
    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonIgnore
    private User userId;
    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private Role role;


    public enum Role {

        REVIEWER,OPENER,EVALUATOR,APPROVER;
    }

}
