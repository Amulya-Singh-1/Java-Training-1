package com.dgmarket.notice.entities;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "ep_notice_items")
@Data
public class NoticeCPV {
    @Id
    @Column(name = "item_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "noticeItem")
    @SequenceGenerator(name = "noticeItem", sequenceName = "ep_notice_item_id_seq", allocationSize = 1)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "notice_id")
    private Notice notice;

    @ManyToOne
    @JoinColumn(name = "commodity_code", referencedColumnName = "cpv")
    private CPV cpv;

    static public NoticeCPV create(Notice notice, CPV cpv) {
        NoticeCPV noticeCPV = new NoticeCPV();
        noticeCPV.setNotice(notice);
        noticeCPV.setCpv(cpv);
        return noticeCPV;
    }
}
