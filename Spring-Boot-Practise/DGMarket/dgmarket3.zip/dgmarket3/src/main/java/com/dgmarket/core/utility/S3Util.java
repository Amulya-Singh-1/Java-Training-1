package com.dgmarket.core.utility;

import lombok.AllArgsConstructor;
import org.apache.commons.io.IOUtils;
import software.amazon.awssdk.awscore.exception.AwsServiceException;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.exception.SdkClientException;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.io.IOException;
import java.io.InputStream;

@AllArgsConstructor
public class S3Util {

    private static final String BUCKET = "dg3-dev-docstore";

    public static boolean uploadFile(String fileName, InputStream inputStream) throws S3Exception, AwsServiceException, SdkClientException, IOException {
        S3Client client = S3Client.builder().build();

        PutObjectRequest request = PutObjectRequest.builder()
                .bucket(BUCKET)
                .key(fileName)
                .build();

        if(client.putObject(request, RequestBody.fromInputStream(inputStream, inputStream.available())) != null){
            return true;
        }
        return false;
    }

    public static boolean deleteFile(String fileName) throws S3Exception, AwsServiceException, SdkClientException, IOException {
        S3Client client = S3Client.builder().build();

        DeleteObjectRequest request = DeleteObjectRequest.builder()
                .bucket(BUCKET)
                .key(fileName)
                .build();

        if(client.deleteObject(request) != null){
            return true;
        }
        return false;
    }

    public static byte[] downloadFileFromS3(String fileName) throws IOException {
        S3Client client = S3Client.builder().build();

        GetObjectRequest object = GetObjectRequest.builder()
                .bucket(BUCKET)
                .key(fileName)
                .build();
        ResponseInputStream<GetObjectResponse> inputStream = client.getObject(object);
        byte[] bytes = IOUtils.toByteArray(inputStream);
        return bytes;
    }

}
