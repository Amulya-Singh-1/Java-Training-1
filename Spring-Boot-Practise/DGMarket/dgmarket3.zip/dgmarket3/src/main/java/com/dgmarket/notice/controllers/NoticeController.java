package com.dgmarket.notice.controllers;

import com.dgmarket.core.config.Constants;
import com.dgmarket.notice.dto.filters.NoticeFilter;
import com.dgmarket.notice.dto.filters.NoticeSearchFilter;
import com.dgmarket.notice.dto.request.*;
import com.dgmarket.notice.dto.response.NoticeDetailDTO;
import com.dgmarket.notice.dto.response.NoticeDocumentsDTO;
import com.dgmarket.notice.dto.response.NoticeListResponse;
import com.dgmarket.notice.entities.*;
import com.dgmarket.notice.helpers.NoticeDetailsHelper;
import com.dgmarket.notice.helpers.NoticeDocumentsHelper;
import com.dgmarket.notice.service.*;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.user.entities.User;
import com.dgmarket.user.services.UserService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


@RestController
@RequestMapping("/api/notices")
@AllArgsConstructor
public class NoticeController {

    private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);

    private final NoticeService noticeService;
    private final UserService userService;
    private final NoticeFundingService noticeFundingService;
    private final NoticeDetailService noticeDetailService;
    private final NoticeContactsService noticeContactsService;
    private final NoticeDocumentsService noticeDocumentsService;
    private final NoticeDocumentsHelper noticeDocumentsHelper;
    private final NoticeDetailsHelper noticeDetailsHelper;
    private final OrganizationHelper organizationHelper;
    private final NoticeCpvMappingService noticeCpvMappingService;

    @GetMapping("/")
    public ResponseEntity<NoticeListResponse> noticeList(NoticeSearchFilter filter) {
        logger.info("fetching list of notices from database for notice list api ...");
        return ResponseEntity.ok().body(noticeService.prepareNoticeList(filter));
    }

    @GetMapping("/filter")
    public ResponseEntity<NoticeListResponse> findNoticeListByFilter(NoticeFilter filter) {
        logger.info("fetching list of notices from database for notice list api ...");
        return ResponseEntity.ok().body(noticeService.findNoticeList(filter));
    }

    @GetMapping(value ="/documents/{id}")
    public ResponseEntity<?> documentList(@PathVariable("id") Long noticeId) {
        final Map<String, Object> responseBody = new HashMap<>();
        List<NoticeDocuments> noticeDocumentsList = noticeDocumentsService.findNoticeDocumentsListByNoticeId(noticeId);
        if(!(noticeDocumentsList.isEmpty())){
            List<NoticeDocumentsDTO> noticeDocumentsDTOList = noticeDocumentsService.getNoticeDocumentsDTOList(noticeDocumentsList);
            responseBody.put("status", HttpServletResponse.SC_OK);
            responseBody.put("documentList", noticeDocumentsDTOList);
            return ResponseEntity.ok().body(responseBody);
        }
        responseBody.put("status", HttpServletResponse.SC_NO_CONTENT);
        responseBody.put("message", "Documents not found !!.");
        return ResponseEntity.ok().body(responseBody);
    }

    @GetMapping(value ="/{id}")
    public ResponseEntity<?> noticeDetails(@PathVariable("id") Long noticeId) {
        final Map<String, Object> responseBody = new HashMap<>();
        NoticeDetailDTO noticeDetailDTO = noticeDetailsHelper.getNoticeDetailsDTOByNoticeId(noticeId);
        if(noticeDetailDTO != null){
            responseBody.put("status", HttpServletResponse.SC_OK);
            responseBody.put("noticeDetails", noticeDetailDTO);
            return ResponseEntity.ok().body(responseBody);
        }
        responseBody.put("status", HttpServletResponse.SC_CONFLICT);
        responseBody.put("message", "Notice Details not found !!.");
        return ResponseEntity.badRequest().body(responseBody);
    }

    @GetMapping("/cpv/{id}")
    public ResponseEntity<?> findNoticeCpvMappingCollectionByNoticeId(@PathVariable("id") Long noticeId) {
        final Map<String, Object> responseBody = new HashMap<>();

        List<NoticeCpvMapping> noticeCpvMappingList = noticeCpvMappingService.findNoticeCpvMappingListByNoticeId(noticeId);
        if(!(noticeCpvMappingList.isEmpty())){
            responseBody.put("status", HttpServletResponse.SC_OK);
            responseBody.put("message", "Notice cpv mapping found successfully !!.");
            responseBody.put("noticeCpvMapping", noticeDetailsHelper.getNoticeCpvMappingDTOList(noticeCpvMappingList));
            return ResponseEntity.ok().body(responseBody);
        }
        responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
        responseBody.put("message", "Notice cpv mapping not found for given Notice ID !!.");
        return ResponseEntity.ok().body(responseBody);
    }

    @PostMapping("/generalInformation")
    public ResponseEntity generalInformation(@Valid @RequestBody CreateNoticeRequest createNoticeRequest) {
        final Map<String, Object> responseBody = new HashMap<>();
        SimpleDateFormat simple = new SimpleDateFormat(Constants.DEFAULT_DATE_TIME_FORMAT);
        SimpleDateFormat dateFormatForUi = new SimpleDateFormat(Constants.DEFAULT_DATE_TIME_UI);
        Date deadLineDate = null;
        User user = userService.getUserById(createNoticeRequest.getUserId());
        if (user == null) {
            responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
            responseBody.put("message", "User record not found !!");
            return ResponseEntity.badRequest().body(responseBody);
        }
        if(organizationHelper.getOrganizationById(createNoticeRequest.getOrgId()) == null) {
            responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
            responseBody.put("message", "Organization record not found !!");
            return ResponseEntity.badRequest().body(responseBody);
        }
        if (createNoticeRequest.getDeadline() != null && (!(createNoticeRequest.getDeadline().isEmpty()))) {
            try {
                Date fromUi = dateFormatForUi.parse(createNoticeRequest.getDeadline());
                deadLineDate = simple.parse(simple.format(fromUi));
            } catch (ParseException e) {
                logger.error("While Parse the Deadline Date : {}", e.getMessage());
            }
        }
        Notice notice = noticeService.populateAndSaveGeneralInformation(createNoticeRequest, user, deadLineDate);
        noticeFundingService.saveFundingAgencyForNotice(notice, createNoticeRequest.getFundingAgency());
        responseBody.put("noticeId", notice.getId());
        responseBody.put("status", HttpServletResponse.SC_CREATED);
        responseBody.put("message", "General information added successfully!");
        logger.info("General information added successfully !!.");
        return ResponseEntity.ok().body(responseBody);

    }

    @PostMapping("/noticeContactInfo")
    public ResponseEntity noticeContactInfo(@Valid @RequestBody NoticeContactInfoRequest noticeContactInfoRequest) {
        final Map<String, Object> responseBody = new HashMap<>();
        if (noticeService.findById(noticeContactInfoRequest.getNoticeId()) == null) {
            responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
            responseBody.put("message", "Notice not found for given notice id !!");
            return ResponseEntity.badRequest().body(responseBody);
        }
        Notice notice = noticeService.findById(noticeContactInfoRequest.getNoticeId());
        NoticeContacts noticeContacts = noticeContactsService.findNoticeContactByNoticeId(noticeContactInfoRequest.getNoticeId());
        if(noticeContacts != null){
            noticeContactsService.updateNoticeContact(noticeContacts, noticeContactInfoRequest);
            responseBody.put("message", "Contact information updated successfully !!.");
            logger.info("Contact information updated successfully !!.");
        } else {
            noticeContactsService.propagateAndSaveNoticeContact(notice, noticeContactInfoRequest);
            responseBody.put("message", "Contact information added successfully !!.");
            logger.info("Contact information added successfully !!.");
        }
        responseBody.put("status", HttpServletResponse.SC_OK);
        return ResponseEntity.ok().body(responseBody);
    }

    @PostMapping("/detailedInfo")
    public ResponseEntity noticeDetailedInfo(@Valid @RequestBody DetailedInformationRequest detailedInformationRequest) {
        final Map<String, Object> responseBody = new HashMap<>();
        if (noticeService.findById(detailedInformationRequest.getNoticeId()) == null) {
            responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
            responseBody.put("message", "Notice not found for given notice id !!");
            return ResponseEntity.badRequest().body(responseBody);
        }
        Notice notice = noticeService.findById(detailedInformationRequest.getNoticeId());
        NoticeDetail noticeDetail = noticeDetailService.findNoticeDetailByNoticeId(detailedInformationRequest.getNoticeId());
        if(noticeDetail != null){
            noticeDetailService.updateNoticeDetail(noticeDetail, detailedInformationRequest);
            responseBody.put("message", "Detailed information updated successfully !!.");
            logger.info("Detailed information updated successfully !!.");
        } else {
            noticeDetailService.propagateAndSaveNoticeDetail(notice, detailedInformationRequest);
            responseBody.put("message", "Detailed information added successfully !!.");
            logger.info("Detailed information added successfully !!.");
        }
        responseBody.put("status", HttpServletResponse.SC_OK);
        return ResponseEntity.ok().body(responseBody);
    }

    @PostMapping(value ="/noticeDocument", consumes = { MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE })
    public ResponseEntity<?> noticeDocument(@RequestPart("file") MultipartFile file, @RequestPart("noticeDocumentsRequest") String noticeDocumentsRequest) {
        final Map<String, Object> responseBody = new HashMap<>();
        if(file.isEmpty()){
            responseBody.put("status", HttpServletResponse.SC_CONFLICT);
            responseBody.put("message", "File Not found !!.");
            return ResponseEntity.badRequest().body(responseBody);
        }
        if(!(noticeDocumentsHelper.checkFilePermittedExtensions(file.getOriginalFilename()))){
            responseBody.put("status", HttpServletResponse.SC_NOT_ACCEPTABLE);
            responseBody.put("message", "File extension is not valid !!.");
            return ResponseEntity.ok().body(responseBody);
        }
        NoticeDocumentsRequest noticeDocumentsRequests = noticeDocumentsHelper.getNoticeDocumentRequestJson(noticeDocumentsRequest);
        if(noticeDocumentsHelper.noticeDocumentUpload(file) == true && noticeDocumentsRequests != null){
            NoticeDocuments noticeDocuments = noticeDocumentsService.getNoticeDocumentsFromDTO(noticeDocumentsRequests, file);
            noticeDocumentsService.saveNoticeDocuments(noticeDocuments);
            responseBody.put("status", HttpServletResponse.SC_OK);
            responseBody.put("message", "Notice documents uploaded successfully !!.");
            return ResponseEntity.ok().body(responseBody);
        }
        responseBody.put("status", HttpServletResponse.SC_CONFLICT);
        responseBody.put("message", "Notice Documents not uploaded !!.");
        return ResponseEntity.badRequest().body(responseBody);
    }

    @PostMapping("/cpv")
    public ResponseEntity noticeCpvMapping(@RequestBody List<NoticeCpvMappingRequest> noticeCpvMappingRequest) {
        final Map<String, Object> responseBody = new HashMap<>();
        noticeCpvMappingService.addNoticeCpvMapping(noticeCpvMappingRequest);
        Notice notice = noticeService.findById(noticeCpvMappingRequest.get(0).getNoticeId());
        if(notice != null){
            notice.setCompletedSteps(CompletedSteps.cpv);
            noticeService.createNotice(notice);
        }
        responseBody.put("message", "Notice cpv mapping added successfully !!.");
        logger.info("Notice cpv mapping added successfully !!.");
        responseBody.put("status", HttpServletResponse.SC_OK);
        return ResponseEntity.ok().body(responseBody);
    }

    @PutMapping("/{id}")
    public ResponseEntity updateGeneralInformation(@PathVariable("id") Long noticeId, @RequestBody CreateNoticeRequest createNoticeUpdateRequest) {
        final Map<String, Object> responseBody = new HashMap<>();
        SimpleDateFormat simple = new SimpleDateFormat(Constants.DEFAULT_DATE_TIME_FORMAT);
        SimpleDateFormat dateFormatForUi = new SimpleDateFormat(Constants.DEFAULT_DATE_TIME_UI);
        Date deadLineDate = null;
        if (createNoticeUpdateRequest.getDeadline() != null && (!(createNoticeUpdateRequest.getDeadline().isEmpty()))) {
            try {
                Date fromUi = dateFormatForUi.parse(createNoticeUpdateRequest.getDeadline());
                deadLineDate = simple.parse(simple.format(fromUi));
            } catch (ParseException e) {
                logger.error("While Parse the Deadline Date : {}", e.getMessage());
            }
        }
        Notice notice = noticeService.findById(noticeId);
        if(notice != null){
            if(deadLineDate != null)
            notice.setNoticeDeadline(deadLineDate);
            noticeService.updateNotice(notice, createNoticeUpdateRequest);
        } else {
            responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
            responseBody.put("message", "Notice not found for given ID!");
            logger.info("Notice not found for given id - "+noticeId);
            return ResponseEntity.ok().body(responseBody);
        }
        responseBody.put("status", HttpServletResponse.SC_CREATED);
        responseBody.put("message", "Information has been updated successfully!");
        logger.info("Information has been updated  successfully");
        return ResponseEntity.ok().body(responseBody);
    }

    @DeleteMapping("/document/{id}")
    public ResponseEntity deleteDocument(@PathVariable("id") Long documentId) {
        final Map<String, Object> responseBody = new HashMap<>();

        NoticeDocuments noticeDocuments = noticeDocumentsService.findNoticeDocumentById(documentId);
        if(noticeDocuments != null){
            if(noticeDocumentsHelper.deleteDocumentFileFromStorage(noticeDocuments)) {
                noticeDocumentsService.deleteNoticeDocuments(noticeDocuments);
                responseBody.put("status", HttpServletResponse.SC_OK);
                responseBody.put("message", "Document deleted successfully !!.");
                logger.info("Document deleted successfully !!.");
                return ResponseEntity.ok().body(responseBody);
            } else {
                responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
                responseBody.put("message", "Document file not found and not deleted !!.");
                logger.info("Document file not found and not deleted !!.");
                return ResponseEntity.ok().body(responseBody);
            }

        }
        responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
        responseBody.put("message", "Document not found with given ID !!.");
        logger.info("Document not found with given ID");
        return ResponseEntity.ok().body(responseBody);
    }

    @DeleteMapping("/cpv/{id}")
    public ResponseEntity deleteNoticeCpvMapping(@PathVariable("id") Long noticeCpvMapId) {
        final Map<String, Object> responseBody = new HashMap<>();

        NoticeCpvMapping noticeCpvMapping = noticeCpvMappingService.findNoticeCpvMappingById(noticeCpvMapId);
        if(noticeCpvMapping != null){
            noticeCpvMappingService.deleteNoticeCpvMapping(noticeCpvMapping);
            responseBody.put("status", HttpServletResponse.SC_OK);
            responseBody.put("message", "Notice cpv mapping deleted successfully !!.");
            logger.info("Notice cpv mapping deleted successfully !!.");
            return ResponseEntity.ok().body(responseBody);
        } else {
            responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
            responseBody.put("message", "Notice cpv mapping not found with given ID !!.");
            logger.info("Notice cpv mapping not found with given ID !!.");
            return ResponseEntity.ok().body(responseBody);
        }
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<?> downloadFile(@PathVariable("id") Long documentId) {
        final Map<String, Object> responseBody = new HashMap<>();

        ByteArrayResource resource;
        NoticeDocuments noticeDocuments = noticeDocumentsService.findNoticeDocumentById(documentId);
        byte[] data = noticeDocumentsHelper.downloadFileFromStorage(noticeDocuments);
        if (data == null) {
            responseBody.put("status", HttpServletResponse.SC_NOT_FOUND);
            responseBody.put("message", "File not found");
            return ResponseEntity.ok().body(responseBody);
        }
        resource = new ByteArrayResource(data);
        String contentType = contentType(noticeDocuments.getFileName());
        String headerValue = "attachment; filename=\"" + noticeDocuments.getFileName() + "\"";

        return ResponseEntity.ok()
                .contentLength(data.length)
                .header(HttpHeaders.CONTENT_TYPE, contentType)
                .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
                .body(resource);
    }

    @GetMapping("/bulkDownload/{id}")
    public ResponseEntity<?> bulkDownloadFile(@PathVariable("id") Long noticeId, HttpServletResponse response) {
        final Map<String, Object> responseBody = new HashMap<>();

        ZipEntry zipentry = null;
        ZipOutputStream zipOutputStream = null;
        byte bytes[] = new byte[4096];

        List<NoticeDocuments> noticeDocumentsList = noticeDocumentsService.findNoticeDocumentsListByNoticeId(noticeId);
        if(!noticeDocumentsList.isEmpty()){

            try{
                zipOutputStream = new ZipOutputStream(response.getOutputStream());
                for(NoticeDocuments noticeDocuments : noticeDocumentsList) {
                    byte[] data = noticeDocumentsHelper.downloadFileFromStorage(noticeDocuments);
                    ByteArrayResource resource = new ByteArrayResource(data);
                    ZipEntry zipEntry = new ZipEntry(noticeDocuments.getFileName());
                    zipEntry.setSize(resource.contentLength());
                    zipEntry.setTime(System.currentTimeMillis());
                    zipOutputStream.putNextEntry(zipEntry);
                    StreamUtils.copy(resource.getInputStream(), zipOutputStream);
                    zipOutputStream.closeEntry();
                }
                zipOutputStream.finish();
                zipOutputStream.close();
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
            }
        } else {

        }
        String contentType = "application/zip";
        String headerValue = "attachment; filename=  zipfiles  ";
       return ResponseEntity.ok()
        .header(HttpHeaders.CONTENT_TYPE, contentType)
        .header(HttpHeaders.CONTENT_DISPOSITION, headerValue)
        .body(zipOutputStream);
    }

    private String contentType(String filename) {
        String[] fileArrSplit = filename.split("\\.");
        String fileExtension = fileArrSplit[fileArrSplit.length - 1];
        switch (fileExtension) {
            case "xlsx":
                return "application/vnd.ms-excel";
            case "png":
                return "image/png";
            case "jpg":
                return "image/jpeg";
            case "jpeg":
                return "image/jpeg";
            case "pdf":
                return "application/pdf";
            default:
                return "application/octet-stream";
        }
    }

}


