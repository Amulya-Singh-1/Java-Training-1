package com.dgmarket.core.utility;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class GenerateRandomPassword {

    public String generatePassword() {
        String randomNumerics = RandomStringUtils.randomNumeric(2);
        String randomSmallAlphabetics = RandomStringUtils.randomAlphabetic(5).toLowerCase();
        String randomCapitalAlphabetics = RandomStringUtils.randomAlphabetic(2).toUpperCase();
        String randomSpecialCharacters = generateSpecialCharactersByLength(1);

        return randomCapitalAlphabetics + randomSmallAlphabetics + randomNumerics + randomSpecialCharacters;
    }

    public String  generateSpecialCharactersByLength(int size) {

        final String specials = "!@#$&";
        Random rd = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(specials.charAt(rd.nextInt(specials.length())));
        }
        return sb.toString();
    }
}
