package com.dgmarket.notice.entities;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Objects;


@Entity
@Table(name = "cpv")
@Data
@NoArgsConstructor
public class CPV implements Serializable {

    @Id
    @Column(name = "cpv_id")
    private String id;

    @Column(name = "cpv")
    private String code;

    @Column(name = "friendly_name")
    private String friendlyName;

    @Column(name = "children")
    private Long children;

    @Column(name = "indent")
    private Integer indent;

    /**
     * CPV length
     */
    public static final int LENGTH = 8;

    public CPV(String code, Integer indent) {
        this.code = code;
        this.indent = indent;
    }

    public boolean fake() {
        return Objects.equals(code, "99900000") || Objects.equals(code, "99000000");
    }

    public String displayName() {
        return StringUtils.capitalize(friendlyName.replaceAll("-", " ").trim());
    }

    public boolean hasChildren() {
        return children != null && children > 0;
    }

    /**
     * Finds parent CPV, e.g. for the code 14200000 it will return 14000000
     *
     * @return parent CPV
     */
    public CPV getParentCPV() {
        int mainPartLength = getMainPartLength();
        if (mainPartLength >= 2) {
            StringBuilder parentCode = new StringBuilder(code);
            parentCode.setCharAt(mainPartLength - 1, '0');
            return new CPV(parentCode.toString(), indent - 1);
        }
        return null;
    }

    /**
     * Finds main part of the CPV code, e.g. for the code 90711100 it will return 907111
     *
     * @return main part, excluding trailing zeroes
     */
    public String getMainPart() {
        return code.substring(0, getMainPartLength());
    }

    /**
     * Finds the length of main part of the CPV code,
     * e.g. for the code 14200000 it will return 3, for 90000000 will return 2
     *
     * @return main part length
     */
    public int getMainPartLength() {
        return indent + 2;
    }

    public String get2DigitRootParent() {
        StringBuilder parentCode = new StringBuilder(code);
        for (int i = 2; i < LENGTH; i++) {
            parentCode.setCharAt(i, '0');
        }
        return parentCode.toString();
    }

}
