package com.dgmarket.notice.entities;

public enum CompletedSteps {
    general, contact, detail, cpv, team, document, contract_award, completed
}
