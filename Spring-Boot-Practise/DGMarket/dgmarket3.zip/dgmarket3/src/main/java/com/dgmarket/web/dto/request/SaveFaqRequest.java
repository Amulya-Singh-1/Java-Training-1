package com.dgmarket.web.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SaveFaqRequest {

    @NotNull(message = "Name should not be blank")
    @Size(min = 1)
    private String name;
    @NotNull(message = "Description should not be blank")
    @Size(min = 1)
    private String description;
    @NotNull(message = "Faq Type should not be blank")
    private String faqType;
    @NotNull(message = "ModuleInstanceId should not be blank")
    private Long moduleInstanceId;
}
