package com.dgmarket.web.entities;

import com.dgmarket.common.entities.Country;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "office_locations")
public class OfficeLocation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String type;
    private Long orgId;
    @OneToOne
    @JoinColumn(name = "country")
    private Country country;
    private String pincode;
    private String city;
    private String state;
    private String flatNo;
    private String locality;
    private String contactNumber;
    private String email;

    public String getCountry() {
        return this.country != null ? this.country.getIso() : null;
    }
}
