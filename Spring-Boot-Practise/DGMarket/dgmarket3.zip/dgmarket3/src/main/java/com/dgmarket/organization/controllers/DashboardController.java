package com.dgmarket.organization.controllers;

import com.dgmarket.organization.dto.response.DashboardStatsResponse;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.organization.services.DashboardService;
import com.dgmarket.user.services.UserService;
import com.dgmarket.web.dto.response.StatsResponse;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard/")
@AllArgsConstructor
public class DashboardController {
    final private UserService userService;
    final private DashboardService dashboardService;
    final private OrganizationHelper organizationHelper;

    @GetMapping("/stats")
    public ResponseEntity<?> getDashboardStats(Long orgId) {
        final Map<String, Object> body = new HashMap<>();
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", dashboardService.dashboardResponse(orgId));
        return ResponseEntity.ok(body);
    }

    @GetMapping("/tenderViewed")
    public ResponseEntity tenderViewed(@RequestParam(name = "userId") Long id) {
        final Map<String, Object> body = new HashMap<>();

        if (userService.getUserById(id) == null) {
            return ResponseEntity.badRequest().body("User not found with the given Id");
        }

        List<DashboardStatsResponse> dashboardStats = new ArrayList<>();
        dashboardStats.addAll(
                List.of(
                        new DashboardStatsResponse("Tender Viewed", "75")
                ));
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", dashboardStats);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/sector")
    public ResponseEntity<?> statsBySector(@RequestParam(name = "userId") Long id) {
        final Map<String, Object> body = new HashMap<>();

        if (id == null || userService.getUserById(id) == null) {
            return ResponseEntity.badRequest().body(body.put("status", HttpServletResponse.SC_BAD_REQUEST));
        }
        List<StatsResponse> stats = new ArrayList<>();
        stats.addAll(
                List.of(
                        new StatsResponse("Architecture and Urban Development", 65.45),
                        new StatsResponse("Agriculture & Food", 11.55),
                        new StatsResponse("Construction", 10.85),
                        new StatsResponse("Energy & Mining", 6.65),
                        new StatsResponse("Environment", 4.35),
                        new StatsResponse("Health & Public Services", 1.15)));
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", stats);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/continent")
    public ResponseEntity<?> statsByContinent(@RequestParam(name = "userId") Long id) {
        final Map<String, Object> body = new HashMap<>();

        if (id == null || userService.getUserById(id) == null) {
            return ResponseEntity.badRequest().body(body.put("status", HttpServletResponse.SC_BAD_REQUEST));
        }
        List<StatsResponse> stats = new ArrayList<>();

        stats.addAll(
                List.of(
                        new StatsResponse("Africa", 61.41),
                        new StatsResponse("North America", 11.84),
                        new StatsResponse("South America", 10.85),
                        new StatsResponse("Antarctica", 9.65),
                        new StatsResponse("Europe", 4.77),
                        new StatsResponse("Oceania", 1.48)
                )
        );

        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", stats);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/monthly")
    public ResponseEntity<?> monthlyStats(@RequestParam(name = "orgId") Long orgId) {
        final Map<String, Object> body = new HashMap<>();

        if (orgId==null || organizationHelper.getOrganizationById(orgId) == null) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.badRequest().body(body);
        }

        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", dashboardService.getMonthlyStats(orgId));

        return ResponseEntity.ok(body);

    }
}
