package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.Award;
import com.dgmarket.organization.entities.Organization;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AwardRepository extends JpaRepository<Award,Long> {

    List<Award> findAllByOrgId(Organization orgId);
}
