package com.dgmarket.user.dto.filter;

import com.dgmarket.core.dto.request.BaseFilter;
import lombok.Builder;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
@Builder
public class UserFilter extends BaseFilter {
    String keyword;
    Long orgId;

    public boolean hasOrgId(){
        return orgId != null;
    }

    public boolean hasKeyword() {
        return StringUtils.isNotEmpty(this.keyword);
    }
}
