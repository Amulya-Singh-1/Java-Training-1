package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.Language;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LanguageRepository extends JpaRepository<Language,String> {
}
