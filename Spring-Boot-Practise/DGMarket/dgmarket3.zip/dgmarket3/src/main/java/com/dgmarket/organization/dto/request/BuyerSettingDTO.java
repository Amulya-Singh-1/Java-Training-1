package com.dgmarket.organization.dto.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;


//todo:: only use this dto if there is a chance of the params to grow in future. Otherwise just pass the params directly as method variable.
@Data
@Builder
public class BuyerSettingDTO {
    @NotNull
    private Long orgId;
    private Integer buyerType;
}
