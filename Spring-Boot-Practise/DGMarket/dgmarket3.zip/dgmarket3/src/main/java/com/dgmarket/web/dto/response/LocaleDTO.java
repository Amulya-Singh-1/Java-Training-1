package com.dgmarket.web.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.persistence.Column;

@Data
@Builder
@AllArgsConstructor
public class LocaleDTO {

    private String code;
    private String name;

}
