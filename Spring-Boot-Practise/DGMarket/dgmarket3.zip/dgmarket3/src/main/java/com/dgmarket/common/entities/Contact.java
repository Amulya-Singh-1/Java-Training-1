package com.dgmarket.common.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.*;
import java.io.Serializable;


@Entity
@Table(name = "ep_addresses")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Slf4j
public class Contact implements Serializable {

    @Id
    @Column(name = "address_id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "contact")
    @SequenceGenerator(name = "contact", sequenceName = "ep_addresses_id_seq", allocationSize = 1)
    private Long id;

    @Column(name = "first_names")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "title")
    private String title;

    @Column(name = "department")
    private String department;

    @Column(name = "address")
    private String address;

    @Column(name = "address2")
    private String address2;

    @Column(name = "city")
    private String city;

    @Column(name = "state")
    private String state;

    @Column(name = "postal_code")
    private String postalCode;

    @ManyToOne
    @JoinColumn(name = "country_code")
    @Builder.Default
    private Country country = new Country();

    @Column(name = "phone")
    private String phone;

    @Column(name = "fax")
    private String fax;

    @Column(name = "email")
    private String email;

    @Column(name = "url")
    private String url;

    @Column(name = "agency_name")
    private String agencyName;

    /**
     * This is used from SaveNoticeRequest
     */
    @Transient
    private String countryCode;
    @Transient
    private String countryName;

    @Transient
    public String getFullName() {
        return StringUtils.stripToEmpty(StringUtils.stripToEmpty(firstName) + " " + StringUtils.stripToEmpty(lastName));
    }
}