package com.dgmarket.organization.services;

import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.exception.SameNamedOrganizationExistsException;
import com.dgmarket.organization.dto.filters.OrganizationFilter;
import com.dgmarket.organization.dto.request.BuyerSettingDTO;
import com.dgmarket.organization.dto.request.ContactInfoDTO;
import com.dgmarket.organization.dto.request.OrganizationCreateUpdateRequest;
import com.dgmarket.organization.dto.response.BaseOrganizationDTO;
import com.dgmarket.organization.dto.response.OrganizationListItemDTO;
import com.dgmarket.organization.dto.response.OrganizationListResponse;
import com.dgmarket.organization.entities.Organization;
import com.dgmarket.organization.entities.OrganizationUsers;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.organization.repositories.OrganizationRepository;
import com.dgmarket.organization.repositories.OrganizationUserRepository;
import com.dgmarket.user.entities.User;
import com.dgmarket.user.entities.UserRoles;
import com.dgmarket.user.repositories.UserRoleRepository;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class OrganizationService {

    private final OrganizationRepository organizationRepository;
    private final UserRoleRepository userRoleRepository;
    private final UserRepository userRepository;
    private final OrganizationHelper organizationHelper;
    private final OrganizationUserRepository organizationUserRepository;

    //todo:: need to prepare custom query to implment filter now only works with one filter at a time.. whcih serves the purpose
    public OrganizationListResponse prepareAllOrganizationList(OrganizationFilter filter) {
        Page<Organization> organizations;
        if (filter.hasUserId()) {
            return organizationHelper.prepareOrganizationListForUserId(filter);
        }

        if (filter.hasParentId() && filter.hasKeywords()) {
            organizations = organizationRepository.findOrganizationsBySearchKeyAndParentId(filter.getKeywords(), filter.getParentId(), PageRequest.of(filter.getPage(), filter.getPerPage()));
        } else if (filter.hasParentId()) {
            organizations = organizationRepository.findByOrgParentIdOrderByOrgIdDesc(filter.getParentId(), PageRequest.of(filter.getPage(), filter.getPerPage()));
        } else {
            organizations = getAllOrganizations(filter);
        }

        List<OrganizationListItemDTO> listItemDTOS = organizations.stream().map(org ->
                new OrganizationListItemDTO().getDTOFromEntity(org)
        ).collect(Collectors.toList());

        OrganizationListResponse organizationListResponse = new OrganizationListResponse(
                null,
                filter.getPage(),
                filter.getPerPage(),
                organizations.getTotalElements(),
                listItemDTOS
        );

        return organizationListResponse;
    }

    public Page<Organization> getAllOrganizations(OrganizationFilter filter) {
        return organizationRepository.findAll(PageRequest.of(filter.getPage(), filter.getPerPage()));
    }


    public Organization createOrUpdateOrganization(OrganizationCreateUpdateRequest organizationCreateUpdateRequest, @Nullable Organization existingOrganization) throws SameNamedOrganizationExistsException {
        Organization organization = (existingOrganization == null) ? create(organizationCreateUpdateRequest) : update(organizationCreateUpdateRequest, existingOrganization);
        if (organizationCreateUpdateRequest.getUserId() != null && organizationCreateUpdateRequest.getRoleId() != null)
            organizationHelper.processUserRole(organization.getOrgId(), organizationCreateUpdateRequest.getUserId(), organizationCreateUpdateRequest.getRoleId());
        return organization;
    }


    public Organization saveOrUpdateOrgContacts(ContactInfoDTO contactInfoDTO) {
        Organization organization = organizationHelper.processOrganizationContactInfo(organizationRepository.getById(contactInfoDTO.getOrganizationId()), contactInfoDTO);
        return organizationRepository.save(organization);
    }

    public Organization saveOrUpdateOrgType(BuyerSettingDTO buyerSettingDTO) {
        Organization organization = organizationHelper.getOrganizationById(buyerSettingDTO.getOrgId());
        organization.setOrgType(buyerSettingDTO.getBuyerType());
        organization.setLastModifiedTime(new Date());
        return organizationRepository.save(organization);
    }

    public List<BaseOrganizationDTO> getOrganizationDTOList(long userId) {
        List<UserRoles> userRoles = userRoleRepository.findAllByUserIdOrderByCreatedTimeDesc(userId, Pageable.unpaged()).getContent();
        if (!userRoles.isEmpty()) {
            return userRoles.stream().map(
                    userRole -> {
                        Organization organization = organizationRepository.findById(userRole.getOrgId()).get();
                        return BaseOrganizationDTO.builder()
                                .id(organization.getOrgId())
                                .orgName(organization.getOrgName())
                                .orgDescription(organization.getOrgDescription())
                                .orgType(organization.getBuyerType())
                                .orgStatus(organization.getOrgStatus())
                                .roleId(userRole.getRole().getId())
                                .roleName(userRole.getRole().getName())
                                .build();
                    }
            ).collect(Collectors.toList());
        }
        return List.of();
    }

    private Organization create(OrganizationCreateUpdateRequest organizationCreateUpdateRequest) throws SameNamedOrganizationExistsException {
        Organization organization = organizationHelper.prepareOrganization(new Organization(), organizationCreateUpdateRequest);
        organization.setOrgStatus(Organization.Status.APPROVED.getVal());
        organization.setCreatedTime(new Date());
        organization.setOrgCreatorId(organizationCreateUpdateRequest.getCreatedBy());
        organization.setBuyer(organizationCreateUpdateRequest.getIsBuyer());
        organization.setSeller(organizationCreateUpdateRequest.getIsSeller());
        return organizationRepository.save(organization);
    }

    private Organization update(OrganizationCreateUpdateRequest organizationCreateUpdateRequest, Organization existingOrganization) throws SameNamedOrganizationExistsException {
        Organization organization = organizationHelper.prepareOrganization(existingOrganization, organizationCreateUpdateRequest);
        if (organizationCreateUpdateRequest.getStatus() != null && organizationCreateUpdateRequest.getStatus() != existingOrganization.getOrgStatus())
            organization.setOrgStatus(organizationCreateUpdateRequest.getStatus());

        if (organizationCreateUpdateRequest.getIsSeller() != null
                && organizationCreateUpdateRequest.getIsSeller() != organization.isSeller())
            organization.setSeller(organizationCreateUpdateRequest.getIsSeller());

        if (organizationCreateUpdateRequest.getIsBuyer() != null
                && organizationCreateUpdateRequest.getIsBuyer() != organization.isBuyer())
            organization.setBuyer(organizationCreateUpdateRequest.getIsBuyer());

        organization.setLastModifiedTime(new Date());
        return organizationRepository.save(organization);
    }

    public String processUserRoleRequest(Long orgId, Long userId, Long roleId) {
        if (!doesUserExistWithinThisOrganization(orgId, userId)) {
            addUserToOrganization(orgId, userId);
        }
        return addOrRemoveRole(orgId, userId, roleId);
    }

    public String addOrRemoveRole(Long orgId, Long userId, Long roleId) {
        if (roleId == 0) {    //deletes userRole
            if (organizationHelper.getUserRoleByUserIdAndOrgId(orgId, userId) == null) {
                return "User role record does not exist and can not be removed!";
            }
            removeUserRoleFromOrganization(userId, orgId);
            return "User role removed.";
        } else {              //add or update user Role
            assignUserRoleToOrganization(orgId, userId, roleId);
            return "User role updated.";
        }
    }

    public UserRoles assignUserRoleToOrganization(Long orgId, Long userId, Long roleId) {
        System.out.println("updating " + orgId + ", " + userId + ", " + roleId);
        return organizationHelper.processUserRole(orgId, userId, roleId);
    }

    public void removeUserRoleFromOrganization(Long userId, Long orgId) {
        UserRoles userRoles = organizationHelper.getUserRoleByUserIdAndOrgId(orgId, userId);
        userRoleRepository.delete(userRoles);
    }

    public Page<User> getAllOrganizationUsers(long orgId, Pageable pageable) {
        Organization organization = organizationHelper.getOrganizationById(orgId);
        if (organization != null)
            return organizationUserRepository.findUsersOrgId(orgId, pageable);
        return null;
    }

    public Page<User> getOrganizationUsersWithMatchingName(String keywords, long orgId, Pageable pageable) {
        Organization organization = organizationHelper.getOrganizationById(orgId);
        if (organization != null)
            return organizationUserRepository.findUsersBySearchKeyAndOrgId(keywords, orgId, pageable);
        return null;
    }

    public OrganizationUsers addUserToOrganization(long orgId, long userId) {
        if (doesUserExistWithinThisOrganization(orgId, userId))
            return null;
        Organization organization = organizationHelper.getOrganizationById(orgId);
        User user = userRepository.findUserById(userId);
        if (organization == null || user == null)
            return null;
        OrganizationUsers organizationUsers = OrganizationUsers.builder().user(user).orgId(orgId).createdTime(new Date()).build();
        return organizationUserRepository.save(organizationUsers);
    }

    //todo:: after removing the user from the organization need to remove the role as well
    public boolean removeUserFromOrganization(long orgId, long userId) {
        OrganizationUsers organizationUsers = organizationUserRepository.findByOrgIdAndUserId(orgId, userId);
        if (organizationUsers == null)
            return false;
        organizationUserRepository.delete(organizationUsers);
        return true;
    }

    public boolean doesUserExistWithinThisOrganization(long orgId, long userId) {
        return organizationUserRepository.findByOrgIdAndUserId(orgId, userId) != null;
    }

}
