package com.dgmarket.notice.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Arrays;
import java.util.List;

@Entity
@Table(name = "regions")
@Data
public class Region {
    @Id
    private Long id;

    @Column(name = "region_code")
    private String regionCode;

    @Column(name = "name")
    private String name;

    @Column(name = "countries")
    private String countries; // Comma-separated list of country codes

    public List<String> countriesAsList() {
        return Arrays.asList(countries.split(","));
    }
}

