package com.dgmarket.auth.services;

import com.dgmarket.auth.entities.ResetPassword;
import com.dgmarket.auth.repositories.ResetPasswordRepository;
import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.core.config.Constants;
import com.dgmarket.core.dto.EmailRequestDTO;
import com.dgmarket.core.entities.EmailChannel;
import com.dgmarket.core.entities.EmailType;
import com.dgmarket.core.mail.MailUtility;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@AllArgsConstructor
public class ForgotPasswordService {

    private final Logger logger = LoggerFactory.getLogger(ForgotPasswordService.class);

    private final ResetPasswordRepository resetPasswordRepository;

    private final UserRepository userRepository;

    private final MailUtility mailUtility;

    public void storeTokenInDB(String email, String randomString) {
        if (userHasResetPasswordToken(email)) {
            updateDBEntry(randomString, userRepository.findByEmailIgnoreCase(email).getId());
            logger.info("database updated for email " + email + " random string token (length:30) " + randomString);
        } else {
            addDBEntry(randomString, email);
            logger.info("created entry in database for email " + email + " random string token (length:30) " + randomString);
        }
    }

    //todo:: move hardcoded strings to message.properties, when set up
    public void sendPasswordResetLinkOnMail(String email, String baseUrl) {
        logger.info("baseUrl modified to reset Link : " + baseUrl);
        String verificationUrl = generateTokenForUserEmailVerification(email, baseUrl);
        mailUtility.sendEmail(EmailRequestDTO.builder()
                .subject("Reset Your Password Here")
                .body(verificationUrl)
                .toAddresses(List.of(email))
                .emailChannel(EmailChannel.SMTP)
                .emailType(EmailType.targeted)
                .isHtml(false)
                .fromAddress(Constants.DG_DEFAULT_NOTIFICATION_EMAIL)
                .build());
        logger.info(" Reset Password link sent to the email : " + email);
    }

    private void updateDBEntry(String keyCode, Long userId) {
        resetPasswordRepository.findById(userId).ifPresent(resetPassword -> {
            resetPassword.setCode(keyCode);
            resetPassword.setResetDate(new Date());
            resetPasswordRepository.save(resetPassword);
        });
    }

    private void addDBEntry(String keyCode, String email) {
        ResetPassword resetPassword = new ResetPassword();
        resetPassword.setUserId(userRepository.findByEmailIgnoreCase(email).getId());
        resetPassword.setCode(keyCode);
        resetPassword.setResetDate(new Date());
        resetPasswordRepository.save(resetPassword);
    }

    private boolean userHasResetPasswordToken(String email) {
        logger.info("email : " + email);
        return resetPasswordRepository.findById(userRepository.findByEmailIgnoreCase(email).getId()).isPresent();
    }

    private String generateTokenForUserEmailVerification(String email, String resetPasswordUrl) {
        String randomString = RandomStringUtils.randomAlphanumeric(30);
        logger.info("random String token generated " + randomString);
        resetPasswordUrl += "?token=" + randomString;
        storeTokenInDB(email, randomString);
        return resetPasswordUrl;
    }

}
