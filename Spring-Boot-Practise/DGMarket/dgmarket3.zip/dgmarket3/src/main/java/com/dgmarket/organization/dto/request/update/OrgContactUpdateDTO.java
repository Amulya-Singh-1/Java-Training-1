package com.dgmarket.organization.dto.request.update;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
public class OrgContactUpdateDTO {

    @NotNull
    private Long orgId;
    private String firstName;
    private String lastName;
    private String address;
    private String city;
    private String state;
    private String country;
    @Digits(integer = 16, fraction = 0)
    @NotBlank(message = "phone number should not be blank")
    private String phone;
    private String fax;
    @Email
    @NotBlank(message = "email should not be blank")
    private String email;
    private String website;
}
