package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.FundingAgency;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FundingAgencyRepository extends JpaRepository<FundingAgency,Integer> {
    List<FundingAgency> findAll();
}
