package com.dgmarket.web.controller;

import com.dgmarket.web.dto.request.SaveFaqRequest;
import com.dgmarket.web.dto.request.UpdateFAQRequest;
import com.dgmarket.web.entities.FaqItems;
import com.dgmarket.web.services.FaqItemsService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/faq")
public class FaqController {

    private final FaqItemsService faqItemsService;

    // TODO: Do after...
    @PostMapping("/")
    public ResponseEntity<?> saveFaq(@Valid @RequestBody SaveFaqRequest saveFaqRequest) {
            return ResponseEntity.ok().body(saveFaqRequest + "\n" + " is saved in DB");
    }

    // TODO: Do after...
    @PutMapping("/")
    public ResponseEntity<?> updateFaq(@Valid @RequestBody UpdateFAQRequest updateFaqRequest) {
            return ResponseEntity.ok().body(updateFaqRequest + "\n" + "is updated");
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> findFaqTypeByParam(@PathVariable("id") Long id) {
        final Map<String, Object> body = new HashMap<>();
        List<FaqItems> faqItemsList = faqItemsService.findFaqItemsByFaqId(id);
        if(!(faqItemsList.isEmpty())){
            body.put("status", HttpServletResponse.SC_OK);
            body.put("faqList", faqItemsService.getFaqDTOListFromFaqItemsList(faqItemsList));
            return ResponseEntity.ok().body(body);

        }
        body.put("status", HttpServletResponse.SC_BAD_REQUEST);
        body.put("message", "Faq List not found");
        return ResponseEntity.badRequest().body(body);
    }

}






