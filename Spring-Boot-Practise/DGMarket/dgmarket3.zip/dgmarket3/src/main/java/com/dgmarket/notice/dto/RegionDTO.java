package com.dgmarket.notice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class RegionDTO {
    private String code;
    private String displayName;
    private List<String> countries;

    public static RegionDTO fromRegionDB(com.dgmarket.notice.entities.Region regionDB) {
        return new RegionDTO(regionDB.getRegionCode(), regionDB.getName(), regionDB.countriesAsList());
    }
}