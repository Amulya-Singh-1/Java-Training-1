package com.dgmarket.sibutu.controllers;

import com.dgmarket.notice.entities.Notice;
import com.dgmarket.notice.service.NoticeService;
import com.dgmarket.sibutu.dto.request.SibutuTeamRequest;
import com.dgmarket.sibutu.dto.request.SibutuTeamUpdateRequest;
import com.dgmarket.sibutu.dto.response.SibutuResponse;
import com.dgmarket.sibutu.filters.SibutuTeamSearchFilter;
import com.dgmarket.sibutu.services.SibutuTeamService;
import com.dgmarket.user.entities.User;
import com.dgmarket.user.services.UserService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
@RestController
@RequestMapping("/api/team")
public class SibutuTeamController {
    private final SibutuTeamService sibutuTeamService;
    private final UserService userService;
    private final NoticeService noticeService;

    @PostMapping("")
    public ResponseEntity<?> saveSibutuTeam(@RequestBody SibutuTeamRequest[] sibutuTeamRequests) {
        final Map<String, Object> body = new HashMap<>();
        if (sibutuTeamRequests.length < 1) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Request BOdy is empty.");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        for (SibutuTeamRequest sibutuTeamRequest : sibutuTeamRequests) {
            Notice notice = noticeService.findById(sibutuTeamRequest.getNoticeId());
            User user = userService.getUserById(sibutuTeamRequest.getUserId());


            if (user == null) {
                body.put("status", HttpServletResponse.SC_BAD_REQUEST);
                body.put("error", "User Id " + sibutuTeamRequest.getUserId() + " is not found and hence not saved.");
            }
            if (notice == null) {
                body.put("status", HttpServletResponse.SC_BAD_REQUEST);
                body.put("error", "Notice Id " + sibutuTeamRequest.getNoticeId() + " is not found and hence not saved.");
            }
            if (user != null && notice != null) {
                if (sibutuTeamService.sibutuTeamExists(sibutuTeamRequest)) {
                    body.put("status", HttpServletResponse.SC_CONFLICT);
                    body.put("conflict", sibutuTeamRequest + " already exists.");
                }
                sibutuTeamService.saveSibutuTeam(sibutuTeamRequest);
                body.put("status", HttpServletResponse.SC_CREATED);
                body.put("message", "User Id " + sibutuTeamRequest.getUserId() + " is saved successfully.");
            }

        }
        return ResponseEntity.ok(body);
    }

    @GetMapping("")
    public ResponseEntity<?> sibutuTeams(SibutuTeamSearchFilter sibutuTeamSearchFilter) {
        final Map<String, Object> body = new HashMap<>();

        List<SibutuResponse> sibutuResponseList = sibutuTeamService.searchByFilter(sibutuTeamSearchFilter);
        if (sibutuResponseList.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", sibutuResponseList);
        return ResponseEntity.ok(body);
    }

    @PutMapping("")
    public ResponseEntity<?> updateTeams(@RequestBody SibutuTeamUpdateRequest[] sibutuTeamUpdateRequests) {
        final Map<String, Object> body = new HashMap<>();
        if (sibutuTeamUpdateRequests.length < 1) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Request is empty.");

        }
        String response = " is updated.";

        for (SibutuTeamUpdateRequest sibutuTeamUpdateRequest : sibutuTeamUpdateRequests) {
            if (sibutuTeamService.sibutuTeamExists(sibutuTeamUpdateRequest.getId())) {
                sibutuTeamService.updateSibutuTeam(sibutuTeamUpdateRequest);
                response = sibutuTeamUpdateRequest.getId() + "  " + response;
                body.put("status", HttpServletResponse.SC_OK);
                body.put("message", response);
            }
        }
        return ResponseEntity.ok(body);
    }
}
