package com.dgmarket.organization.controllers;

import com.dgmarket.exception.SameNamedOrganizationExistsException;
import com.dgmarket.organization.dto.filters.OrganizationFilter;
import com.dgmarket.organization.dto.request.BuyerSettingDTO;
import com.dgmarket.organization.dto.request.ContactInfoDTO;
import com.dgmarket.organization.dto.request.OrganizationCreateUpdateRequest;
import com.dgmarket.organization.dto.response.OrganizationListItemDTO;
import com.dgmarket.organization.dto.response.OrganizationListResponse;
import com.dgmarket.organization.dto.response.OrganizationParents;
import com.dgmarket.organization.dto.response.OrganizationTreeResponse;
import com.dgmarket.organization.entities.Organization;
import com.dgmarket.organization.entities.OrganizationUsers;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.organization.services.OrganizationService;
import com.dgmarket.user.dto.filter.UserFilter;
import com.dgmarket.user.services.UserService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/organization")
@AllArgsConstructor
public class OrganizationController {
    private static final Logger logger = LoggerFactory.getLogger(OrganizationController.class);

    private final OrganizationService organizationService;
    private final OrganizationHelper organizationHelper;
    private final UserService userService;

    @GetMapping("")
    public ResponseEntity<?> getOrganizationList(OrganizationFilter filter) {
        OrganizationListResponse organizationListResponse = organizationService.prepareAllOrganizationList(filter);
        if (organizationListResponse.getOrganizationList() == null) {
            logger.warn("No Organization found, organization list is empty for organization list api");
            return ResponseEntity.ok().body(organizationListResponse);
        } else {
            logger.info("fetched list of organization from database. for Organization list api");
            return ResponseEntity.ok().body(organizationListResponse);
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> getOrganizationDetails(@PathVariable("id") Long id) {
        final Map<String, Object> body = new HashMap<>();
        Organization Organization = organizationHelper.getOrganizationById(id);
        if (Organization == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", " Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        } else {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("organization", Organization);
            return ResponseEntity.ok(body);
        }
    }

    @GetMapping("{id}/children")
    public ResponseEntity<?> getOrgnaizationChildTree(@PathVariable("id") Long id) {
        final Map<String, Object> body = new HashMap<>();
        OrganizationTreeResponse Organization = organizationHelper.getOrganizationChildTree(id);
        if (Organization == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", " Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        } else {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("organization", Organization);
            return ResponseEntity.ok(body);
        }
    }

    @GetMapping("{id}/children/details")
    public ResponseEntity<?> getOrgnaizationChildTreeDetails(@PathVariable("id") Long id) {
        final Map<String, Object> body = new HashMap<>();
        OrganizationListItemDTO Organization = organizationHelper.getOrganizationWithChildren(id);
        if (Organization == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", " Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        } else {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("organization", Organization);
            return ResponseEntity.ok(body);
        }
    }

    @PostMapping("")
    public ResponseEntity<?> createOrganization(@Valid @RequestBody OrganizationCreateUpdateRequest organizationCreateRequest) {
        final Map<String, Object> body = new HashMap<>();

        if (organizationCreateRequest.getUserId() != null && organizationHelper.hasIncompleteOrganization(organizationCreateRequest.getUserId())) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Incomplete Organization found , complete details of previous organization before creating a new one.");
            return ResponseEntity.status(HttpServletResponse.SC_BAD_REQUEST).body(body);
        }

        try {
            Organization organization = organizationService.createOrUpdateOrganization(organizationCreateRequest, null);
            body.put("status", HttpServletResponse.SC_CREATED);
            body.put("message", "organization saved !!");
            body.put("orgId", organization.getOrgId());
            return ResponseEntity.ok(body);
        } catch (SameNamedOrganizationExistsException oe) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "Organization with same name already exist");
            return ResponseEntity.status(HttpServletResponse.SC_CONFLICT).body(body);
        }
    }

    @PutMapping("{id}")
    public ResponseEntity<?> updateOrganization(@PathVariable("id") Long id, @Valid @RequestBody OrganizationCreateUpdateRequest organizationUpdateRequest) {
        final Map<String, Object> body = new HashMap<>();

        Organization organization = organizationHelper.getOrganizationById(id);
        if (organization == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        } else {
            logger.info("updating organization");
            try {
                organizationService.createOrUpdateOrganization(organizationUpdateRequest, organization);
                body.put("status", HttpServletResponse.SC_OK);
                body.put("message", "organization updated !!");
                return ResponseEntity.ok(body);
            } catch (SameNamedOrganizationExistsException oe) {
                body.put("status", HttpServletResponse.SC_CONFLICT);
                body.put("message", "Organization with same name already exist");
                return ResponseEntity.status(HttpServletResponse.SC_CONFLICT).body(body);
            }
        }
    }

    @PostMapping("/contacts")
    public ResponseEntity<?> saveContacts(@Valid @RequestBody ContactInfoDTO contactInfoDTO) {
        final Map<String, Object> body = new HashMap<>();
        if (organizationHelper.getOrganizationById(contactInfoDTO.getOrganizationId()) == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        organizationService.saveOrUpdateOrgContacts(contactInfoDTO);
        body.put("status", HttpServletResponse.SC_OK);
        body.put("message", "organization contacts updated !!");
        return ResponseEntity.ok(body);
    }

    @PostMapping("/buyerType")
    public ResponseEntity<?> saveOrganizationType(@Valid @RequestBody BuyerSettingDTO buyerSettingDTO) {
        final Map<String, Object> body = new HashMap<>();

        Organization organization = organizationHelper.getOrganizationById(buyerSettingDTO.getOrgId());
        if (organization == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        if (organization.getOrgType() == buyerSettingDTO.getBuyerType()) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "organization type is already the same !!");
        } else {
            organizationService.saveOrUpdateOrgType(buyerSettingDTO);
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "organization type is updated !!");
        }
        return ResponseEntity.ok(body);
    }


    @GetMapping("{orgId}/users")
    public ResponseEntity<?> getUsersForOrganization(@PathVariable("orgId") Long orgId, String keyword) {
        final Map<String, Object> body = new HashMap<>();
        if (organizationHelper.getOrganizationById(orgId) == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("users", userService.getUserListDTO(UserFilter.builder()
                .orgId(orgId)
                .keyword(keyword)
                .build()));
        return ResponseEntity.ok(body);
    }

    @PostMapping("{orgId}/users")
    public ResponseEntity<?> addUserToOrganizaton(@PathVariable("orgId") Long orgId, long userId) {
        final Map<String, Object> body = new HashMap<>();
        if (organizationHelper.getOrganizationById(orgId) == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        if (userService.getUserById(userId) == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }

        if (organizationService.doesUserExistWithinThisOrganization(orgId, userId)) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "User is already present in Organization");
            return ResponseEntity.status(HttpServletResponse.SC_CONFLICT).body(body);
        }
        OrganizationUsers organizationUsers = organizationService.addUserToOrganization(orgId, userId);
        body.put("status", HttpServletResponse.SC_CREATED);
        body.put("user_organization", organizationUsers);
        return ResponseEntity.ok(body);
    }

    @DeleteMapping("{orgId}/users")
    public ResponseEntity<?> removeUserFromOrganizaton(@PathVariable("orgId") Long orgId, long userId) {
        final Map<String, Object> body = new HashMap<>();
        if (organizationHelper.getOrganizationById(orgId) == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        if (userService.getUserById(userId) == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }

        if (!organizationService.doesUserExistWithinThisOrganization(orgId, userId)) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "User is not present in Organization");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        if (organizationService.removeUserFromOrganization(orgId, userId)) {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "User is removed from the organization");
            return ResponseEntity.ok(body);
        } else {
            body.put("status", HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            body.put("message", "Server Error!");
            return ResponseEntity.status(HttpServletResponse.SC_INTERNAL_SERVER_ERROR).body(body);
        }
    }

    //TODO:: fix the flow.. does the work.. but must need rework
    @PostMapping("/role")
    public ResponseEntity<?> assignUserRole(Long orgId, Long[] userId, Long roleId) {
        final Map<String, Object> body = new HashMap<>();
        if (orgId == null || organizationHelper.getOrganizationById(orgId) == null) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Invalid orgId!!");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        if (roleId == null || roleId < 0 || roleId > 4) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Invalid Role Id.");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        if (ArrayUtils.isEmpty(userId)) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "At least one User is required.");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        for (Long id : userId) {
            if (userService.getUserById(id) == null) {
                body.put("status", HttpServletResponse.SC_BAD_REQUEST);
                body.put("message", "Invalid user id");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
            }
            body.put("message", organizationService.processUserRoleRequest(orgId, id, roleId));
        }
        body.put("status", HttpServletResponse.SC_OK);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/userRoles")
    public ResponseEntity<?> getUserRolesByOrgId(Long orgId) {
        final Map<String, Object> body = new HashMap<>();
        if (userService.getUserRolesByOrgId(orgId).isEmpty()) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "No users are available for the given org Id.");
            return ResponseEntity.status(HttpServletResponse.SC_BAD_REQUEST).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", userService.getUserRolesByOrgId(orgId));
        return ResponseEntity.ok(body);
    }

    @GetMapping("/generations")
    public ResponseEntity<?> getAllParentsByChildId(Long childId) {
        final Map<String, Object> body = new HashMap<>();
        List<OrganizationParents> parents = new ArrayList<>();
        if (!organizationHelper.hasParentOrg(childId)) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "No parent organization exists for the given organization Id.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        organizationHelper.processParents(organizationHelper.getOrganizationById(childId), parents, childId);
        body.put("response", parents);
        return ResponseEntity.status(HttpServletResponse.SC_OK).body(body);
    }
}
