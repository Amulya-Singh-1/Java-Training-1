package com.dgmarket.web.services;

import com.dgmarket.notice.dto.CategoryDTO;
import com.dgmarket.notice.entities.Category;
import com.dgmarket.notice.repositories.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryService {

    final private CategoryRepository categoryRepository;

    public List<CategoryDTO> topCategories() {
        Pageable pageable = PageRequest.of(0, 8, Sort.by("id"));
        Page page = categoryRepository.findAll(pageable);
        List<CategoryDTO> dtoList = new ArrayList<>();
        page.stream().forEach(e -> dtoList.add(new CategoryDTO(((Category) e).getId(), ((Category) e).getCategoryName())));
        return dtoList;
    }
}
