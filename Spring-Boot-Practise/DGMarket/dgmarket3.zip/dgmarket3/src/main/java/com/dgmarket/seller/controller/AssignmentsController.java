package com.dgmarket.seller.controller;

import com.dgmarket.seller.dto.request.AssignmentsRequest;
import com.dgmarket.seller.entities.Assignments;
import com.dgmarket.seller.services.AssignmentsService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/assignments")
public class AssignmentsController {

    private final AssignmentsService assignmentsService;

    @GetMapping("")
    public ResponseEntity<?> findByFilter(Assignments assignments) {
        final Map<String, Object> body = new HashMap<>();
        List<Assignments> assignmentsList = assignmentsService.findByFilter(assignments);
        if (assignmentsList.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Assignment list Not found.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("assignmentList", assignmentsList);
        return ResponseEntity.ok(body);
    }

    @PostMapping("")
    public ResponseEntity<?> addAssignments(@RequestBody @Valid AssignmentsRequest assignmentsRequest) {
        final Map<String, Object> body = new HashMap<>();

        Assignments assignments = assignmentsService.addAssignments(assignmentsRequest);
        if (assignments != null) {
            body.put("status", HttpServletResponse.SC_CREATED);
            body.put("message", "Assignments added successfully.");
            return ResponseEntity.status(HttpServletResponse.SC_CREATED).body(body);
        }
        body.put("status", HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        body.put("message", "Assignments not saved.");
        return ResponseEntity.ok(body);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateAssignments(@PathVariable(name = "id") Long assignmentsId, @RequestBody AssignmentsRequest assignmentsRequest){
        final Map<String, Object> body = new HashMap<>();
        Assignments assignments = assignmentsService.findAssignmentsById(assignmentsId);
        if(assignments != null && assignmentsService.propagateAssignmentsAndUpdate(assignments, assignmentsRequest) != null){
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "Assignments updated successfully !!.");
            return ResponseEntity.ok().body(body);
        }
        body.put("status", HttpServletResponse.SC_BAD_REQUEST);
        body.put("message", "Assignments is not found for the given id !!.");
        return ResponseEntity.badRequest().body(body);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteAssignmentsById(@PathVariable(name = "id") Long assignmentsId){
        final Map<String, Object> body = new HashMap<>();

        if(assignmentsService.findAssignmentsById(assignmentsId) == null){
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Assignments is not found for the given id !!.");
            return ResponseEntity.badRequest().body(body);
        }
        assignmentsService.deleteAssignments(assignmentsId);
        body.put("status", HttpServletResponse.SC_OK);
        body.put("message", "Assignments deleted successfully !!.");
        return ResponseEntity.ok().body(body);
    }

}
