package com.dgmarket.core.repositories;

import com.dgmarket.core.entities.EmailLog;
import com.dgmarket.core.entities.EmailType;
import org.springframework.data.repository.CrudRepository;

import java.util.Date;

public interface EmailLogRepository extends CrudRepository<EmailLog, Long> {
    int countByRecipientAndTimeSentAfterAndEmailType(String email, Date time, EmailType emailType);
}
