package com.dgmarket.organization.dto.response;

import com.dgmarket.organization.entities.Organization;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrganizationListItemDTO extends BaseOrganizationDTO{
    private String orgAddress;
    private String orgCity;
    private String orgState;
    private String orgCountry;
    private String countryOperation;
    private String orgLanguage;
    private String orgPhone;
    private String orgWebsite;
    private Long orgParentId;
    private boolean isBuyer;
    private boolean isSeller;

    private List<OrganizationListItemDTO> childOrganizations = new ArrayList<>();

    public OrganizationListItemDTO getDTOFromEntity(Organization org){
        OrganizationListItemDTO itemDTO = new OrganizationListItemDTO();
        itemDTO.setId(org.getOrgId());
        itemDTO.setOrgType(org.getBuyerType());
        itemDTO.orgName=(org.getOrgName());
        itemDTO.orgDescription=(org.getOrgDescription());
        itemDTO.orgAddress=(org.getOrgAddress());
        itemDTO.orgCity=(org.getOrgCity());
        itemDTO.orgState=(org.getOrgState());
        itemDTO.orgCountry=(org.getOrgCountry());
        itemDTO.countryOperation=(org.getCountryOperation());
        itemDTO.orgLanguage=(org.getOrgLanguage());
        itemDTO.orgPhone=(org.getOrgPhone());
        itemDTO.orgWebsite=(org.getOrgWebsite());
        itemDTO.orgParentId=(org.getOrgParentId());
        itemDTO.orgStatus=(org.getOrgStatus());
        itemDTO.isBuyer=(org.isBuyer());
        itemDTO.isSeller=(org.isSeller());
        return itemDTO;
    }

    public void addChildOrg(OrganizationListItemDTO child){
        this.childOrganizations.add(child);
    }
}
