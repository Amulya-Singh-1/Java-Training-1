package com.dgmarket.notice.dto.request;

import lombok.Builder;
import lombok.Data;
import org.springframework.lang.Nullable;

import javax.persistence.Column;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@Builder
public class CreateNoticeRequest {

    @NotNull(message = "User id should not be blank")
    private Long userId;

    @NotNull(message = "Org id should not be blank")
    private Long orgId;

    @NotBlank(message = "Notice title should not be blank")
    private String noticeTitle;

    @NotBlank(message = "Language should not be blank")
    private String language;

    @NotNull(message = "Country should not be blank")
    private String country;

    @Nullable
    private List<String> fundingAgency;

    @NotBlank(message = "City should not be blank")
    private String city;

    @NotBlank(message = "Notice type should not be blank")
    private String type;

    @NotBlank(message = "Estimated value should not be blank")
    private String estimatedValue;

    @NotBlank(message = "Estimated value currency should not be blank")
    private String estimatedValueCurrency;

    @NotBlank(message = "Contract number should not be blank")
    private String contractNumber;

    @NotBlank(message = "Method of procurement should not be blank")
    private String methodOfProcurement;

    private String minEligibilityOfBidders;

    private String deadline;

    private Boolean publishedOnSibutu;

    private String noticeStatus;

    private String documentFee;

    private String completedSteps;

}
