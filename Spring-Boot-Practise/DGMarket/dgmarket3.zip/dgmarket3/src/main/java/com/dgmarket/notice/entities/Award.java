package com.dgmarket.notice.entities;

import com.dgmarket.organization.entities.Organization;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

import javax.persistence.*;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@Data
@Table(name = "award_informations")
@ToString
public class Award {
    @Column(name = "id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Id;

    private String bidderName;
    private String address;
    private String initialEstimatedValue;
    private String finalEstimatedValue;
    private String bidRecieved;
    private String contractDuration;
    private Date awardDate;
    @OneToOne
    @JoinColumn(name = "org_id")
    @JsonIgnore
    private Organization orgId;
    private Integer status;

}
