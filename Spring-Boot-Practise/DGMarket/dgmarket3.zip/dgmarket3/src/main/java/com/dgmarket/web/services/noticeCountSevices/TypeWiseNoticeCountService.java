package com.dgmarket.web.services.noticeCountSevices;

import com.dgmarket.web.entities.views.TypeWiseNoticeCount;
import com.dgmarket.web.repositories.TypeWiseNoticeCountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class TypeWiseNoticeCountService {

    private TypeWiseNoticeCountRepository typeWiseNoticeCountRepository;

    public List<TypeWiseNoticeCount> findAllTypeWise(){
        return typeWiseNoticeCountRepository.findAll();
    }
    public List<TypeWiseNoticeCount> findAllTypeWiseByName(String name){
        return typeWiseNoticeCountRepository.findAllByNameContainingIgnoreCase(name);
    }
}
