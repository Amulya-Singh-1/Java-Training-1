package com.dgmarket.auth.dto.request;

import com.dgmarket.auth.securities.constriant.ValidPassword;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ChangePasswordRequest {

    @NotNull(message = "User id should not be blank")
    private Long id;

    @NotBlank(message = "Current Password should not be blank")
    @Size(min = 8, max = 40)
    @ValidPassword
    private String currentPassword;

    @NotBlank(message = "Password should not be blank")
    @Size(min = 8, max = 40)
    @ValidPassword
    private String password;

    @NotBlank(message = "Confirm password should not be blank")
    @Size(min = 8, max = 40)
    @ValidPassword
    private String confirmPassword;

}
