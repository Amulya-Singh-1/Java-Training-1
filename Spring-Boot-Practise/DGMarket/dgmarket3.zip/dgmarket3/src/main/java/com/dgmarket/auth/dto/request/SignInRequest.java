package com.dgmarket.auth.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SignInRequest {
    @NotBlank(message = "Email should not be blank")
    private String email;

    @NotBlank(message = "Password is missing")
    private String password;

    @NotBlank(message = "Captcha should not be blank")
    private String captchaText;
}