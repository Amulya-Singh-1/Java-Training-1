package com.dgmarket.web.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.stream.Stream;

@RequiredArgsConstructor
public enum Category {

    PROBLEM("Problem"),
    SUGGESTION("Suggestion"),
    QUESTION("Question"),
    OTHERS("Other");

    @Getter
    private final String id;

    public static Category fromId(String id) {
        return Stream.of(Category.values()).filter(targetEnum -> targetEnum.id.equals(id)).findFirst().orElse(null);
    }

}



