package com.dgmarket.organization.entities;

import com.dgmarket.organization.dto.response.DraftOrganizatonListItemDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.*;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.*;
import java.util.Date;

@Table(name = "organizations_draft")
@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DraftOrganization {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "org_id")
    private Long organizationId;
    private String orgName;
    private Long userId;
    private boolean isBuyer;
    private boolean isSeller;
    private int orgStatus;
    private Date createdTime;

    public enum Status {
        DRAFT(0), APPROVED(1), REJECTED(2), SUSPENDED(3);
        int val;

        Status(int _val) {
            this.val = _val;
        }

        public int getVal() {
            return this.val;
        }
    }

    public DraftOrganizatonListItemDTO toDTO(String email, String name) {
        return DraftOrganizatonListItemDTO.builder()
                .organizationId(this.organizationId)
                .orgName(this.orgName)
                .orgStatus(this.orgStatus)
                .createdTime(this.createdTime)
                .isBuyer(this.isBuyer)
                .isSeller(this.isSeller)
                .userId(this.userId)
                .userName(name)
                .userEmail(email)
                .build();
    }
}
