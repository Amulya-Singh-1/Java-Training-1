package com.dgmarket.seller.services;

import com.dgmarket.notice.service.FundingAgencyService;
import com.dgmarket.seller.dto.request.AssignmentsRequest;
import com.dgmarket.seller.entities.Assignments;
import com.dgmarket.seller.repositories.AssignmentsRepository;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class AssignmentsService {

    private final AssignmentsRepository assignmentsRepository;
    private final FundingAgencyService fundingAgencyService;

    public Assignments addAssignments(AssignmentsRequest assignmentsRequest) {
        return assignmentsRepository.save(Assignments.builder()
                .orgId(assignmentsRequest.getOrgId())
                .assignmentTitle(assignmentsRequest.getAssignmentTitle())
                .projectTitle(assignmentsRequest.getProjectTitle())
                .contractNumber(assignmentsRequest.getContractNumber())
                .country(assignmentsRequest.getAssignmentCountry())
                .clientName(assignmentsRequest.getClientName())
                .startDate(assignmentsRequest.getStartDate())
                .endDate(assignmentsRequest.getEndDate())
                .staffMonths(assignmentsRequest.getStaffMonths())
                .contractValue(assignmentsRequest.getContractNumber())
                .fundingAgency(fundingAgencyService.findFundingAgencyById((assignmentsRequest.getFundedBy())))
                .description(assignmentsRequest.getDescription()).
            build());
    }

    public List<Assignments> findByFilter(Assignments assignments) {
       return assignmentsRepository.findAll().stream().
                filter(assign -> (assignments.getId() == null || (assignments.getId().equals(assign.getId())))
                        && (assignments.getOrgId() == null || (assignments.getOrgId().equals(assign.getOrgId())))
                        && (assignments.getAssignmentTitle() == null || (assignments.getAssignmentTitle().equals(assignments.getAssignmentTitle())))
                        && (assignments.getProjectTitle() == null || (assignments.getProjectTitle().equals(assign.getProjectTitle())))
                        && (assignments.getContractNumber() == null || (assignments.getContractNumber().equals(assign.getContractNumber())))
                        && (assignments.getCountry() == null || (assignments.getCountry().equals(assign.getCountry())))
                        && (assignments.getClientName() == null || (assignments.getClientName().equals(assign.getClientName())))
                        && (assignments.getStartDate() == null || (assignments.getStartDate().equals(assign.getStartDate())))
                        && (assignments.getEndDate() == null || (assignments.getEndDate().equals(assign.getEndDate())))
                        && (assignments.getStaffMonths() == null || (assignments.getStaffMonths().equals(assign.getStaffMonths())))
                        && (assignments.getContractValue() == null || (assignments.getContractValue().equals(assign.getContractValue())))
                        && (assignments.getFundingAgency() == null || (assignments.getFundingAgency().getId() == assign.getFundingAgency().getId()))
                ).collect(Collectors.toList());
    }

    public Assignments findAssignmentsById(Long assignmentsId) {
       return assignmentsRepository.findById(assignmentsId).orElse(null);
    }

    public boolean existAssignment(Long assignmentsId) {
        return assignmentsRepository.existsById(assignmentsId);
    }

    public void deleteAssignments(Long id) {
        assignmentsRepository.deleteById(id);
    }

    public Assignments propagateAssignmentsAndUpdate(Assignments assignments, AssignmentsRequest assignmentsRequest) {
       if(assignmentsRequest.getOrgId() != null)
           assignments.setOrgId(assignmentsRequest.getOrgId());
       if(StringUtils.isNotBlank(assignmentsRequest.getAssignmentTitle()))
           assignments.setAssignmentTitle(assignmentsRequest.getAssignmentTitle());
       if(StringUtils.isNotBlank(assignmentsRequest.getProjectTitle()))
           assignments.setProjectTitle(assignments.getProjectTitle());
       if(StringUtils.isNotBlank(assignmentsRequest.getContractNumber()))
           assignments.setContractNumber(assignmentsRequest.getContractNumber());
       if(StringUtils.isNotBlank(assignmentsRequest.getAssignmentCountry()))
           assignments.setCountry(assignmentsRequest.getAssignmentCountry());
       if(StringUtils.isNotBlank(assignmentsRequest.getClientName()))
           assignments.setClientName(assignmentsRequest.getClientName());
       if(assignmentsRequest.getStartDate() != null)
           assignments.setStartDate(assignmentsRequest.getStartDate());
       if(assignmentsRequest.getEndDate() != null)
           assignments.setEndDate(assignmentsRequest.getEndDate());
       if(StringUtils.isNotBlank(assignmentsRequest.getStaffMonths()))
           assignments.setStaffMonths(assignmentsRequest.getStaffMonths());
       if(StringUtils.isNotBlank(assignmentsRequest.getValueOfServices()))
           assignments.setContractValue(assignmentsRequest.getValueOfServices());
       if(assignmentsRequest.getFundedBy() != null)
           assignments.setFundingAgency(fundingAgencyService.findFundingAgencyById((assignmentsRequest.getFundedBy())));
       if(StringUtils.isNotBlank(assignmentsRequest.getDescription()))
           assignments.setDescription(assignmentsRequest.getDescription());
      return assignmentsRepository.save(assignments);
    }
}
