package com.dgmarket.organization.dto.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@Builder
public class DraftRejectionDTO {

    @NotNull(message = "Rejected organization Id should not be null")
    private Long orgId;
    @NotBlank(message = "A reason is required for the rejection")
    @Size(min = 10)
    private String reason;
    @NotNull(message = "Only Global Admin is authorized to reject an Organization")
    //Todo :: only for global admin currently
    @Digits(fraction = 0, integer = 1)
    private Long rejectedBy;

}
