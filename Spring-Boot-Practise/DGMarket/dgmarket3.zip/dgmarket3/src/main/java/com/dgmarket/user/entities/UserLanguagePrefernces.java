package com.dgmarket.user.entities;

import lombok.*;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Builder
@Entity
@Table(name = "dg_user_lang_preferences")
@NoArgsConstructor
@AllArgsConstructor
@ToString(of = {"userId"})
public class UserLanguagePrefernces {

    @Id
    @Column(name = "user_id")
    private Long userId;

    @Column(name = "site_id")
    private Long siteId;

    @Column(name = "alerts_language")
    private String alertsLanguage;

}
