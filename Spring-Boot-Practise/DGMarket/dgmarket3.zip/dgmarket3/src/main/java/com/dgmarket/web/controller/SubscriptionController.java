package com.dgmarket.web.controller;

import com.dgmarket.web.dto.request.SubscriptionRequest;
import com.dgmarket.web.entities.Subscription;
import com.dgmarket.web.services.SubscriptionService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/web/subscription")
public class SubscriptionController {
    private final SubscriptionService subscriptionService;

    @GetMapping("")
    public ResponseEntity<?> findByFilter(Subscription sub) {
        final Map<String, Object> body = new HashMap<>();
        List<Subscription> subscriptions = subscriptionService.findByFilter(sub);
        if (subscriptions.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not found.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", subscriptions);
        return ResponseEntity.ok(body);
    }

    @PostMapping("")
    public ResponseEntity<?> addSubscription(@RequestBody @Valid SubscriptionRequest subscriptionRequest) {
        final Map<String, Object> body = new HashMap<>();
        if (subscriptionService.existByOrgId(subscriptionRequest.getOrgId())) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "Subscription with Org Id already exists.");
            return ResponseEntity.status(HttpServletResponse.SC_CONFLICT).body(body);
        }
        Subscription subscription = subscriptionService.addSubscription(subscriptionRequest);

        if (subscription != null) {
            body.put("status", HttpServletResponse.SC_CREATED);
            body.put("message", "Subscription added successfully.");
            return ResponseEntity.status(HttpServletResponse.SC_CREATED).body(body);
        }
        body.put("status", HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        body.put("message", "Subscription is not saved.");
        return ResponseEntity.ok(body);
    }
}
