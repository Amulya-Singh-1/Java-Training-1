package com.dgmarket.notice.service;

import com.dgmarket.notice.dto.response.ProcurementMethodDTO;
import com.dgmarket.notice.entities.ProcurementMethods;
import com.dgmarket.notice.repositories.ProcurementMethodsRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class ProcurementMethodsService {

    private final ProcurementMethodsRepository procurementMethodsRepository;

    public List<ProcurementMethods> getProcurementMethodList() {
        return procurementMethodsRepository.findAll();
    }

    public ProcurementMethods findProcurementMethodById(Integer id) {
        return procurementMethodsRepository.getById(id);
    }

    public ProcurementMethodDTO propagateProcurementMethodDTO(ProcurementMethods procurementMethods){
        return ProcurementMethodDTO.builder()
                .id(procurementMethods.getId())
                .methodName(procurementMethods.getMethodName())
                .build();
    }

}
