package com.dgmarket.notice.helpers;

import com.dgmarket.common.dto.response.CountryDTO;
import com.dgmarket.common.entities.Country;
import com.dgmarket.common.services.CountryService;
import com.dgmarket.notice.dto.response.*;
import com.dgmarket.notice.entities.*;
import com.dgmarket.notice.repositories.CurrenciesRepository;
import com.dgmarket.notice.service.*;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.web.dto.response.LocaleDTO;
import com.dgmarket.web.entities.LocaleLanguage;
import com.dgmarket.web.services.LanguageService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class NoticeDetailsHelper {

    private final NoticeService noticeService;
    private final ProcurementMethodsService procurementMethodsService;
    private final NoticeContactsService noticeContactsService;
    private final NoticeDetailService noticeDetailService;
    private final OrganizationHelper organizationHelper;
    private final NoticeDocumentsService noticeDocumentsService;
    private final LanguageService languageService;
    private final CountryService countryService;
    private final NoticeCpvMappingService noticeCpvMappingService;
    private final CPVMasterService cpvMasterService;
    private final NoticeTypesService noticeTypesService;
    private final CurrenciesRepository currenciesRepository;
    private final NoticeFundingService noticeFundingService;

    public NoticeDetailDTO getNoticeDetailsDTOByNoticeId(Long noticeId) {
        Notice notice = noticeService.findById(noticeId);
        NoticeDetailDTO noticeDetailDTO = null;
        if(notice != null) {
            noticeDetailDTO = populateNoticeDetailDTOFromNotice(notice);
        }
        NoticeContacts noticeContacts = noticeContactsService.findNoticeContactByNoticeId(noticeId);
        if(noticeContacts != null){
            noticeDetailDTO = populateNoticeDetailDTOFromNoticeContacts(noticeDetailDTO, noticeContacts);
        }
        NoticeDetail noticeDetail = noticeDetailService.findNoticeDetailByNoticeId(noticeId);
        if(noticeDetail != null){
            noticeDetailDTO = populateNoticeDetailDTOFromNoticeDetails(noticeDetailDTO, noticeDetail);
        }
        List<NoticeDocuments> noticeDocumentsList = noticeDocumentsService.findNoticeDocumentsListByNoticeId(noticeId);
        if(!(noticeDocumentsList.isEmpty())){
            noticeDetailDTO.setNoticeDocuments(noticeDocumentsList);
        }
        List<NoticeCpvMapping> noticeCpvMappingList = noticeCpvMappingService.findNoticeCpvMappingListByNoticeId(noticeId);
        if(!(noticeCpvMappingList.isEmpty())){
            List<NoticeCpvMappingDTO> noticeCpvMappingDTOList = getNoticeCpvMappingDTOList(noticeCpvMappingList);
            if(!noticeCpvMappingDTOList.isEmpty())
                noticeDetailDTO.setNoticeCpvMappings(noticeCpvMappingDTOList);
        }
        List<NoticeFunding> noticeFundingList = noticeFundingService.findNoticeFundingListByNoticeId(noticeId);
        if(!noticeFundingList.isEmpty()){
           List<FundingAgency> fundingAgencyList = noticeFundingList.stream().map(e ->
                   e.getFundingAgency()).collect(Collectors.toList());
           noticeDetailDTO.setFundingAgency(fundingAgencyList);
        }
        return noticeDetailDTO;
    }

    public List<NoticeCpvMappingDTO> getNoticeCpvMappingDTOList(List<NoticeCpvMapping> noticeCpvMappingList) {
        List<NoticeCpvMappingDTO>  noticeCpvMappingDTOList = noticeCpvMappingList.stream()
                .map(this::populateNoticeCpvDTO)
                .collect(Collectors.toList());
        return noticeCpvMappingDTOList;
    }

    private NoticeCpvMappingDTO populateNoticeCpvDTO(NoticeCpvMapping noticeCpvMapping) {
       return NoticeCpvMappingDTO.builder()
                .id(noticeCpvMapping.getId())
                .code(cpvMasterService.findById(noticeCpvMapping.getCpvMaster()).getCode())
                .name(cpvMasterService.findById(noticeCpvMapping.getCpvMaster()).getName())
                .isPrimary(noticeCpvMapping.isPrimary())
                .build();
    }

    private NoticeDetailDTO populateNoticeDetailDTOFromNoticeDetails(NoticeDetailDTO noticeDetailDTO, NoticeDetail noticeDetail) {
        noticeDetailDTO.setOfficialText(noticeDetail.getOfficalText());
        noticeDetailDTO.setExternalUrl(noticeDetail.getExternalUrl());
        return noticeDetailDTO;
    }

    private NoticeDetailDTO populateNoticeDetailDTOFromNoticeContacts(NoticeDetailDTO noticeDetailDTO, NoticeContacts noticeContacts) {
        noticeDetailDTO.setTitle(noticeContacts.getTitle());
        noticeDetailDTO.setFirstName(noticeContacts.getFirstName());
        noticeDetailDTO.setLastName(noticeContacts.getLastName());
        noticeDetailDTO.setAddress(noticeContacts.getAddress());
        noticeDetailDTO.setContactCity(noticeContacts.getCity());
        noticeDetailDTO.setState(noticeContacts.getState());
        noticeDetailDTO.setPostalCode(noticeContacts.getPostalCode());
        noticeDetailDTO.setCountry(countryService.getCountryForId(noticeContacts.getCountry()).getCountryName());
        noticeDetailDTO.setPhone(noticeContacts.getPhone());
        noticeDetailDTO.setFax(noticeContacts.getFax());
        noticeDetailDTO.setEmail(noticeContacts.getEmail());
        noticeDetailDTO.setWebsite(noticeContacts.getWebsite());
        noticeDetailDTO.setOrgName(organizationHelper.getOrganizationById(noticeContacts.getOrgId()).getOrgName());
        return noticeDetailDTO;
    }

    public NoticeDetailDTO populateNoticeDetailDTOFromNotice(Notice notice) {
        return NoticeDetailDTO.builder()
                .id(notice.getId())
                .noticeNo(notice.getNoticeNo())
                .noticeType(getNoticeTypeResponse(notice.getNoticeType()))
                .noticeTitle(notice.getNoticeTitle())
                .mainLanguage(getLocaleDTO(notice.getMainLanguage()))
                .performanceCountry(getCountryDTO(notice.getPerformanceCountry()))
                .city(notice.getCity())
                .estimatedAmount(notice.getEstimatedAmount())
                .currency(getCurrencyDTO(notice.getCurrency()))
                .procurementMethod(getProcurementMethodDTO(notice.getProcurementMethod()))
                .qualification(notice.getQualification())
                .noticeDeadline(notice.getNoticeDeadline() != null ? notice.getNoticeDeadline().toString() : null)
                .publishDate(notice.getPublishDate().toString())
                .noticeSource(notice.getNoticeSource())
                .creator(notice.getCreator().getFullName())
                .isPublishOnSibutu(notice.isPublishOnSibutu())
                .status(notice.getStatus()==null?"":notice.getStatus().toString())
                .completedSteps(notice.getCompletedSteps() == null ? null : notice.getCompletedSteps().toString())
                .documentFee(notice.getDocumentFee())
                .build();
    }

    private CurrencyDTO getCurrencyDTO(String currencyCode) {
        Currencies currencies = currenciesRepository.getById(currencyCode);
        if(currencies != null)
            return CurrencyDTO.builder()
                    .code(currencies.getCode())
                    .name(currencies.getName())
                    .symbol(currencies.getSymbol())
                    .build();

        return null;
    }

    private NoticeTypesResponse getNoticeTypeResponse(NoticeTypes noticeType) {
        return noticeTypesService.propagateNoticeTypeDTO(noticeType);
    }

    private LocaleDTO getLocaleDTO(String mainLanguage) {
        LocaleLanguage localeLanguage = languageService.findLocaleLanguageById(mainLanguage);
        if(localeLanguage != null)
            return LocaleDTO.builder()
                    .code(localeLanguage.getCode())
                    .name(localeLanguage.getName())
                    .build();

        return null;
    }

    private ProcurementMethodDTO getProcurementMethodDTO(Integer procurementMethod) {
        ProcurementMethods procurementMethods = procurementMethodsService.findProcurementMethodById(procurementMethod);
        if(procurementMethods != null)
            return procurementMethodsService.propagateProcurementMethodDTO(procurementMethods);

            return null;
    }

    private CountryDTO getCountryDTO(String countryForId) {
        Country country = countryService.getCountryForId(countryForId);
        if(country != null)
           return countryService.propagateCountryDTO(country);

        return null;
    }

}
