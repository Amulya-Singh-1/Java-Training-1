package com.dgmarket.notice.service;

import com.dgmarket.common.services.CountryService;
import com.dgmarket.notice.controllers.NoticeController;
import com.dgmarket.notice.dto.CPVDTO;
import com.dgmarket.notice.dto.NoticeListItemDTO;
import com.dgmarket.notice.dto.filters.NoticeFilter;
import com.dgmarket.notice.dto.filters.NoticeSearchFilter;
import com.dgmarket.notice.dto.request.CreateNoticeRequest;
import com.dgmarket.notice.dto.response.NoticeListResponse;
import com.dgmarket.notice.entities.*;
import com.dgmarket.notice.helpers.CPVHelper;
import com.dgmarket.notice.helpers.NoticeSpecification;
import com.dgmarket.notice.repositories.CurrenciesRepository;
import com.dgmarket.notice.repositories.LanguageRepository;
import com.dgmarket.notice.repositories.NoticeRepository;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.user.entities.User;
import com.dgmarket.web.services.LanguageService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class NoticeService {

    private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);

    private final NoticeRepository noticeRepository;
    private final LanguageRepository languageRepository;
    private final CurrenciesRepository currenciesRepository;
    private final NoticeTypesService noticeTypesService;
    private final CPVHelper cpvHelper;
    private final CountryService countryService;
    private final LanguageService languageService;
    private final OrganizationHelper organizationHelper;
    private final NoticeSpecification noticeSpecification;

    public Notice createNotice(Notice notice) {
        return noticeRepository.save(notice);
    }

    public Notice findById(Long id) {
        if (noticeRepository.findById(id).isEmpty()) {
            logger.info("Notice not found , returning null");
            return null;
        } else {
            return noticeRepository.findById(id).get();
        }
    }

    public String getLanguageByNoticeId(String id) {
        if (id == null)
            return "unknown";
        if (languageRepository.findById(id).isEmpty())
            return "unknown";
        else
            return languageRepository.findById(id).get().getLocalLabel();
    }

    private CPVDTO getCPVDTOByCode(CPV cpv) {
        return new CPVDTO(cpvHelper.getCPVDisplayName(cpv.getCode()), cpv.getCode());
    }

    public Long totalNotices() {
        return noticeRepository.count();
    }

    public List<Currencies> findAllCurrencies() {
        return currenciesRepository.findAll();
    }

    public Notice populateAndSaveGeneralInformation(CreateNoticeRequest createNoticeRequest, User user, Date deadLineDate) {
       Notice notice =  Notice.builder()
                .noticeNo(createNoticeRequest.getContractNumber())
                .noticeType(noticeTypesService.findNoticeTypesByCode(createNoticeRequest.getType()))
                .noticeTitle(createNoticeRequest.getNoticeTitle())
                .performanceCountry(createNoticeRequest.getCountry())
                .mainLanguage(createNoticeRequest.getLanguage())
                .estimatedAmount(Long.parseLong(createNoticeRequest.getEstimatedValue()))
                .currency(createNoticeRequest.getEstimatedValueCurrency())
                .city(createNoticeRequest.getCity())
                .procurementMethod(Integer.parseInt(createNoticeRequest.getMethodOfProcurement()))
                .qualification(createNoticeRequest.getMinEligibilityOfBidders())
                .noticeDeadline(deadLineDate)
                .publishDate(new Date())
                .noticeSource("INTERNAL")
                .creator(user)
                .organization(organizationHelper.getOrganizationById(createNoticeRequest.getOrgId()))
                .isPublishOnSibutu(createNoticeRequest.getPublishedOnSibutu())
                .status(NoticeStatus.valueOf(createNoticeRequest.getNoticeStatus()))
                .documentFee(createNoticeRequest.getDocumentFee())
                .completedSteps(CompletedSteps.general)
                .build();
      return createNotice(notice);
    }

    public void updateNotice(Notice notice, CreateNoticeRequest createNoticeRequest) {
        if(StringUtils.isNotBlank(createNoticeRequest.getContractNumber()))
            notice.setNoticeNo(createNoticeRequest.getContractNumber());
        if(StringUtils.isNotBlank(createNoticeRequest.getType()))
            notice.setNoticeType(noticeTypesService.findNoticeTypesByCode(createNoticeRequest.getType()));
        if(StringUtils.isNotBlank(createNoticeRequest.getNoticeTitle()))
            notice.setNoticeTitle(createNoticeRequest.getNoticeTitle());
        if(StringUtils.isNotBlank(createNoticeRequest.getCountry()))
            notice.setPerformanceCountry(createNoticeRequest.getCountry());
        if(StringUtils.isNotBlank(createNoticeRequest.getLanguage()))
            notice.setMainLanguage(createNoticeRequest.getLanguage());
        if(StringUtils.isNotBlank(createNoticeRequest.getEstimatedValue()))
            notice.setEstimatedAmount(Long.parseLong(createNoticeRequest.getEstimatedValue()));
        if(StringUtils.isNotBlank(createNoticeRequest.getEstimatedValueCurrency()))
            notice.setCurrency(createNoticeRequest.getEstimatedValueCurrency());
        if(StringUtils.isNotBlank(createNoticeRequest.getCity()))
            notice.setCity(createNoticeRequest.getCity());
        if(StringUtils.isNotBlank(createNoticeRequest.getMethodOfProcurement()))
            notice.setProcurementMethod(Integer.parseInt(createNoticeRequest.getMethodOfProcurement()));
        if(StringUtils.isNotBlank(createNoticeRequest.getMinEligibilityOfBidders()))
            notice.setQualification(createNoticeRequest.getMinEligibilityOfBidders());
        if(createNoticeRequest.getOrgId() != null && createNoticeRequest.getOrgId() > 1)
            notice.setOrganization(organizationHelper.getOrganizationById(createNoticeRequest.getOrgId()));
        if(createNoticeRequest.getPublishedOnSibutu() != null)
            notice.setPublishOnSibutu(createNoticeRequest.getPublishedOnSibutu());
        if(StringUtils.isNotBlank(createNoticeRequest.getNoticeStatus()))
            notice.setStatus(NoticeStatus.valueOf(createNoticeRequest.getNoticeStatus()));
        if(StringUtils.isNotEmpty(createNoticeRequest.getNoticeStatus()) && createNoticeRequest.getNoticeStatus().equals("published"))
            notice.setPublishDate(new Date());
        if(StringUtils.isNotBlank(createNoticeRequest.getDocumentFee()))
            notice.setDocumentFee(createNoticeRequest.getDocumentFee());
        if(StringUtils.isNotBlank(createNoticeRequest.getCompletedSteps()))
            notice.setCompletedSteps(CompletedSteps.valueOf(createNoticeRequest.getCompletedSteps()));
        createNotice(notice);
    }

    public NoticeListResponse prepareNoticeList(NoticeSearchFilter filter) {
        Page<Long> matchingNoticeIds = null;
        if(filter.hasTenderType() && filter.hasKeywords() && filter.hasOrgId()){
            if(filter.getTenderType().equals("Indian")){
                matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryKeywordAndCountryAndOrg(filter.getKeywords(), "in", filter.getOrgId(), PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
            } else {
                matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryKeywordAndNotCountryAndOrg(filter.getKeywords(), "in", filter.getOrgId(), PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
            }
        }
        if(!(filter.hasTenderType()) && (!(filter.hasKeywords())) && (!(filter.hasOrgId()))){
            matchingNoticeIds = noticeRepository.findAllNoticeIds(PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
        }
        if(filter.hasKeywords() && (!(filter.hasTenderType())) && (!(filter.hasOrgId()))){
            matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryKeyword(filter.getKeywords(), PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
        }
        if(filter.hasOrgId() && (!(filter.hasTenderType())) && (!filter.hasKeywords())){

        }
        if(filter.hasTenderType() && (!(filter.hasOrgId())) && (!(filter.hasKeywords()))){
            if(filter.getTenderType().equals("Indian")){
                matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryCountry("in", PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
            } else {
                matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryNotCountry("in", PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
            }
        }
        if(filter.hasTenderType() && (!(filter.hasOrgId())) && (filter.hasKeywords())){
            if(filter.getTenderType().equals("Indian")) {
                matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryKeywordAndCountry(filter.getKeywords(), "in", PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
            } else {
                matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryKeywordAndNotCountry(filter.getKeywords(), "in", PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
            }
        }
        if(filter.hasTenderType() && (filter.hasOrgId()) && (!filter.hasKeywords())){
            if(filter.getTenderType().equals("Indian")) {
                matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryCountryAndOrg(filter.getOrgId(), "in", PageRequest.of(filter.getPage() - 1, filter.getPerPage(),Sort.by(Sort.Direction.DESC, "id")));
            } else {
                matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryNotCountryAndOrg(filter.getOrgId(), "in", PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
            }
        }
        if(!(filter.hasTenderType()) && (filter.hasOrgId()) && filter.hasKeywords()){
            matchingNoticeIds = noticeRepository.findNoticeIdsMatchingQueryAndOrg(filter.getKeywords(), filter.getOrgId(), PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
        }
        if(!(filter.hasTenderType()) && (filter.hasOrgId()) && (!filter.hasKeywords())){
            matchingNoticeIds = noticeRepository.findNoticeIdsForOrg(filter.getOrgId(), PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
        }

        return new NoticeListResponse(null, filter.getPage(),
                filter.getPerPage(),
                matchingNoticeIds.getTotalElements(),
                prepareNotices(matchingNoticeIds));
    }

    private List<NoticeListItemDTO> prepareNotices(Page<Long> noticeIds) {
        List<NoticeListItemDTO> noticeHeaders = noticeIds.stream()
                .map(noticeRepository::findById)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .map(this::noticeToDTO)
                .collect(Collectors.toList());

        return noticeHeaders;
    }

    NoticeListItemDTO noticeToDTO(Notice notice) {
        return NoticeListItemDTO.builder()
                .noticeId(notice.getId())
                .noticeTitle(notice.getNoticeTitle())
                .orgName(notice.getOrganization().getOrgName())
                .estimatedValue(notice.getEstimatedAmount())
                .currency(notice.getCurrency())
                .country(countryService.getCountryForId(notice.getPerformanceCountry()).getCountryName())
                .type(notice.getNoticeType().getName())
                .deadline(notice.getNoticeDeadline() != null ? notice.getNoticeDeadline().toString() : null)
                .publishedDate(notice.getPublishDate().toString())
                .language(languageService.findLocaleLanguageById(notice.getMainLanguage()).getName())
                .noticeStatus(notice.getStatus()==null?null:notice.getStatus().toString())
                .build();
    }
    public List<Notice> findAll(){
        return noticeRepository.findAll();
    }

    public NoticeListResponse findNoticeList(NoticeFilter filter) {
        Page<Notice> pages = noticeRepository.findAll(noticeSpecification.findNotices(filter), PageRequest.of(filter.getPage() - 1, filter.getPerPage(), Sort.by(Sort.Direction.DESC, "id")));
        return new NoticeListResponse(null, filter.getPage(),
                filter.getPerPage(),
                pages.getTotalElements(),
                preparedNotices(pages));
    }

    private List<NoticeListItemDTO> preparedNotices(Page<Notice> notices) {
        List<NoticeListItemDTO> noticeHeaders = notices.stream()
                .map(this::noticeToDTO)
                .collect(Collectors.toList());

        return noticeHeaders;
    }
}


