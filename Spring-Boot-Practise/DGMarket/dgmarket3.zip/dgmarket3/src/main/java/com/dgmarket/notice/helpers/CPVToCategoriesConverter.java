package com.dgmarket.notice.helpers;

import com.dgmarket.core.utility.StreamUtils;
import com.dgmarket.notice.entities.CPVToCategory;
import com.dgmarket.notice.entities.Category;
import com.dgmarket.notice.repositories.CPVToCategoryRepository;
import com.dgmarket.notice.repositories.CategoryRepository;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class CPVToCategoriesConverter {
    private List<CPVToCategory> cpvToCategoryCache;
    private Map<String, Category> categoryCache;

    public CPVToCategoriesConverter(CategoryRepository categoryRepository, CPVToCategoryRepository cpvToCategoryRepository) {
        cpvToCategoryCache = StreamUtils.stream(cpvToCategoryRepository.findAll()).collect(Collectors.toList());
        categoryCache = StreamUtils.stream(categoryRepository.findAll())
                .collect(Collectors.toMap(Category::getCategoryCode, t -> t));
    }

    @SuppressWarnings("unchecked")
    public List<Category> findCategories(String cpvCode) {
        while (true) {
            List<String> categoryCodes = findCategoryCodesByCpvCode(cpvCode);
            if (CollectionUtils.isNotEmpty(categoryCodes))
                return extractCategories(categoryCodes);
            else if (cpvCode.endsWith("000000"))
                return Collections.EMPTY_LIST;
            else
                cpvCode = replaceLastNonZeroWithZero(cpvCode);
        }
    }

    private List<String> findCategoryCodesByCpvCode(String cpvCode) {
        return cpvToCategoryCache.stream()
                .filter(cpvToCategory -> cpvToCategory.getCpvCode().equals(cpvCode))
                .map(CPVToCategory::getCategoryCode)
                .distinct()
                .collect(Collectors.toList());
    }

    private List<Category> extractCategories(List<String> categoryCodes) {
        return categoryCodes.stream().map(categoryCache::get).distinct().collect(Collectors.toList());
    }

    @SuppressWarnings("UnnecessaryLocalVariable")
    private static String replaceLastNonZeroWithZero(String cpvCode) {
        String cpvCodeRoot = StringUtils.stripEnd(cpvCode, "0");
        String cpvCodeRootChoppedLastChar = StringUtils.chop(cpvCodeRoot);
        String result = StringUtils.rightPad(cpvCodeRootChoppedLastChar, 8, '0');
        return result;
    }
}