package com.dgmarket.notice.dto.filters;

import com.dgmarket.core.dto.request.BaseFilter;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class CpvSearchFilter extends BaseFilter {
    String keyword;
    public boolean hasKeyword() {
        return StringUtils.isNotEmpty(this.keyword);
    }
}
