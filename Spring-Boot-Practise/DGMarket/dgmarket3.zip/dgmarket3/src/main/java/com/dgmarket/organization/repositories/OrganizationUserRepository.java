package com.dgmarket.organization.repositories;

import com.dgmarket.organization.entities.OrganizationUsers;
import com.dgmarket.user.entities.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface OrganizationUserRepository extends JpaRepository<OrganizationUsers, Long> {
    @Query("SELECT ou.user from OrganizationUsers ou where ou.orgId =:orgId")
    Page<User> findUsersOrgId(@Param("orgId") Long orgId, Pageable pageable);

    @Query("SELECT ou.user from OrganizationUsers ou where ou.orgId =:orgId and (lower(ou.user.firstName) like CONCAT('%', :searchKey, '%') or  lower(ou.user.lastName) like CONCAT('%', :searchKey, '%') or lower(ou.user.email) like CONCAT('%', :searchKey, '%'))")
    Page<User> findUsersBySearchKeyAndOrgId(@Param("searchKey") String searchKey,@Param("orgId") Long orgId, Pageable pageable);

    OrganizationUsers findByOrgIdAndUserId(long orgId, long userId);

}
