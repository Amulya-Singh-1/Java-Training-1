package com.dgmarket.web.controller;

import com.dgmarket.core.config.Constants;
import com.dgmarket.core.dto.EmailRequestDTO;
import com.dgmarket.core.entities.EmailChannel;
import com.dgmarket.core.entities.EmailType;
import com.dgmarket.web.dto.request.ContactUsRequest;
import com.dgmarket.core.mail.MailUtility;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/web")
public class ContactUsController {

    private final MailUtility mailUtility;

    @PostMapping("/contactUs")
    public ResponseEntity<?> contactUs(@Valid @RequestBody ContactUsRequest contactUsRequest) {
        final Map<String, Object> body = new HashMap<>();

        StringBuffer sb = new StringBuffer("Name : " + contactUsRequest.getName() + "\n" + "Email : " + contactUsRequest.getEmail() + "\n" + "Message : " + contactUsRequest.getMessage());
        mailUtility.sendEmail(EmailRequestDTO.builder()
                .subject(contactUsRequest.getSubject())
                .body(sb.toString())
                .toAddresses(List.of(Constants.DG_DEFAULT_SUPPORT_EMAIL))
                .emailChannel(EmailChannel.SMTP)
                .emailType(EmailType.targeted)
                .isHtml(false)
                .fromAddress(Constants.DG_DEFAULT_NOTIFICATION_EMAIL)
                .build());
        body.put("status", HttpServletResponse.SC_OK);
        body.put("message", "Enquiry submitted successfully !!");
        return ResponseEntity.ok().body(body);

    }

}
