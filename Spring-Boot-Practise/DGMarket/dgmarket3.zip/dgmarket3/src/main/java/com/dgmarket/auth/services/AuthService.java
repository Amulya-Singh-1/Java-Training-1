package com.dgmarket.auth.services;

import com.dgmarket.auth.dto.request.SignInRequest;
import com.dgmarket.auth.dto.response.AuthUserResponseDTO;
import com.dgmarket.auth.jwt.JwtUtils;
import com.dgmarket.auth.securities.AuthyManager;
import com.dgmarket.user.services.UserService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseCookie;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
@AllArgsConstructor
public class AuthService {

    private final AuthyManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final UserService userService;

    public ResponseCookie logIn(SignInRequest signInRequest) {
        Authentication authentication = authenticationManager
                .authenticate(new UsernamePasswordAuthenticationToken(signInRequest.getEmail(), signInRequest.getPassword(),new ArrayList<>()));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        return jwtUtils.generateJwtCookie(signInRequest.getEmail());
    }

    public AuthUserResponseDTO getUserDTO(String email) {
        return userService.convertUserToAuthResponseDTO(email);
    }

}
