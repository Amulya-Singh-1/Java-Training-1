package com.dgmarket.exception;

import org.springframework.security.authentication.DisabledException;

public class UserEmailNotVerifiedException extends DisabledException {
    public UserEmailNotVerifiedException(String message) {
        super(message);
    }
}
