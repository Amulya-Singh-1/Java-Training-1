package com.dgmarket.web.repositories;

import com.dgmarket.web.entities.views.CountryWiseNoticeCount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CountryWiseNoticeCountRepository extends JpaRepository<CountryWiseNoticeCount, Long> {


    Optional<CountryWiseNoticeCount> findByIso(String iso);
    Optional<CountryWiseNoticeCount> findByCount(Long count);
}
