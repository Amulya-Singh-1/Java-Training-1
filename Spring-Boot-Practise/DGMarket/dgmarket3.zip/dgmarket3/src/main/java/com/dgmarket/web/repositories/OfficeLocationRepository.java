package com.dgmarket.web.repositories;

import com.dgmarket.common.entities.Country;
import com.dgmarket.web.entities.OfficeLocation;
import com.dgmarket.web.services.OfficeLocationService;
import lombok.AllArgsConstructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OfficeLocationRepository extends JpaRepository<OfficeLocation,Long> {

//    static String query = ;

//    @Query(query)
//    List<OfficeLocation> findALLBYFILTER(
//
//            @Param("id") Long id,
//            @Param("name") String name,
//            @Param("type") String type,
//            @Param("orgId") Long orgId,
//            @Param("country")Country country,
//            @Param("pincode")String pincode,
//            @Param("city")String city,
//            @Param("state")String state,
//            @Param("flatNo")String flatNo,
//            @Param("locality")String locality,
//            @Param("contactNumber")String contactNumber,
//            @Param("email")String email
//    );
//
//@Query("=:query")
//    List<OfficeLocation>findALLBYFILTER(@Param("query") String query);
}


