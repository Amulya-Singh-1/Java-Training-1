package com.dgmarket.web.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class FaqItemsDTO {

    private String faqName;
    private String question;
    private String answer;

}
