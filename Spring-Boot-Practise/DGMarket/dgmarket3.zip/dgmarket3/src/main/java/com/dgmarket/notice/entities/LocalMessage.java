package com.dgmarket.notice.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "dg_message")
@Data
public class LocalMessage {
    @EmbeddedId
    private LocalMessagePK id;
    @Column(name = "message_utf8")
    private String text;

}
