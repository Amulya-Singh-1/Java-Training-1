package com.dgmarket.user.repositories;

import com.dgmarket.user.entities.UserLanguagePrefernces;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserLanguagePreferencesRepository extends JpaRepository<UserLanguagePrefernces, Long> {
}
