package com.dgmarket.security;

import com.dgmarket.auth.services.UserDetailsServiceImpl;
import lombok.AllArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor

public class UserContext {

    private final UserDetailsServiceImpl userDetailsService;

    public long getUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return userDetailsService.getUserByEmail(authentication.getName()).getId();
    }

    public boolean isUserLoggedIn() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication == null || authentication.isAuthenticated();
    }

}