package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.Region;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface RegionRepository extends CrudRepository<Region, String> {
    List<Region> findAllByOrderByName();
    Region findByNameIgnoreCase(String name);
}
