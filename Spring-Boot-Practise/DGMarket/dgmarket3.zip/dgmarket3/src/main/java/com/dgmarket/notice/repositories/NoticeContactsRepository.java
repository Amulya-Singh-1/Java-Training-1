package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.NoticeContacts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NoticeContactsRepository extends JpaRepository<NoticeContacts, Long> {
    NoticeContacts findByNoticeId(Long noticeId);
}
