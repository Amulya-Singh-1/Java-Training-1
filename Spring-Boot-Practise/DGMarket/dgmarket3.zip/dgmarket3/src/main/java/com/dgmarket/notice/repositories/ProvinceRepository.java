package com.dgmarket.notice.repositories;


import com.dgmarket.notice.entities.Province;
import com.dgmarket.notice.entities.ProvincePK;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface ProvinceRepository extends CrudRepository<Province, ProvincePK> {
    List<Province> findById_CountryCode(String countryCode);

    List<Province> findById_CountryCodeAndStateNameIn(String countryCode, List<String> stateNames);
}
