package com.dgmarket.web.repositories;

import com.dgmarket.web.entities.views.LanguageWiseNoticeCount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LanguageWiseNoticeCountRepository extends JpaRepository<LanguageWiseNoticeCount,String> {
}
