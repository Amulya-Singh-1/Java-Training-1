package com.dgmarket.core.mail;

import com.dgmarket.core.dto.EmailRequestDTO;
import com.dgmarket.core.entities.EmailChannel;
import com.dgmarket.core.entities.EmailLog;
import com.dgmarket.core.entities.EmailType;
import com.dgmarket.core.repositories.EmailLogRepository;
import lombok.AllArgsConstructor;
import lombok.SneakyThrows;
import org.slf4j.LoggerFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.UnsupportedEncodingException;
import java.util.Date;

@Service
@AllArgsConstructor
public class MailUtility {

    private final JavaMailSender javaMailSender;
    private final EmailLogRepository emailLogRepository;
    private static final org.slf4j.Logger logger = LoggerFactory.getLogger(MailUtility.class);

    @SneakyThrows
    public void sendEmail(EmailRequestDTO emailRequest) {
        send(emailRequest);
    }

    @Async
    void send(EmailRequestDTO emailRequest) throws UnsupportedEncodingException, MessagingException {
        for (String emailAddress : emailRequest.getToAddresses()) {
            MimeMessage message = javaMailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message);
            helper.setFrom(emailRequest.getFromAddress(), "dgMarket");
            helper.setTo(emailAddress);
            helper.setSubject(emailRequest.getSubject());
            helper.setText(emailRequest.getBody(), true);
            logger.info("sending email to: {}\n", emailAddress);
            javaMailSender.send(message);
            saveEmailLog(emailAddress, emailRequest.getSubject(), emailRequest.getBody(), "-1", emailRequest.getEmailType(), emailRequest.getEmailChannel());
        }
    }

    private void saveEmailLog(String toAddress, String subject, String body, String providerMessageId, EmailType emailType, EmailChannel channel) {
        EmailLog emailLog = EmailLog.builder()
                .recipient(toAddress)
                .subject(subject)
                .body(body)
                .channel(channel)
                .timeSent(new Date())
                .messageId(providerMessageId)
                .emailType(emailType)
                .build();
        emailLogRepository.save(emailLog);
    }
}
