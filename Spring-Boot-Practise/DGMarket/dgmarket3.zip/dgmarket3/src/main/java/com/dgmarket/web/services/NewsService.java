package com.dgmarket.web.services;

import com.dgmarket.web.dto.NewsListDTO;
import com.dgmarket.web.dto.NewsPageDTO;
import com.dgmarket.web.dto.response.NewsListResponse;
import com.dgmarket.web.entities.News;
import org.springframework.data.domain.Page;

import java.util.List;

public interface NewsService {

    List<NewsListDTO> getAllNewsList();

    News getNewsDetailsById(long id);

    Page newsPage(Integer pageNo, Integer pageSize);

    NewsListDTO populateNewsDto(News news);

    Long totalNewsData();

    NewsListResponse prepareNewsList(NewsPageDTO newsPageDTO);
}
