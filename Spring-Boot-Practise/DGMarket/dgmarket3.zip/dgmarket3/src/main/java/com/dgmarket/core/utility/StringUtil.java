package com.dgmarket.core.utility;

import java.util.Random;

public class StringUtil {

    public static String generateStringWithRandaomNumbers(int captchaLength){
        String saltCharacters = "abranNumcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuffer captchaStrBuff = new StringBuffer();
        Random ranNum = new Random();
        while (captchaStrBuff.length() < captchaLength){
            int index = (int) (ranNum.nextFloat() * saltCharacters.length());
            captchaStrBuff.append(saltCharacters.substring(index, index+1));
        }
        System.out.println("random: "+captchaStrBuff);
        return captchaStrBuff.toString();
    }
}



