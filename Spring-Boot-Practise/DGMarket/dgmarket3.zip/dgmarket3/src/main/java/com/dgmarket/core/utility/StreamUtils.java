package com.dgmarket.core.utility;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class StreamUtils {
    public static <T> Stream<T> stream(final Iterable<T> iterable){
        if (iterable==null)
            return Stream.empty();
        if (iterable instanceof Collection)
            return ((Collection<T>) iterable).stream();
        return StreamSupport.stream(iterable.spliterator(),false);
    }

    public static List<Long> commaSeparatedStringToList(String src){
        if (StringUtils.isBlank(src))
            return Collections.emptyList();
        else
            return Arrays.stream(src.split(","))
                    .map(s->s.replaceAll(" ", ""))
                    .filter(NumberUtils::isParsable)
                    .map(Long::valueOf)
                    .collect(Collectors.toList());
    }

    public static Stream<Long> commaSeparatedStringToStream(String src){
        return commaSeparatedStringToList(src).stream();
    }
}
