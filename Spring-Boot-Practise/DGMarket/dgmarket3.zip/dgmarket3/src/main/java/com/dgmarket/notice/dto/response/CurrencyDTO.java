package com.dgmarket.notice.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class CurrencyDTO {

    private String code;
    private String name;
    private String symbol;

}
