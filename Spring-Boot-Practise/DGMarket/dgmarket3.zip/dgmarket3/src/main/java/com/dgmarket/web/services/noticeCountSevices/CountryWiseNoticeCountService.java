package com.dgmarket.web.services.noticeCountSevices;

import com.dgmarket.web.entities.views.CountryWiseNoticeCount;
import com.dgmarket.web.repositories.CountryWiseNoticeCountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class CountryWiseNoticeCountService {
    final private CountryWiseNoticeCountRepository countryWiseNoticeCountRepository;

    public CountryWiseNoticeCount findByIso(String iso){
        return countryWiseNoticeCountRepository.findByIso(iso).orElse(null);
    }
    public List<CountryWiseNoticeCount> findAll(){
        return countryWiseNoticeCountRepository.findAll();
    }

    public CountryWiseNoticeCount findByCount(Long count){
        return countryWiseNoticeCountRepository.findByCount(count).orElse(null);
    }
}
