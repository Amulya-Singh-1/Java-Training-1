package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.NoticeFunding;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NoticeFundingRepository extends JpaRepository<NoticeFunding, Integer> {
    NoticeFunding findByNoticeId(Long noticeId);
    List<NoticeFunding> findAllByNoticeId(Long noticeId);
}
