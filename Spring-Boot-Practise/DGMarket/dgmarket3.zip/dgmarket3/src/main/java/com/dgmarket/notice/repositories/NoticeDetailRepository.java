package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.NoticeDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NoticeDetailRepository extends JpaRepository<NoticeDetail, Long> {
    NoticeDetail findByNoticeId(Long noticeId);
}
