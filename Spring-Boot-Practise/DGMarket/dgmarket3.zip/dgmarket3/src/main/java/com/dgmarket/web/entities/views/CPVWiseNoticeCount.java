package com.dgmarket.web.entities.views;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@AllArgsConstructor
@Data
@NoArgsConstructor
@Entity
@Table(name = "cpv_wise_notice_count")
public class CPVWiseNoticeCount {
    @Id
    private String code;
    private String name;
    private Long count;
}
