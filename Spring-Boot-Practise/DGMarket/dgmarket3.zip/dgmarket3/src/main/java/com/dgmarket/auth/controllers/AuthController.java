package com.dgmarket.auth.controllers;

import com.dgmarket.auth.dto.request.ForgotPasswordRequest;
import com.dgmarket.auth.dto.request.RegistrationRequest;
import com.dgmarket.auth.dto.request.ResetPasswordRequest;
import com.dgmarket.auth.dto.request.SignInRequest;
import com.dgmarket.auth.repositories.ResetPasswordRepository;
import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.auth.services.AuthService;
import com.dgmarket.auth.services.ForgotPasswordService;
import com.dgmarket.core.config.Constants;
import com.dgmarket.core.dto.EmailRequestDTO;
import com.dgmarket.core.entities.EmailChannel;
import com.dgmarket.core.entities.EmailType;
import com.dgmarket.core.mail.MailUtility;
import com.dgmarket.user.services.UserPreferenceService;
import com.dgmarket.user.services.UserService;
import com.dgmarket.organization.services.DraftOrganizationService;
import com.dgmarket.user.entities.User;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/auth")
@AllArgsConstructor
public class AuthController {
    private final UserService userService;
    private final AuthService authService;
    private final ForgotPasswordService forgotPasswordService;
    private final DraftOrganizationService draftOrganizationService;
    private final UserPreferenceService userPreferenceService;

    private final MailUtility mailUtility;

    private final UserRepository userRepository;
    private final ResetPasswordRepository resetPasswordRepository;

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    static final String BASE_SITE_URL = "http://dg3-docker.dgmarket.com/";

    @PostMapping("/signin")
    public ResponseEntity<?> authenticateUser(@Valid @RequestBody SignInRequest signInRequest, HttpSession session) {
        final Map<String, Object> body = new HashMap<>();
        String captcha = (String) session.getAttribute("CAPTCHA");
        if (signInRequest.getCaptchaText().equals(captcha)) {
            session.removeAttribute("CAPTCHA");
            String token = authService.logIn(signInRequest).toString();
            return ResponseEntity.ok().header("access-token", token)
                    .body(authService.getUserDTO(signInRequest.getEmail()));
        } else {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Captcha not valid");
            return ResponseEntity.badRequest().body(body);
        }
    }

    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@Valid @RequestBody RegistrationRequest registrationRequest, HttpSession session) {
        final Map<String, Object> body = new HashMap<>();
        String captcha = (String) session.getAttribute("CAPTCHA");

        if (!registrationRequest.isTermsCondition()) {
            body.put("status", HttpServletResponse.SC_FORBIDDEN);
            body.put("message", "Terms & Conditions need to be accepted!");
            return ResponseEntity.badRequest().body(body);
        }

        if (userService.doesUserEmailExists(registrationRequest.getEmail())) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "Email already registered!");
            return ResponseEntity.badRequest().body(body);
        }

        if (!registrationRequest.getPassword().equals(registrationRequest.getConfirmPassword())) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "Password and confirm password should be same !!");
            logger.error("Password and confirm password should be same !!. " + registrationRequest.getPassword() + " " + registrationRequest.getConfirmPassword());
            return ResponseEntity.badRequest().body(body);
        }

        if (registrationRequest.getCaptchaText().equals(captcha)) {
            User registeredUser = userService.createUser(registrationRequest);
            draftOrganizationService.saveDraftOrganization(registeredUser.getId(), registrationRequest);
            userPreferenceService.saveNewPreferenceForUser(registeredUser.getId(), registrationRequest.getTendersInterestedIn(), registrationRequest.getInterestedSectors());
            mailUtility.sendEmail(EmailRequestDTO.builder()
                    .subject("Welcome To dgMarket")
                    .body(String.format("Thank you for joining dgMarket. Please verify your email address by clicking the link below. <a href='%s'>Verify Now</a> ", BASE_SITE_URL+"emailverification?token="+registeredUser.getEmailVerificatonCode()))
                    .toAddresses(List.of(registeredUser.getEmail()))
                    .emailChannel(EmailChannel.SMTP)
                    .emailType(EmailType.targeted)
                    .isHtml(false)
                    .fromAddress(Constants.DG_DEFAULT_NOTIFICATION_EMAIL)
                    .build());

            session.removeAttribute("CAPTCHA");
            body.put("status", HttpServletResponse.SC_CREATED);
            body.put("message", "User registered successfully! Please verify your email and login");
            logger.info("User registered successfully");
            return ResponseEntity.ok()
                    .body(body);

        } else {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Captcha not valid");
            return ResponseEntity.badRequest().body(body);
        }
    }

    @GetMapping("/verify")
    public ResponseEntity<?> verifyEmail(String token) {
        final Map<String, Object> body = new HashMap<>();
        if(userService.verifyUserEmail(token)){
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "Email verified! Please Login now to experience the new dgMarket");
            return ResponseEntity.ok(body);
        }else{
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "verificaton token is not valid");
            return ResponseEntity.badRequest().body(body);
        }
    }

    @PostMapping("/password/request")
    public ResponseEntity<?> requestLinkToChangePassword(@Valid @RequestBody ForgotPasswordRequest forgotPasswordRequest, HttpSession session) {

        final Map<String, Object> body = new HashMap<>();
        String captcha = (String) session.getAttribute("CAPTCHA");
        if (!userRepository.existsByEmail(forgotPasswordRequest.getEmail()) && forgotPasswordRequest.getEmail() != null) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "User does not exists !!");
            logger.info("user not found for email " + forgotPasswordRequest.getEmail());
            return ResponseEntity.badRequest().body(body);
        } else {
            if (!forgotPasswordRequest.getCaptchaText().equals(captcha)) {
                body.put("status", HttpServletResponse.SC_CONFLICT);
                body.put("message", "Captcha not valid");
                return ResponseEntity.badRequest().body(body);
            }
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "We have sent a password reset link on your registered email " + forgotPasswordRequest.getEmail()
                    + " Please click on the link to change your password.");
            logger.info("user found for email " + forgotPasswordRequest.getEmail());
            forgotPasswordService.sendPasswordResetLinkOnMail(forgotPasswordRequest.getEmail(), BASE_SITE_URL + "reset-password");
            session.removeAttribute("CAPTCHA");
            return ResponseEntity.ok().body(body);
        }
    }

    @PutMapping("/password")
    public ResponseEntity<?> resetAndSavePassword(@Valid @RequestBody ResetPasswordRequest resetPasswordRequest, HttpSession session) {

        final Map<String, Object> body = new HashMap<>();
        String captcha = (String) session.getAttribute("CAPTCHA");

        if (resetPasswordRepository.findResetPasswordByCode(resetPasswordRequest.getToken()) == null) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "wrong token !! Try again !!");
            logger.error("wrong Token ");
            return ResponseEntity.badRequest().body(body);
        }

        if (userRepository.findById(resetPasswordRepository.findResetPasswordByCode(resetPasswordRequest.getToken()).getUserId()).isEmpty()) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "User not found !! Try again !!");
            logger.error("user not found ");
            return ResponseEntity.badRequest().body(body);
        }
        User user = userRepository.findById(resetPasswordRepository.findResetPasswordByCode(resetPasswordRequest.getToken()).getUserId()).get();

        if (!resetPasswordRequest.getPassword().equals(resetPasswordRequest.getConfirmPassword())) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "Password doesn't match !!");
            logger.error("password does not match " + resetPasswordRequest.getPassword() + " " + resetPasswordRequest.getConfirmPassword());
            return ResponseEntity.badRequest().body(body);
        } else {
            if (!resetPasswordRequest.getCaptchaText().equals(captcha)) {
                body.put("status", HttpServletResponse.SC_CONFLICT);
                body.put("message", "Captcha not valid");
                return ResponseEntity.badRequest().body(body);
            }
            userService.updatePassword(user, resetPasswordRequest.getPassword());
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "Your Password has been set successfully !!");
            logger.info("password set for user email " + user.getEmail());
            session.removeAttribute("CAPTCHA");
            return ResponseEntity.ok().body(body);
        }
    }
}