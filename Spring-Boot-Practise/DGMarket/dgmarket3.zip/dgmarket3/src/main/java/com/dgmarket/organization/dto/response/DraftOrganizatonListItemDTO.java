package com.dgmarket.organization.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@Builder
public class DraftOrganizatonListItemDTO {
    private Long organizationId;
    private String orgName;
    private int orgStatus;
    private Long userId;
    private String userName;
    private String userEmail;
    private Date createdTime;
    private boolean isBuyer;
    private boolean isSeller;
}
