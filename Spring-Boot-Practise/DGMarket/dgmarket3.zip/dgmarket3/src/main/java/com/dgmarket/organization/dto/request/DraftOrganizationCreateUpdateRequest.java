package com.dgmarket.organization.dto.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DraftOrganizationCreateUpdateRequest {
    private String orgName;
    private Long userId;
    private Boolean isBuyer;
    private Boolean isSeller;
    private Integer orgStatus; //only used for update request
}
