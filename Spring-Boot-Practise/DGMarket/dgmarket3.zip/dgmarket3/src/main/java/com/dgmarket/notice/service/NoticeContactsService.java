package com.dgmarket.notice.service;

import com.dgmarket.notice.dto.request.NoticeContactInfoRequest;
import com.dgmarket.notice.entities.CompletedSteps;
import com.dgmarket.notice.entities.Notice;
import com.dgmarket.notice.entities.NoticeContacts;
import com.dgmarket.notice.repositories.NoticeContactsRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class NoticeContactsService {

    private final NoticeContactsRepository noticeContactsRepository;
    private final NoticeService noticeService;

    public void propagateAndSaveNoticeContact(Notice notice, NoticeContactInfoRequest noticeContactInfoRequest) {
        NoticeContacts noticeContacts = noticeContactsRepository.save(
                NoticeContacts.builder()
                        .orgId(noticeContactInfoRequest.getOrgId())
                        .notice(notice)
                        .title(noticeContactInfoRequest.getTitle())
                        .firstName(noticeContactInfoRequest.getFirstName())
                        .lastName(noticeContactInfoRequest.getLastName())
                        .address(noticeContactInfoRequest.getAddress())
                        .city(noticeContactInfoRequest.getCity())
                        .state(noticeContactInfoRequest.getState())
                        .postalCode(noticeContactInfoRequest.getPostalCode())
                        .country(noticeContactInfoRequest.getCountry())
                        .phone(noticeContactInfoRequest.getPhone())
                        .fax(noticeContactInfoRequest.getFax())
                        .email(noticeContactInfoRequest.getEmail())
                        .website(noticeContactInfoRequest.getWebsite())
                        .build()
        );
        if(noticeContacts != null){
            notice.setCompletedSteps(CompletedSteps.contact);
            noticeService.createNotice(notice);
        }
    }

    public NoticeContacts findNoticeContactByNoticeId(Long noticeId) {
        return noticeContactsRepository.findByNoticeId(noticeId);
    }

    public void updateNoticeContact(NoticeContacts noticeContacts, NoticeContactInfoRequest noticeContactInfoRequest) {
        noticeContacts.setTitle(noticeContactInfoRequest.getTitle());
        noticeContacts.setFirstName(noticeContactInfoRequest.getFirstName());
        noticeContacts.setLastName(noticeContactInfoRequest.getLastName());
        noticeContacts.setAddress(noticeContactInfoRequest.getAddress());
        noticeContacts.setCity(noticeContactInfoRequest.getCity());
        noticeContacts.setState(noticeContactInfoRequest.getState());
        noticeContacts.setPostalCode(noticeContactInfoRequest.getPostalCode());
        noticeContacts.setCountry(noticeContactInfoRequest.getCountry());
        noticeContacts.setPhone(noticeContactInfoRequest.getPhone());
        noticeContacts.setFax(noticeContactInfoRequest.getFax());
        noticeContacts.setEmail(noticeContactInfoRequest.getEmail());
        noticeContacts.setWebsite(noticeContactInfoRequest.getWebsite());
        noticeContactsRepository.save(noticeContacts);
    }
}
