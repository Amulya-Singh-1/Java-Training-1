package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.CPV;
import lombok.NonNull;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CPVRepository extends CrudRepository<CPV, String> {

    CPV findByCode(@NonNull String code);

    @Query("select c from CPV c where c.code like concat(:id, '%') order by c.code")
    List<CPV> findByPrefix(@Param("id") String codePrefix);

    @Query("select c from CPV c where c.code like :pattern order by c.code")
    List<CPV> findByPattern(@Param("pattern") String pattern);

    @Query("select c from CPV c where c.indent = 0 order by c.code")
    List<CPV> findTopCPVs();

    List<CPV> findAll();

}
