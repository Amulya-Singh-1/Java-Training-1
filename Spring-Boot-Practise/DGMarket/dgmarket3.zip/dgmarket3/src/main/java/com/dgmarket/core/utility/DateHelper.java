package com.dgmarket.core.utility;

import com.dgmarket.core.config.Constants;
import com.dgmarket.user.entities.User;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

@Component
@RequiredArgsConstructor
public class DateHelper {

    public static LocalDateTime dateToLocalDateTime(Date dateToConvert) {
        if (dateToConvert == null)
            return null;

        return LocalDateTime.ofInstant(dateToConvert.toInstant(), ZoneId.systemDefault());
    }

    @Bean
    public LocalDate getLocalDate(){
        return LocalDate.now();
    }

    //---------------------------------- Time Zone adjustment methods


    public static String tzAdjustForShowingInFE(Date date, User user) {
        if (date == null)
            return null;
        LocalDateTime localDateTime = dateToLocalDateTime(date);
        ZonedDateTime zonedDateTime = localDateTime.atZone(Constants.DATABASE_DATES_ZONE_ID);
        zonedDateTime = zonedDateTime.withZoneSameInstant(getZoneForUser(user));
        return zonedDateTime.format(DateTimeFormatter.ofPattern(Constants.DEFAULT_DATE_TIME_FORMAT));
    }

    //------------------------------------------------------ Private Methods

    /**
     * Add appropriate number of hours to convert date from the Users TZ into DB TZ
     */

    //todo:: handle hardcoded value for timezone
    private static ZoneId getZoneForUser(User user) {
        if (user == null)
            return Constants.DATABASE_DATES_ZONE_ID;
        else {
            try {
                return ZoneId.of("Etc/GMT +5.00");
            } catch (Exception e) {
                return Constants.DATABASE_DATES_ZONE_ID;
            }
        }
    }

}
