package com.dgmarket.web.dto;

import lombok.*;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NewsListDTO {

    private Long id;
    private String newsType;
    private String headline;
    private String text;
    private String source;
    private Date createDate;
    private String country;

}

