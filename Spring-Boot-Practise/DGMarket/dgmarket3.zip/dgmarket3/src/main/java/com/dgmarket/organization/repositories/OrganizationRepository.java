package com.dgmarket.organization.repositories;

import com.dgmarket.organization.entities.Organization;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface OrganizationRepository extends JpaRepository<Organization, Long> {
    List<Organization> findByOrgNameIgnoreCase(String orgName);

    Page<Organization> findByOrgParentIdOrderByOrgIdDesc(Long orgParentId, Pageable pageable);

    Page<Organization> findAllByOrgParentId(Long orgParentId, Pageable pageable);

    @Query("SELECT o FROM Organization o WHERE o.orgParentId =:parentId and upper(o.orgName) like upper(CONCAT('%', :searchKey, '%'))")
    Page<Organization> findOrganizationsBySearchKeyAndParentId(@Param("searchKey") String searchKey, @Param("parentId") Long orgId, Pageable pageable);
}
