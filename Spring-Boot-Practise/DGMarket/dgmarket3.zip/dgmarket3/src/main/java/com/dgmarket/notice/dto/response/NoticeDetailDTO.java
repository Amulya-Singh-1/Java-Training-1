package com.dgmarket.notice.dto.response;

import com.dgmarket.common.dto.response.CountryDTO;
import com.dgmarket.notice.entities.FundingAgency;
import com.dgmarket.notice.entities.NoticeDocuments;
import com.dgmarket.web.dto.response.LocaleDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class NoticeDetailDTO {

    private Long id;
    private String noticeNo;
    private NoticeTypesResponse noticeType;
    private String noticeTitle;
    private LocaleDTO mainLanguage;
    private String status;
    private CountryDTO performanceCountry;
    private String city;
    private Long estimatedAmount;
    private CurrencyDTO currency;
    private ProcurementMethodDTO procurementMethod;
    private String qualification;
    private String noticeDeadline;
    private String publishDate;
    private String noticeSource;
    private String creator;
    private boolean isPublishOnSibutu;
    private String orgName;
    private String title;
    private String firstName;
    private String lastName;
    private String address;
    private String contactCity;
    private String state;
    private String postalCode;
    private String country;
    private String phone;
    private String fax;
    private String email;
    private String website;
    private String officialText;
    private String externalUrl;
    private String completedSteps;
    private String documentFee;
    private List<NoticeDocuments> noticeDocuments;
    private List<NoticeCpvMappingDTO> noticeCpvMappings;
    private List<FundingAgency> fundingAgency;

}
