package com.dgmarket.sibutu.dto.request;

import com.dgmarket.sibutu.entities.SibutuTeam;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class SibutuTeamUpdateRequest {
    private Long id;
    private Long noticeId;
    private Long userId;

    private SibutuTeam.Role role;
}
