package com.dgmarket.web.controller;

import com.dgmarket.web.entities.views.*;
import com.dgmarket.web.services.noticeCountSevices.*;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@AllArgsConstructor
@RestController
@RequestMapping("/api/noticeCount")
public class NoticeCountController {
    final private CountryWiseNoticeCountService countryWiseNoticeCountService;
    final private OrgWiseNoticeCountService orgWiseNoticeCountService;
    final private TypeWiseNoticeCountService typeWiseNoticeCountService;
    final private FundingAgenciesNoticeCountService fundingAgenciesNoticeCountService;
    final private LanguageWiseNoticeCountService languageWiseNoticeCountService;
    final private CPVWiseNoticeCountService cpvWiseNoticeCountService;
    final private NoticeCountByPeriodService noticeCountByPeriodService;
    final private LocalDate localDate;

    @GetMapping("/country/{iso}")
    public ResponseEntity<?> findByIso(@PathVariable(name = "iso") String iso) {
        final Map<String, Object> body = new HashMap<>();
        if (countryWiseNoticeCountService.findByIso(iso) == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("response", "Not Found.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", countryWiseNoticeCountService.findByIso(iso));
        return ResponseEntity.ok(body);
    }

    @GetMapping("/country")
    public ResponseEntity<?> findAll() {
        final Map<String, Object> body = new HashMap<>();
        if (countryWiseNoticeCountService.findAll().isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("response", "Not Found.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", countryWiseNoticeCountService.findAll());
        return ResponseEntity.ok(body);
    }

    @GetMapping("/org")
    public ResponseEntity<?> findAllOrgWise() {
        final Map<String, Object> body = new HashMap<>();
        List<OrgWiseNoticeCount> count = orgWiseNoticeCountService.findAll();
        if (count.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not Found.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", count);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/org/{orgName}")
    public ResponseEntity<?> findByOrgName(@PathVariable(name = "orgName") String orgName) {
        final Map<String, Object> body = new HashMap<>();
        List<OrgWiseNoticeCount> orgWiseNoticeCount = orgWiseNoticeCountService.findByOrgName(orgName);
        if (orgWiseNoticeCount.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not found.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", orgWiseNoticeCount);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/type")
    public ResponseEntity<?> findAllByType() {
        final Map<String, Object> body = new HashMap<>();
        List<TypeWiseNoticeCount> counts = typeWiseNoticeCountService.findAllTypeWise();
        if (counts.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not found");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", counts);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/type/{name}")
    public ResponseEntity<?> findTypeByName(@PathVariable(name = "name") String name) {
        final Map<String, Object> body = new HashMap<>();
        List<TypeWiseNoticeCount> counts = typeWiseNoticeCountService.findAllTypeWiseByName(name);
        if (counts.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not found.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", counts);
        return ResponseEntity.ok(body);

    }

    @GetMapping("/fundingAgency")
    public ResponseEntity<?> findByFilter(FundingAgenciesNoticeCount fundingAgenciesNoticeCount) {
        final Map<String, Object> body = new HashMap<>();
        List<FundingAgenciesNoticeCount> countList = fundingAgenciesNoticeCountService.filteredList(fundingAgenciesNoticeCount);
        if (countList.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not Found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", countList);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/language")
    public ResponseEntity<?> findByLanguageWiseFilter(LanguageWiseNoticeCount languageWiseNoticeCount) {
        final Map<String, Object> body = new HashMap<>();
        List<LanguageWiseNoticeCount> countList = languageWiseNoticeCountService.getFilteredList(languageWiseNoticeCount);
        if (countList.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not Found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", countList);
        return ResponseEntity.ok(body);
    }

    @GetMapping("/cpv")
    public ResponseEntity<?> findByCPVFilter(CPVWiseNoticeCount cpvWiseNoticeCount) {
        final Map<String, Object> body = new HashMap<>();
        List<CPVWiseNoticeCount> countList = cpvWiseNoticeCountService.getFilteredList(cpvWiseNoticeCount);
        if (countList.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not Found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", countList);
        return ResponseEntity.ok(body);
    }


    @GetMapping("/period/date")
    public ResponseEntity<?> findCountByPeriod(int days) {
        final Map<String, Object> body = new HashMap<>();
        Date date = Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).minusDays(days).toInstant());
        Page<Long> count = noticeCountByPeriodService.countByPeriod(date);

        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", count.getContent());
        return ResponseEntity.ok(body);
    }


}
