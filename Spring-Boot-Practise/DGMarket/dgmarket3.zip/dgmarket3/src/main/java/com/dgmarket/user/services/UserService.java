package com.dgmarket.user.services;

import com.dgmarket.auth.dto.request.RegistrationRequest;
import com.dgmarket.auth.dto.response.AuthUserResponseDTO;
import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.organization.services.OrganizationService;
import com.dgmarket.user.dto.filter.UserFilter;
import com.dgmarket.user.dto.response.UserDTO;
import com.dgmarket.user.dto.response.UserListResponse;
import com.dgmarket.user.dto.response.UserProfileData;
import com.dgmarket.user.dto.response.UserRoleResponse;
import com.dgmarket.user.entities.User;
import com.dgmarket.user.enums.UserPreferenceKeys;
import com.dgmarket.user.repositories.UserRoleRepository;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static com.dgmarket.core.utility.StringUtil.generateStringWithRandaomNumbers;

@AllArgsConstructor
@Service
public class UserService {

    private final UserPreferenceService userPreferenceService;
    private final UserLanguagePreferencesService userLanguagePreferencesService;
    private final OrganizationService organizationService;
    private final OrganizationHelper organizationHelper;

    private final UserRepository userRepository;
    private final UserRoleRepository userRoleRepository;

    private final PasswordEncoder encoder;

    public User getUserById(Long id) {
        return userRepository.findUserById(id);
    }

    public boolean verifyUserEmail(String token) {
        User user = userRepository.findByEmailVerificatonCode(token);
        if (user != null && user.isActive() && !user.isEmailVerified()) {
            user.setEmailVerified(true);
            userRepository.save(user);
            return true;
        }
        return false;
    }

    //todo:: registration source
    public User createUser(RegistrationRequest registrationRequest) {
        User user = User.builder()
                .email(registrationRequest.getEmail())
                .password(encoder.encode(registrationRequest.getPassword()))
                .firstName(registrationRequest.getFirstName())
                .lastName(registrationRequest.getLastName())
                .mobile(registrationRequest.getPhone())
                .active(true)
                .createdTime(new Date())
                .lastModifiedTime(new Date())
                .registrationSource((StringUtils.isNotEmpty(registrationRequest.getRegistrationSource()) && registrationRequest.getRegistrationSource().equalsIgnoreCase("admin-panel")) ? registrationRequest.getRegistrationSource() : "WEB:<ip_address>")
                .emailVerificatonCode((StringUtils.isNotEmpty(registrationRequest.getRegistrationSource()) && registrationRequest.getRegistrationSource().equalsIgnoreCase("admin-panel")) ? "" : generateStringWithRandaomNumbers(35))
                .emailVerified((StringUtils.isNotEmpty(registrationRequest.getRegistrationSource()) && registrationRequest.getRegistrationSource().equalsIgnoreCase("admin-panel")))
                .build();
        user = userRepository.save(user);
        return user;
    }

    public boolean doesUserEmailExists(String email) {
        if (userRepository.existsByEmail(email))
            return true;
        return false;
    }

    public void updatePassword(User user, String password) {
        user.setPassword(encoder.encode(password));
        userRepository.save(user);
    }

    public AuthUserResponseDTO convertUserToAuthResponseDTO(String email) {
        User userEntity = userRepository.findByEmailIgnoreCase(email);
        if (userEntity == null) {
            throw new UsernameNotFoundException(email);
        }
        return AuthUserResponseDTO.builder()
                .id(userEntity.getId())
                .username(userEntity.getFullName())
                .email(userEntity.getEmail())
                .baseOrganizationDTOList(organizationService.getOrganizationDTOList(userEntity.getId()))
                .tendersInterestedIn(userPreferenceService.getUserPreferenceForKey(userEntity.getId(), UserPreferenceKeys.USER_PREFS_INTERESTED_TENDERS.name()).toString())
                .interestedSectors(userPreferenceService.getUserPreferenceForKey(userEntity.getId(), UserPreferenceKeys.USER_PREFS_INTERESTED_SECTORS.name()))
                .subscribed(false)
                .build();
    }

    //todo:: uncomment localLanguage when properly implemented
    public UserProfileData getUserProfileDataDTO(User user) {
        return UserProfileData.builder().
                username(user.getFullName()).
                email(user.getEmail()).
                baseOrganizationDTOList(organizationService.getOrganizationDTOList(user.getId())).
                interestedSectors(userPreferenceService.getUserPreferenceForKey(user.getId(), UserPreferenceKeys.USER_PREFS_INTERESTED_SECTORS.name())).
                tendersInterestedIn(userPreferenceService.getUserPreferenceForKey(user.getId(), UserPreferenceKeys.USER_PREFS_INTERESTED_TENDERS.name()).toString()).
                phoneNo(user.getMobile()).
//                localLanguage(userLanguagePreferencesService.getUserLanguagePreferenceByUserId(user.getId()).getAlertsLanguage()).
        build();
    }

    private List<String> getUserRole(long userId) {
        return userRoleRepository.findAllByUserId(userId).stream().map(userRoles -> userRoles.getRole().getName()).collect(Collectors.toList());
    }

    public UserListResponse getUserListResponse(@NonNull UserFilter filter) {
        Page<User> users = getFilteredUserListPage(filter);
        UserListResponse userListResponse = new UserListResponse(null,
                filter.getPage(),
                filter.getPerPage(),
                users.getTotalElements(),
                prepareDTOList(users.getContent()));
        return userListResponse;
    }

    public List<UserDTO> getUserListDTO(@NonNull UserFilter filter) {
        if (filter.hasKeyword() && filter.hasOrgId()) {
            return prepareDTOList(getOrgUsersByMatchingNamePage(filter).getContent());
        } else if (filter.hasKeyword()) {
            return prepareDTOList(getUsersByMatchingNamePage(filter).getContent());
        } else if (filter.hasOrgId()) {
            return prepareDTOList(getAllUsersForOrgIdPage(PageRequest.of(filter.getPage(), filter.getPerPage()), filter.getOrgId()).getContent());
        } else {
            return prepareDTOList(getAllUsersPage(PageRequest.of(filter.getPage(), filter.getPerPage())).getContent());
        }
    }

    public Page<User> getFilteredUserListPage(@NonNull UserFilter filter) {
        if (filter.hasKeyword() && filter.hasOrgId()) {
            return getOrgUsersByMatchingNamePage(filter);
        } else if (filter.hasKeyword()) {
            return getUsersByMatchingNamePage(filter);
        } else if (filter.hasOrgId()) {
            return getAllUsersForOrgIdPage(PageRequest.of(filter.getPage(), filter.getPerPage()), filter.getOrgId());
        } else {
            return getAllUsersPage(PageRequest.of(filter.getPage(), filter.getPerPage()));
        }
    }

    public Page<User> getOrgUsersByMatchingNamePage(UserFilter filter) {
//        return userRoleRepository.findUsersBySearchKeyAndOrgId(filter.getKeyword(), filter.getOrgId(), PageRequest.of(filter.getPage(), filter.getPerPage()));
        return organizationService.getOrganizationUsersWithMatchingName(filter.getKeyword(), filter.getOrgId(), PageRequest.of(filter.getPage(), filter.getPerPage()));
    }

    public Page<User> getUsersByMatchingNamePage(UserFilter filter) {
        return userRepository.findAllByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCaseOrEmailContainingIgnoreCase(filter.getKeyword(), filter.getKeyword(), filter.getKeyword(), PageRequest.of(filter.getPage(), filter.getPerPage()));
    }

    public Page<User> getAllUsersPage(Pageable pageable) {
        return userRepository.findAll(pageable);
    }

    public Page<User> getAllUsersForOrgIdPage(Pageable pageable, Long orgId) {
//        return userRoleRepository.findUsersByOrgId(orgId, pageable);
        return organizationService.getAllOrganizationUsers(orgId, pageable);
    }

    public boolean isAdmin(Long userId) {
        if (organizationHelper.getUserRolesByUserId(userId) != null) {
            return organizationHelper.getUserRoleById(userId).getRole().getName().equals("Global Admin");
        }
        return false;
    }

    public List<UserDTO> prepareDTOList(List<User> users) {
        return users.stream().map(u -> u.toDTO(u)).collect(Collectors.toList());
    }

    public List<UserRoleResponse> getUserRolesByOrgId(Long orgId) {
        return userRoleRepository.findAllByOrgId(orgId).stream().map(userRoles ->
                new UserRoleResponse(
                        userRoles.getUser().getFullName(),
                        userRoles.getRole().getId(),
                        userRoles.getUser().getId(),
                        userRoles.getUser().getEmail())).collect(Collectors.toList());
    }
}
