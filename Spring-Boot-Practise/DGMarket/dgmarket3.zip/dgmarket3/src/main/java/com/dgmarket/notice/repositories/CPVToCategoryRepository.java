package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.CPVToCategory;
import org.springframework.data.repository.CrudRepository;

public interface CPVToCategoryRepository extends CrudRepository<CPVToCategory, Long> {
}