package com.dgmarket.web.services.noticeCountSevices;

import com.dgmarket.web.entities.views.LanguageWiseNoticeCount;
import com.dgmarket.web.repositories.LanguageWiseNoticeCountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class LanguageWiseNoticeCountService {
    final private LanguageWiseNoticeCountRepository languageWiseNoticeCountRepository;

    public List<LanguageWiseNoticeCount> getFilteredList(LanguageWiseNoticeCount languageWiseNoticeCount) {
        List<LanguageWiseNoticeCount> list = languageWiseNoticeCountRepository.findAll();
        List<LanguageWiseNoticeCount> counts = list.stream().filter(e ->
                e.getCode().equals((languageWiseNoticeCount.getCode() == null ? e.getCode() : languageWiseNoticeCount.getCode()))
                        &&
                        e.getCount().equals((languageWiseNoticeCount.getCount() == null ? e.getCount() : languageWiseNoticeCount.getCount()))
                        &&
                        e.getName().equals((languageWiseNoticeCount.getName() == null ? e.getName() : languageWiseNoticeCount.getName())))
                .collect(Collectors.toList());
        return counts;
    }
}
