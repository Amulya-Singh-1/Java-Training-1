package com.dgmarket.auth.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ForgotPasswordRequest {
    @NotBlank(message = "Email field is missing")
    @Size(max = 50)
    @Email(message = "Enter valid email id")
    private String email;

    @NotBlank(message = "Captcha should not be blank")
    private String captchaText;
}
