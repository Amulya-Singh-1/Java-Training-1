package com.dgmarket.web.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OfficeLocationRequest {

    @NotBlank(message = "Name should not be blank.")
    private String name;
    private String type;
    @NotNull(message = "Organization Id should not be null.")
    private Long orgId;
    @NotBlank(message = "Country should not be blank.")
    private String country;
    private String pincode;
    private String city;
    private String state;
    private String flatNo;
    private String locality;
    private String contactNumber;
    @NotBlank(message="Email should not be blank.")
    @Email
    private String email;
}
