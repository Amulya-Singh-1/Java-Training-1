package com.dgmarket.user.services;

import com.dgmarket.user.repositories.UserLanguagePreferencesRepository;
import com.dgmarket.user.entities.UserLanguagePrefernces;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class UserLanguagePreferencesService {

    private final UserLanguagePreferencesRepository userLanguagePreferencesRepository;

    public void saveUserLanguagePreferences(Long userId, String defaultLanguage) {
        UserLanguagePrefernces userLanguagePrefernces = UserLanguagePrefernces.builder().
                userId(userId).
                siteId(170028L). // To be Changed
                alertsLanguage(defaultLanguage)
                .build();
        userLanguagePreferencesRepository.save(userLanguagePrefernces);

    }

    public UserLanguagePrefernces getUserLanguagePreferenceByUserId(Long id) {
        UserLanguagePrefernces languagePrefernces = userLanguagePreferencesRepository.getById(id);
        if(languagePrefernces==null)
            return UserLanguagePrefernces.builder().build();
        return languagePrefernces;
    }

}
