package com.dgmarket.notice.service;

import com.dgmarket.notice.dto.request.NoticeCpvMappingRequest;
import com.dgmarket.notice.entities.NoticeCpvMapping;
import com.dgmarket.notice.repositories.NoticeCpvMappingRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class NoticeCpvMappingService {

    private final NoticeCpvMappingRepository noticeCpvMappingRepository;
    private final NoticeService noticeService;

    public void addNoticeCpvMapping(List<NoticeCpvMappingRequest> noticeCpvMappingRequest) {
        noticeCpvMappingRequest.stream().forEach(noticeCpvMappingReq -> saveNoticeCpvMapping(noticeCpvMappingReq));
    }

    public void saveNoticeCpvMapping(NoticeCpvMappingRequest noticeCpvMappingRequest){
        noticeCpvMappingRepository.save(NoticeCpvMapping.builder()
                .notice(noticeService.findById(noticeCpvMappingRequest.getNoticeId()))
                .cpvMaster(noticeCpvMappingRequest.getCpvId())
                .isPrimary(noticeCpvMappingRequest.isPrimary())
                .build());
    }

    public List<NoticeCpvMapping> findNoticeCpvMappingListByNoticeId(Long noticeId) {
       return noticeCpvMappingRepository.findAllByNotice_Id(noticeId);
    }

    public NoticeCpvMapping findNoticeCpvMappingById(Long noticeCpvMapId) {
        return noticeCpvMappingRepository.findById(noticeCpvMapId).orElse(null);
    }

    public void deleteNoticeCpvMapping(NoticeCpvMapping noticeCpvMapping) {
        noticeCpvMappingRepository.delete(noticeCpvMapping);
    }
}
