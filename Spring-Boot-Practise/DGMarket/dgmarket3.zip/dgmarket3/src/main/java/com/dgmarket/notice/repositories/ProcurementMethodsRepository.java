package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.ProcurementMethods;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProcurementMethodsRepository extends JpaRepository<ProcurementMethods, Integer> {
}
