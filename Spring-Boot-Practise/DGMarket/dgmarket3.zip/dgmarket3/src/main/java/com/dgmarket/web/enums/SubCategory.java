package com.dgmarket.web.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.stream.Stream;

@RequiredArgsConstructor
public enum SubCategory {

    SIGN_UP_PROBLEM("Sign-up problem"),
    CANNOT_LOGIN("Can't Log in"),
    SITE_DESIGN_UTILITY("Site Design/Usability"),
    SITE_CONTENT("Site Content"),
    OTHERS("Others");

    @Getter
    private final String id;

    public static SubCategory fromId(String id) {
        return Stream.of(SubCategory.values()).filter(targetEnum -> targetEnum.id.equals(id)).findFirst().orElse(null);
    }

}
