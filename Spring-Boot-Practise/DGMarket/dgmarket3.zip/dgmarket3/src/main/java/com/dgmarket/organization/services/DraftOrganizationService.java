package com.dgmarket.organization.services;

import com.dgmarket.auth.dto.request.RegistrationRequest;
import com.dgmarket.exception.SameNamedOrganizationExistsException;
import com.dgmarket.organization.dto.filters.DraftOrganizationFilter;
import com.dgmarket.organization.dto.request.DraftOrganizationCreateUpdateRequest;
import com.dgmarket.organization.dto.request.DraftRejectionDTO;
import com.dgmarket.organization.dto.request.OrganizationCreateUpdateRequest;
import com.dgmarket.organization.dto.response.DraftOrganizationListResponse;
import com.dgmarket.organization.dto.response.DraftOrganizatonListItemDTO;
import com.dgmarket.organization.entities.DraftOrganization;
import com.dgmarket.organization.entities.OrgRejectionDetail;
import com.dgmarket.organization.entities.Organization;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.organization.repositories.DraftOrganizationRepository;
import com.dgmarket.organization.repositories.OrgRejectionDetailRepository;
import com.dgmarket.user.entities.User;
import com.dgmarket.user.services.UserService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class DraftOrganizationService {
    private static final Logger logger = LoggerFactory.getLogger(DraftOrganizationService.class);

    private final DraftOrganizationRepository draftOrganizationRepository;

    private final OrganizationService organizationService;
    private final UserService userService;
    private final OrganizationHelper organizationHelper;
    private final OrgRejectionDetailRepository orgRejectionDetailRepository;

    public DraftOrganization saveDraftOrganization(long userId, RegistrationRequest registrationRequest) {
        return create(DraftOrganizationCreateUpdateRequest.builder()
                .isBuyer(registrationRequest.isBuyer())
                .isSeller(registrationRequest.isSeller())
                .orgName(registrationRequest.getOrganizationName())
                .userId(userId)
                .build());
    }

    public DraftOrganizationListResponse showAllDrafts(DraftOrganizationFilter filter) {
        Page<DraftOrganization> draftOrganizations = null;
        if (filter.hasUserId() && filter.hasStatus())
            draftOrganizations = draftOrganizationRepository.findAllByUserIdAndOrgStatusOrderByCreatedTimeDesc(filter.getUserId(), filter.getStatus(), PageRequest.of(filter.getPage(), filter.getPerPage()));

        else if (filter.hasStatus())
            draftOrganizations = draftOrganizationRepository.findAllByOrgStatusOrderByOrganizationIdDesc(filter.getStatus(), PageRequest.of(filter.getPage(), filter.getPerPage()));

        else if (filter.hasUserId())
            draftOrganizationRepository.findAllByUserIdOrderByCreatedTimeDesc(filter.getUserId(), PageRequest.of(filter.getPage(), filter.getPerPage()));

        else if (draftOrganizations == null)
            draftOrganizations = draftOrganizationRepository.findAll(PageRequest.of(filter.getPage(), filter.getPerPage()));

        List<DraftOrganizatonListItemDTO> dtoList = draftOrganizations.stream().map(draftOrganization -> {
            User user = userService.getUserById(draftOrganization.getUserId());
            return draftOrganization.toDTO(user.getEmail(), user.getFullName());
        }).collect(Collectors.toList());

        DraftOrganizationListResponse draftOrganizationListResponse = new DraftOrganizationListResponse(
                (filter.getPage() == 0 && draftOrganizations.getTotalElements() == 0) ? "No Draft organization found!" : null,
                filter.getPage(),
                filter.getPerPage(),
                draftOrganizations.getTotalElements(),
                dtoList
        );

        return draftOrganizationListResponse;
    }


    public DraftOrganization create(DraftOrganizationCreateUpdateRequest draftOrganizationCreateUpdateRequest) {
        return draftOrganizationRepository.save(
                DraftOrganization.builder()
                        .createdTime(new Date())
                        .isBuyer(draftOrganizationCreateUpdateRequest.getIsBuyer())
                        .isSeller(draftOrganizationCreateUpdateRequest.getIsSeller())
                        .orgName(draftOrganizationCreateUpdateRequest.getOrgName())
                        .userId(draftOrganizationCreateUpdateRequest.getUserId())
                        .orgStatus(DraftOrganization.Status.DRAFT.getVal())
                        .build());
    }

    public DraftOrganization updateDraftOrganizaton(Long id, DraftOrganizationCreateUpdateRequest draftOrganizationCreateUpdateRequest) {
        DraftOrganization draftOrganization = findById(id);
        if (processFields(draftOrganization, draftOrganizationCreateUpdateRequest)) {
            if (processStatus(draftOrganization, draftOrganizationCreateUpdateRequest)) {
                return draftOrganizationRepository.save(draftOrganization);
            }
        }
        return null;
    }

    private boolean processFields(DraftOrganization draftOrganization, DraftOrganizationCreateUpdateRequest draftOrganizationCreateUpdateRequest) {
        boolean fieldProcessSuccessful = false;
        if (draftOrganizationCreateUpdateRequest.getIsBuyer() != null && draftOrganization.isBuyer() != draftOrganizationCreateUpdateRequest.getIsBuyer()) {
            draftOrganization.setBuyer(draftOrganizationCreateUpdateRequest.getIsBuyer());
            fieldProcessSuccessful = true;
        }
        if (draftOrganizationCreateUpdateRequest.getIsSeller() != null && draftOrganization.isSeller() != draftOrganizationCreateUpdateRequest.getIsSeller()) {
            draftOrganization.setSeller(draftOrganizationCreateUpdateRequest.getIsSeller());
            fieldProcessSuccessful = true;
        }
        if (StringUtils.isNotBlank(draftOrganizationCreateUpdateRequest.getOrgName())
                && !draftOrganizationCreateUpdateRequest.getOrgName().equalsIgnoreCase(draftOrganization.getOrgName())) {
            draftOrganization.setOrgName(draftOrganizationCreateUpdateRequest.getOrgName());
            fieldProcessSuccessful = true;
        }
        if (draftOrganizationCreateUpdateRequest.getOrgStatus() != null) {
            fieldProcessSuccessful = true;
        }
        return fieldProcessSuccessful;
    }

    private boolean processStatus(DraftOrganization draftOrganization, DraftOrganizationCreateUpdateRequest draftOrganizationCreateUpdateRequest) {
        if (draftOrganizationCreateUpdateRequest.getOrgStatus() != null) {
            if (draftOrganization.getOrgStatus() != DraftOrganization.Status.APPROVED.getVal()) {
                if (draftOrganization.getOrgStatus() == draftOrganizationCreateUpdateRequest.getOrgStatus()) {
                    logger.error("Existing DraftOrganization and update request has no status changes to process.");
                    return false;
                } else {
                    draftOrganization.setOrgStatus(draftOrganizationCreateUpdateRequest.getOrgStatus());
                }
                if (draftOrganizationCreateUpdateRequest.getOrgStatus() == DraftOrganization.Status.APPROVED.getVal()) {
                    return !processOrganizationCreation(draftOrganization);
                }
                return true;
            }
            logger.error("Can not update the draft state anymore once it already has been set to APPROVED");
            return false;
        }
        return true;
    }


    //careful.. once set to active. can not change the status again. thus no org creation takes place anymore
    private boolean processOrganizationCreation(DraftOrganization draftOrganization) {
        boolean hasDuplicateNameError = false;
        if (!organizationHelper.doesOrganizationExistsWithSameName(draftOrganization.getOrgName())) {
            createOrganizationFromDraft(draftOrganization);
        } else {
            logger.error("Organization already exists in database. Aborting DraftOrganization update");
            hasDuplicateNameError = true;
        }
        return hasDuplicateNameError;
    }

    public DraftOrganization findById(Long id) {
        return draftOrganizationRepository.findById(id).orElse(null);
    }

    private void createOrganizationFromDraft(DraftOrganization draftOrganization) {
        OrganizationCreateUpdateRequest createRequest = OrganizationCreateUpdateRequest.builder()
                .userId(draftOrganization.getUserId())
                .createdBy(draftOrganization.getUserId())
                .roleId(2l)
                .orgName(draftOrganization.getOrgName())
                .isBuyer(draftOrganization.isBuyer())
                .isSeller(draftOrganization.isSeller())
                .build();

        try {
            logger.info("Creating new Organization");
            Organization organization = organizationService.createOrUpdateOrganization(createRequest, null);
            organizationService.addUserToOrganization(organization.getOrgId(), draftOrganization.getUserId());
        } catch (SameNamedOrganizationExistsException e) {
            logger.error("Organization already exists in database.");
            e.printStackTrace();
        }
    }


    public boolean rejectDraft(DraftRejectionDTO draftRejectionDTO) {
        log.info(organizationHelper.getUserRolesByUserId(draftRejectionDTO.getRejectedBy()).getRole().getName());

        if (organizationHelper.getUserRolesByUserId(draftRejectionDTO.getRejectedBy()) != null
                && organizationHelper.getUserRolesByUserId(draftRejectionDTO.getRejectedBy()).getRole().getName().equals("Global Admin")) {

            DraftOrganization draftOrganization = draftOrganizationRepository.findById(draftRejectionDTO.getOrgId()).get();
            draftOrganization.setOrgStatus(DraftOrganization.Status.REJECTED.getVal());
            draftOrganization = draftOrganizationRepository.save(draftOrganization);

            OrgRejectionDetail orgRejectionDetail = OrgRejectionDetail.builder()
                    .createdTime(new Date())
                    .orgId(draftOrganization)
                    .rejectedBy(userService.getUserById(draftRejectionDTO.getRejectedBy()))
                    .reason(draftRejectionDTO.getReason())
                    .build();
            orgRejectionDetailRepository.save(orgRejectionDetail);

            log.info(draftOrganization + " \n         is rejected \n");

            return true;
        }
        return false;
    }

    public boolean isRejected(Long orgId) {
        return draftOrganizationRepository.findById(orgId).get().getOrgStatus() == DraftOrganization.Status.REJECTED.getVal();
    }

    public boolean draftNameExists(String draftName) {
        return draftOrganizationRepository.existsByOrgName(draftName);
    }
}
