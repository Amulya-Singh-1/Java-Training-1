package com.dgmarket.auth.repositories;

import com.dgmarket.auth.entities.ResetPassword;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ResetPasswordRepository extends CrudRepository<ResetPassword, Long> {
    ResetPassword findResetPasswordByCode(String code);
}
