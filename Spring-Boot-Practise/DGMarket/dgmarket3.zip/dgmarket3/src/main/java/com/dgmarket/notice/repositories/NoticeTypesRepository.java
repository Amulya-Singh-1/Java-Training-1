package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.NoticeTypes;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NoticeTypesRepository extends JpaRepository<NoticeTypes,String> {
    List<NoticeTypes> findAll();
    NoticeTypes findByCode(String code);
}
