package com.dgmarket.web.controller;

import com.dgmarket.core.config.Constants;
import com.dgmarket.core.dto.EmailRequestDTO;
import com.dgmarket.core.entities.EmailChannel;
import com.dgmarket.core.entities.EmailType;
import com.dgmarket.core.mail.MailUtility;
import com.dgmarket.web.dto.request.FeedbackRequest;
import com.dgmarket.web.services.FeedbackService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/web")
public class FeedbackController {

    private final MailUtility mailUtility;
    private final FeedbackService feedbackService;

    @PostMapping("/feedback")
    public ResponseEntity<?> feedbackForm(@Valid @RequestBody FeedbackRequest feedbackRequest, HttpSession session){
        final Map<String, Object> body = new HashMap<>();

        String captcha = (String) session.getAttribute("CAPTCHA");
        if (feedbackRequest.getCaptchaText().equals(captcha)) {
            session.removeAttribute("CAPTCHA");
            StringBuffer sb = new StringBuffer("Name : " + feedbackRequest.getName() + "\n" + "Email : " +feedbackRequest.getEmail() + "\n" + "Category : " +feedbackRequest.getCategory() + "\n" + "Sub-Category : " + feedbackRequest.getSubCategory() + "\n" + "Message : " + feedbackRequest.getMessage());
            mailUtility.sendEmail(EmailRequestDTO.builder()
                    .subject("Feedback enquiries from "+feedbackRequest.getName())
                    .body( sb.toString())
                    .toAddresses(List.of(Constants.DG_DEFAULT_SUPPORT_EMAIL))
                    .emailChannel(EmailChannel.SMTP)
                    .emailType(EmailType.targeted)
                    .isHtml(false)
                    .fromAddress(Constants.DG_DEFAULT_NOTIFICATION_EMAIL)
                    .build());
            feedbackService.saveFeedback(feedbackRequest);
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "Feedback enquiry submitted successfully !!");
            return ResponseEntity.ok().body(body);
        } else {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "Captcha not valid");
            return ResponseEntity.badRequest().body(body);
        }

    }

}
