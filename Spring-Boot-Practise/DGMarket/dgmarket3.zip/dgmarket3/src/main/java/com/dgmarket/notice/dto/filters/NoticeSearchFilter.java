package com.dgmarket.notice.dto.filters;

import com.dgmarket.core.dto.request.BaseFilter;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class NoticeSearchFilter extends BaseFilter {

    String keywords;
    String tenderType;
    Long orgId;

    public boolean hasKeywords() {
        return StringUtils.isNotEmpty(this.keywords);
    }
    public boolean hasTenderType() { return StringUtils.isNotEmpty(this.tenderType); }
    public boolean hasOrgId() {
        return orgId != null && orgId > 0;
    }

}
