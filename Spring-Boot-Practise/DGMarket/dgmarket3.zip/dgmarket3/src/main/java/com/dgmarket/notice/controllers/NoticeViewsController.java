package com.dgmarket.notice.controllers;

import com.dgmarket.notice.dto.request.NoticeViewsAndDownloadRequest;
import com.dgmarket.notice.service.NoticeViewService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@RestController
@RequestMapping("/api/notices/views")
public class NoticeViewsController {

    final private NoticeViewService noticeViewService;


    @PostMapping("")
    public ResponseEntity<?> addNoticeViews(@RequestBody NoticeViewsAndDownloadRequest noticeViewsAndDownloadRequest){
        final Map<String,Object> body = new HashMap<>();
        try{
        noticeViewService.addNoticeViews(noticeViewsAndDownloadRequest);
        body.put("status", HttpServletResponse.SC_CREATED);
        body.put("message","Notice View is added successfully.");
        return ResponseEntity.ok(body);}
        catch (Exception e){
            body.put("status",HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            body.put("message","Not saved, Internal server error.");
            return ResponseEntity.status(HttpServletResponse.SC_INTERNAL_SERVER_ERROR).body(body);
        }
    }
}
