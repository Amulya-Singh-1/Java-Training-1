package com.dgmarket.web.dto.response;

import com.dgmarket.web.dto.PartnerListDTO;
import com.dgmarket.web.entities.Partner;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class PartnerListResponse {
    String message;
    int currentPage;
    int totalInPage;
    long totalPartnersCount;
    List<PartnerListDTO> partnerList;
}
