package com.dgmarket.notice.controllers;

import com.dgmarket.notice.dto.request.NoticeViewsAndDownloadRequest;
import com.dgmarket.notice.service.NoticeDownloadsService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@RestController
@RequestMapping("/api/notices")
public class NoticeDownloadsController {
    final private NoticeDownloadsService noticeDownloadsService;

    @PostMapping("/downloads")
    public ResponseEntity<?> addNoticeDownloads(@RequestBody NoticeViewsAndDownloadRequest noticeViewsAndDownloadRequest) {
        final Map<String, Object> body = new HashMap<>();
        noticeDownloadsService.addNoticeDownloads(noticeViewsAndDownloadRequest);
        body.put("status", HttpServletResponse.SC_CREATED);
        body.put("message", "Saved Successfully");
        return ResponseEntity.status(HttpServletResponse.SC_CREATED).body(body);
    }
}
