package com.dgmarket.notice.dto.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
public class NoticeContactInfoRequest {

    @NotNull(message = "Org id should not be null")
    private Integer orgId;

    @NotNull(message = "Notice id should not be blank")
    private Long noticeId;

    private String department;

    private String title;

    @NotBlank(message = "First Name should not be blank")
    private String firstName;

    private String lastName;

    private String address;

    private String city;

    private String state;

    private String postalCode;

    private String country;

    private String phone;

    private String fax;

    @Email(message = "Enter valid email id")
    private String email;

    private String website;

}
