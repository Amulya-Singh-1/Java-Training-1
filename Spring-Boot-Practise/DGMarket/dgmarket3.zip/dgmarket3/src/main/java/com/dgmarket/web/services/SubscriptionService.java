package com.dgmarket.web.services;

import com.dgmarket.web.dto.request.SubscriptionRequest;
import com.dgmarket.web.entities.Subscription;
import com.dgmarket.web.repositories.SubscriptionRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class SubscriptionService {

    final private SubscriptionRepository subscriptionRepository;

    public List<Subscription> findByFilter(Subscription subscription) {

        return subscriptionRepository.findAll().stream()
                .filter(e -> (subscription.getId() == null || (subscription.getId().equals(e.getId())))
                        && (subscription.getOrgId() == null || (subscription.getOrgId().equals(e.getOrgId())))
                        && (subscription.getProductId() == null || (subscription.getProductId().equals(e.getProductId())))
                        && (subscription.getTotalGlobalNotices() == null || (subscription.getTotalGlobalNotices().equals(e.getTotalGlobalNotices())))
                        && (subscription.getRemainingGlobalNotices() == null || (subscription.getRemainingGlobalNotices().equals(e.getRemainingGlobalNotices())))
                        && (subscription.getStartDate() == null || (subscription.getStartDate().equals(e.getStartDate())))
                        && (subscription.getExpirationDate() == null || (subscription.getExpirationDate().equals(e.getExpirationDate())))
                        && (subscription.getRenewalStatus() == null || (subscription.getRenewalStatus().equals(e.getRenewalStatus())))
                        && (subscription.getTransactionId() == null || (subscription.getTransactionId().equals(e.getTransactionId())))
                        && (subscription.getAutoRenew() == null || (subscription.getAutoRenew().equals(e.getAutoRenew())))
                        && (subscription.getActive() == null || (subscription.getActive().equals(e.getActive())))
                ).collect(Collectors.toList());

    }

    public Subscription addSubscription(SubscriptionRequest subscriptionRequest){
        Subscription subscription = new Subscription(null,
                subscriptionRequest.getOrgId(),
                subscriptionRequest.getProductId(),
                subscriptionRequest.getTotalGlobalNotices(),
                subscriptionRequest.getRemainingGlobalNotices(),
                subscriptionRequest.getStartDate(),
                subscriptionRequest.getExpirationDate(),
                subscriptionRequest.getRenewalStatus(),
                subscriptionRequest.getTransactionId(),
                subscriptionRequest.getAutoRenew(),
                subscriptionRequest.getActive()
        );
        return subscriptionRepository.save(subscription);
    }

    public boolean existByOrgId(Long orgId){
        return subscriptionRepository.existsByOrgId(orgId);
    }
}
