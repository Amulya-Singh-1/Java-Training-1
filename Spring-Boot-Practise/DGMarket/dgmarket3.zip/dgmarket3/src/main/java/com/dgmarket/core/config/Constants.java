package com.dgmarket.core.config;

import java.time.ZoneId;

public class Constants {
    public static final String DG_DEFAULT_FROM_EMAIL = "dg3dev-notifications@dgmarket.com";
    public static final String DG_DEFAULT_SUPPORT_EMAIL = "dg3dev@dgmarket.com";
    public static final String DG_DEFAULT_NOTIFICATION_EMAIL = "notifications@dgmarket.com";

    public static final String HTTP_SESSION_KEY_CURRENT_COUNTRY = "dgMarket.currentCountry";

    public static final ZoneId DATABASE_DATES_ZONE_ID = ZoneId.of("America/New_York");
    public static final String DEFAULT_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DEFAULT_DATE_TIME_UI= "dd-MM-yyyy HH:mm:ss";
//    public static final String UPLOAD_DIR = "D:\\DGMarket Project\\dgmarket3\\resources";
    public static final String UPLOAD_DIR = "s3://dg3-dev-docstore";

}
