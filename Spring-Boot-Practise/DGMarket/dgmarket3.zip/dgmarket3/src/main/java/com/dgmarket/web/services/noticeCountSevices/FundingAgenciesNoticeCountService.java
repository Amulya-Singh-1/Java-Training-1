package com.dgmarket.web.services.noticeCountSevices;

import com.dgmarket.web.entities.views.FundingAgenciesNoticeCount;
import com.dgmarket.web.repositories.FundingAgenciesNoticeCountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class FundingAgenciesNoticeCountService {
    final private FundingAgenciesNoticeCountRepository fundingAgenciesNoticeCountRepository;


    public List<FundingAgenciesNoticeCount> filteredList(FundingAgenciesNoticeCount fundingAgenciesNoticeCount) {
        List<FundingAgenciesNoticeCount> list = fundingAgenciesNoticeCountRepository.findAll();

        List<FundingAgenciesNoticeCount> counts =
                list.stream().filter(e ->
                (e.getAgencyId().equals(fundingAgenciesNoticeCount.getAgencyId() == null ? e.getAgencyId() : fundingAgenciesNoticeCount.getAgencyId())
                        &&
                        e.getName().equals((fundingAgenciesNoticeCount.getName() == null ? e.getName() : fundingAgenciesNoticeCount.getName()))
                        &&
                        e.getCount().equals((fundingAgenciesNoticeCount.getCount() == null ? e.getCount() : fundingAgenciesNoticeCount.getCount()))))
                .collect(Collectors.toList());
        return counts;
    }
}
