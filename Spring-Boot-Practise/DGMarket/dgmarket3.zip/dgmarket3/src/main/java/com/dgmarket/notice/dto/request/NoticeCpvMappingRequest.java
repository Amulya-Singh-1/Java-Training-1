package com.dgmarket.notice.dto.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
public class NoticeCpvMappingRequest {

    @NotNull(message = "Notice id should not be blank")
    private Long noticeId;
    @NotBlank(message = "Cpv id's should not be blank")
    private String cpvId;
    private boolean isPrimary;

}
