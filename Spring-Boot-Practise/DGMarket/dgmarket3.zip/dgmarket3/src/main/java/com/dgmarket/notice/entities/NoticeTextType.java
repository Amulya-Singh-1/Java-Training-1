package com.dgmarket.notice.entities;

public enum NoticeTextType {
    summary, qual_crit, full_text, title
}
