package com.dgmarket.web.services.noticeCountSevices;

import com.dgmarket.web.entities.views.OrgWiseNoticeCount;
import com.dgmarket.web.repositories.OrgWiseNoticeCountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class OrgWiseNoticeCountService {
    final private OrgWiseNoticeCountRepository orgWiseNoticeCountRepository;

    public List<OrgWiseNoticeCount> findByOrgName(String orgName){
        return orgWiseNoticeCountRepository.findByOrgNameContainingIgnoreCase(orgName);
    }
    public List<OrgWiseNoticeCount> findAll(){
        return orgWiseNoticeCountRepository.findAll();
    }
}
