package com.dgmarket.organization.dto.request.update;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Builder
@Data
public class BuyerSettingUpdateDTO {
    @NotNull
    private Long orgId;
    private Integer buyerType;
}
