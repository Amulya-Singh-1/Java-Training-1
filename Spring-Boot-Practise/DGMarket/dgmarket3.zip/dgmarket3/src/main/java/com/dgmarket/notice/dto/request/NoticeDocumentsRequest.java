package com.dgmarket.notice.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoticeDocumentsRequest {

    private Long noticeId;

    private String documentDescription;

    private String documentType;

    @Override
    public String toString() {
        return "NoticeDocumentsRequest [noticeId=" + noticeId + ", documentDescription=" + documentDescription + ", documentType=" + documentType + "]";
    }

}
