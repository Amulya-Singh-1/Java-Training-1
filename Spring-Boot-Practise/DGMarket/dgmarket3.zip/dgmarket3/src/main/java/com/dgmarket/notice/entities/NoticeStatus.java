package com.dgmarket.notice.entities;

import org.apache.commons.lang3.StringUtils;

public enum NoticeStatus {
    draft, hidden, imported, published, submitted, version, cpv, unpublished;

    public String getCapitalizedName() {
        return StringUtils.capitalize(name());
    }
}