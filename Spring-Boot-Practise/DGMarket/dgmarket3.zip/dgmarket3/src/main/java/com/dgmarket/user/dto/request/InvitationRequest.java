package com.dgmarket.user.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@AllArgsConstructor
@Builder
public class InvitationRequest {

    @NotNull
    @Digits(fraction = 0, integer = 10)
    private Long userId;
    @Digits(fraction = 0, integer = 10)
    private Long orgId;
    @NotBlank(message = "email should not be blank.")
    @Email
    private String email;
    @Digits(fraction = 0, integer = 10)
    private Long roleId;
}
