package com.dgmarket.user.repositories;

import com.dgmarket.user.entities.UserPreferences;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface UserPreferencesRepository extends CrudRepository<UserPreferences,Long> {
    List<UserPreferences> findAllByUserIdAndAndUserDataKey(Long userId,String userDataKey);
}