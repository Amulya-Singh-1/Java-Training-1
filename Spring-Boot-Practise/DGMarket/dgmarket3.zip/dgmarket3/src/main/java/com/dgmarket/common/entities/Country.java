package com.dgmarket.common.entities;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Where;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.IOException;
import java.io.Serializable;

@Entity
@Table(name = "countries")
@Data
@Where(clause = "type = 'country'")
@NoArgsConstructor
@JsonSerialize(using = Country.CountrySerializer.class)
public class Country implements Serializable {
    @Id
    private String iso;

    @Column(name = "country_name")
    private String countryName;

    @Column(name = "message_lang_key")
    private String messageLangKey;

    public Country(String iso) {
        this.iso = iso;
    }

    public static class CountrySerializer extends StdSerializer<Country> {

        public CountrySerializer() {
            this(null);
        }

        public CountrySerializer(Class<Country> t) {
            super(t);
        }

        @Override
        public void serialize(Country country, JsonGenerator jgen, SerializerProvider provider) throws IOException, JsonProcessingException {
            jgen.writeString(country.iso);
        }
    }
}