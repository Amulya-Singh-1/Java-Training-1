package com.dgmarket.organization.controllers;

import com.dgmarket.organization.entities.OrganizationType;
import com.dgmarket.organization.services.OrganizationTypeService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/org")
public class OrganizationTypeController {

    private final OrganizationTypeService organizationTypeService;

    @GetMapping("/types")
    public ResponseEntity<?> getBuyerOrg() {
        final Map<String, Object> body = new HashMap<>();
        body.put("status", HttpServletResponse.SC_OK);
        List<OrganizationType> organizationTypeList = organizationTypeService.getBuyerOrgList();
        if (organizationTypeList != null && organizationTypeList.size() > 0) {
            body.put("response", organizationTypeList);
        } else {
            body.put("message", "Organization type list not found");
        }
        return ResponseEntity.ok().body(body);
    }

}
