package com.dgmarket.sibutu.dto.request;

import com.dgmarket.sibutu.entities.SibutuTeam;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@AllArgsConstructor
@ToString
public class SibutuTeamRequest {
    private Long noticeId;
    private Long userId;

    private SibutuTeam.Role role;

}
