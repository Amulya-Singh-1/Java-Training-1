package com.dgmarket.auth.services;

import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.exception.UserEmailNotVerifiedException;
import com.dgmarket.user.entities.User;
import com.dgmarket.user.repositories.UserRoleRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class UserDetailsServiceImpl implements org.springframework.security.core.userdetails.UserDetailsService {

    private final UserRepository userRepository;
    private final UserRoleRepository userRoleRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = userRepository.findByEmailIgnoreCase(email);
        if (user == null)
            throw new UsernameNotFoundException("Invalid Username/Password !");
        validateUser(user);
        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
        getUserRole(user.getId()).forEach(role -> grantedAuthorities.add(new SimpleGrantedAuthority(role)));

        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), grantedAuthorities);
    }

    public User getUserByEmail(String email) {
        User userEntity = userRepository.findByEmailIgnoreCase(email);
        if (userEntity == null) {
            throw new UsernameNotFoundException(email);
        }
        return userRepository.findByEmailIgnoreCase(email);
    }


    private void validateUser(User user) throws UserEmailNotVerifiedException {
        if (!user.isActive())
            throw new DisabledException("User is not active");
        if(!user.isEmailVerified())
            throw new UserEmailNotVerifiedException("User email not verified");
    }

    private List<String> getUserRole(long userId) {
        return userRoleRepository.findAllByUserId(userId).stream().map(userRoles -> userRoles.getRole().getName()).collect(Collectors.toList());
    }
}