package com.dgmarket.notice.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LocalMessagePK implements Serializable {
    @Column(name = "message_key")
    private String messageKey;

    @Column(name = "lang_iso")
    private String language;

    private String siteId;
}
