package com.dgmarket.notice.entities;

import com.dgmarket.user.entities.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "notice_views")
@NoArgsConstructor
@AllArgsConstructor
public class NoticeViews {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne
    @JoinColumn(name = "user_id",referencedColumnName = "id")
    private User user;
    @OneToOne
    @JoinColumn(name = "notice_id", referencedColumnName = "notice_id")
    private Notice notice;
    private Date seenTime;
}
