package com.dgmarket.notice.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Digits;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AwardRequest {
    private Long orgId;
    private String bidderName;
    private String address;
    @Digits(fraction = 4, integer = 10)
    private Long initialEstimatedValue;
    @Digits(fraction = 4, integer = 10)
    private Long finalEstimatedValue;
    @Digits(fraction = 0, integer = 10)
    private Long bidRecieved;
    private Long contractDuration;
    private Date awardDate;
    @Digits(integer = 1, fraction = 0)
    private Integer status;
}
