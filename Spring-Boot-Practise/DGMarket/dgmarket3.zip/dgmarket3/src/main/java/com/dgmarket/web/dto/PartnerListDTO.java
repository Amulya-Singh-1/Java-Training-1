package com.dgmarket.web.dto;
import lombok.*;
import org.springframework.stereotype.Component;

@Component
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PartnerListDTO {

    private Long id;
    private String name;
    private String partnerType;
    private String sites;
    private String country;
    private String url;
    private boolean active;

}

