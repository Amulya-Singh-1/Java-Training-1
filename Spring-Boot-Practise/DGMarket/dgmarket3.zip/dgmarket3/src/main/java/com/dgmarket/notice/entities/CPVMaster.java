package com.dgmarket.notice.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Builder
@Entity
@Table(name = "cpv_master")
@AllArgsConstructor
@NoArgsConstructor
public class CPVMaster {

    @Id
    private String code;
    private String name;
    @Column(name = "parent_code")
    private String parentCode;
    private boolean active;

}
