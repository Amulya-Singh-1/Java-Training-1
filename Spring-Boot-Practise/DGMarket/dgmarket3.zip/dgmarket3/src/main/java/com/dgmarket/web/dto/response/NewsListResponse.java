package com.dgmarket.web.dto.response;

import com.dgmarket.web.dto.NewsListDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class NewsListResponse {
    String message;
    int currentPage;
    int totalInPage;
    long totalNewsCount;
    List<NewsListDTO> newsList;
}
