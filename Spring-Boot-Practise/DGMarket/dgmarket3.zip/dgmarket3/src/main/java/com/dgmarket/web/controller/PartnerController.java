package com.dgmarket.web.controller;

import com.dgmarket.web.dto.PartnerPageDTO;
import com.dgmarket.web.dto.response.PartnerListResponse;
import com.dgmarket.web.entities.Partner;
import com.dgmarket.web.services.PartnerService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("/api/partners")
public class PartnerController {

    private final PartnerService partnerService;

    private static final Logger logger = LoggerFactory.getLogger(PartnerController.class);

    /*
     * first autowired partnerService inside this class
     * Then after creating getAllPartners() method inside this class
     * Then after getting the getAllPartners list from partnerService.getAll Partners()
     */
    @GetMapping("/")
    public ResponseEntity<PartnerListResponse> getAllPartners(PartnerPageDTO partnerPageDTO) {
        PartnerListResponse partnerListResponse = partnerService.preparePartnerList(partnerPageDTO);
        if (partnerListResponse.getPartnerList() == null) {
            logger.warn("No partner found, partner list is empty. for partner list api");
            return ResponseEntity.badRequest().body(PartnerListResponse.builder()
                    .currentPage(0)
                    .message("partner list is empty!")
                    .totalInPage(0)
                    .build());
        } else {
            logger.info("fetched list of partner from database. for partner list api");
            logger.info("populating fields in PartnerListResponse. for partner list api");
            return ResponseEntity.ok().body(partnerListResponse);
        }

    }

    /* we can create the new partners
    * By using createDgPartners method*/
    @PostMapping("/")
    public Partner createPartners(@RequestBody Partner partner) {
        return partnerService.createPartners(partner);
    }

    /*
    * we can Update the record in the table
    * by using  updatePartner Method */
    @PutMapping("{id}")
    public ResponseEntity<Partner> updatePartner(@PathVariable("id") Long id, @RequestBody Partner partner) {
        partnerService.updatePartner(id, partner);
        return new ResponseEntity<>(partnerService.getPartnerById(id), HttpStatus.OK);
    }

}
