package com.dgmarket.user.dto.response;

import com.dgmarket.organization.dto.response.BaseOrganizationDTO;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class UserProfileData {

    private String username;
    private String email;
    private String tendersInterestedIn;
    private List<String> interestedSectors;
    private String phoneNo;
    private String localLanguage;
    private String website;

    private List<BaseOrganizationDTO> baseOrganizationDTOList;

}
