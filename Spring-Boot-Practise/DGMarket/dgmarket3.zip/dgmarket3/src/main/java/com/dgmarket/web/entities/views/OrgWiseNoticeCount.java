package com.dgmarket.web.entities.views;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "org_wise_notice_count")
public class OrgWiseNoticeCount {
    @Id
    private Long orgId;
    private String orgName;
    private Long count;
}
