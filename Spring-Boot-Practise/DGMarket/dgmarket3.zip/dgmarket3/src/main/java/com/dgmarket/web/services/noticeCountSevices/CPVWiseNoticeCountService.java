package com.dgmarket.web.services.noticeCountSevices;

import com.dgmarket.web.entities.views.CPVWiseNoticeCount;
import com.dgmarket.web.repositories.CPVWiseNoticeCountRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class CPVWiseNoticeCountService {
    final private CPVWiseNoticeCountRepository cpvWiseNoticeCountRepository;

    public List<CPVWiseNoticeCount> getFilteredList(CPVWiseNoticeCount cpvWiseNoticeCount){
        List<CPVWiseNoticeCount> list= cpvWiseNoticeCountRepository.findAll();
        List<CPVWiseNoticeCount> counts = list.stream().filter(e ->
                e.getCode().equals((cpvWiseNoticeCount.getCode()==null?e.getCode():cpvWiseNoticeCount.getCode()))
        &&
                e.getName().equals((cpvWiseNoticeCount.getName()==null?e.getName():cpvWiseNoticeCount.getName()))
        &&
                e.getCount().equals((cpvWiseNoticeCount.getCount()==null?e.getCount():cpvWiseNoticeCount.getCount()))
        ).collect(Collectors.toList());
        return  counts;
    }
}
