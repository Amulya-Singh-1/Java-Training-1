package com.dgmarket.notice.service;

import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.notice.dto.request.NoticeViewsAndDownloadRequest;
import com.dgmarket.notice.entities.NoticeDownloads;
import com.dgmarket.notice.repositories.NoticeDownloadsRepository;
import com.dgmarket.notice.repositories.NoticeRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Date;

@AllArgsConstructor
@Service
public class NoticeDownloadsService {

    final private NoticeDownloadsRepository noticeDownloadsRepository;
    final private NoticeRepository noticeRepository;
    final private UserRepository userRepository;

    public NoticeDownloads addNoticeDownloads(NoticeViewsAndDownloadRequest noticeViewsAndDownloadRequest) {
        NoticeDownloads noticeDownloads = new
                NoticeDownloads(null
                , userRepository.findUserById(noticeViewsAndDownloadRequest.getUserId())
                , noticeRepository.findById(noticeViewsAndDownloadRequest.getNoticeId()).orElse(null)
                , new Date()
        );
        return noticeDownloadsRepository.save(noticeDownloads);
    }
}
