package com.dgmarket.organization.dto.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
public class OrganizationInfoDTO {
    @NotNull
    private Long userId;
    @NotBlank(message = "organization name should not be blank")
    private String orgName;
    @Digits(fraction = 0, integer = 20)
    private String referenceNumber;
    private String countryOfOperations;
    private String defaultLanguage;
    private String orgDescription;
}
