package com.dgmarket.web.services;

import com.dgmarket.web.dto.request.FeedbackRequest;
import com.dgmarket.web.entities.Feedback;
import com.dgmarket.web.enums.Category;
import com.dgmarket.web.enums.SubCategory;
import com.dgmarket.web.repositories.FeedbackRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class FeedbackService {

    private final FeedbackRepository feedbackRepository;

    public void saveFeedback(FeedbackRequest feedbackRequest) {
        Feedback feedback = Feedback.builder().
                name(feedbackRequest.getName()).
                email(feedbackRequest.getEmail()).
                category(Category.fromId(feedbackRequest.getCategory())).
                subCategory(SubCategory.fromId(feedbackRequest.getSubCategory())).
                message(feedbackRequest.getMessage()).
                build();
        feedbackRepository.save(feedback);
    }
}
