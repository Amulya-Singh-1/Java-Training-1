package com.dgmarket.web.entities.views;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Data
@Entity
@Table(name = "type_wise_notice_count")
public class TypeWiseNoticeCount {
    @Id
    private String code;
    private String name;
    private Long count;
}
