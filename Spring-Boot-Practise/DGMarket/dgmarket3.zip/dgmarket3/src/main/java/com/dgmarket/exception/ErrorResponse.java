package com.dgmarket.exception;

import java.util.Date;
import java.util.Map;

public class ErrorResponse {

    private Date timestamp;
    private String status;
    private Map<String, String> errorMessage;
    private String details;



    /**
     * Instantiates a new Error response.
     *
     * @param timestamp the timestamp
     * @param status the status
     * @param errorMessage the message
     * @param details the details
     */
    public ErrorResponse(Date timestamp, String status, Map<String, String> errorMessage, String details) {
        this.timestamp = timestamp;
        this.status = status;
        this.errorMessage = errorMessage;
        this.details = details;
    }

    /**
     * Gets timestamp.
     *
     * @return the timestamp
     */
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * Sets timestamp.
     *
     * @param timestamp the timestamp
     */
    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Gets status.
     *
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets status.
     *
     * @param status the status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Gets message.
     *
     * @return the message
     */
    public Map<String, String> getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets message.
     *
     * @param errorMessage the message
     */
    public void setErrorMessage(Map<String, String> errorMessage) {
        this.errorMessage = errorMessage;
    }

    /**
     * Gets details.
     *
     * @return the details
     */
    public String getDetails() {
        return details;
    }

    /**
     * Sets details.
     *
     * @param details the details
     */
    public void setDetails(String details) {
        this.details = details;
    }

}
