package com.dgmarket.organization.services;

import com.dgmarket.organization.entities.OrganizationType;

import java.util.List;

public interface OrganizationTypeService {
    List<OrganizationType> getBuyerOrgList();
}
