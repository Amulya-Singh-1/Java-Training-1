package com.dgmarket.user.controllers;

import com.dgmarket.auth.dto.request.ChangePasswordRequest;
import com.dgmarket.auth.dto.request.RegistrationRequest;
import com.dgmarket.auth.dto.request.SignInRequest;
import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.auth.services.AuthService;
import com.dgmarket.user.dto.filter.UserFilter;
import com.dgmarket.user.dto.request.InvitationRequest;
import com.dgmarket.user.entities.User;
import com.dgmarket.user.services.InvitationService;
import com.dgmarket.user.services.UserService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final AuthService authService;
    private final UserRepository userRepository;
    private final PasswordEncoder encoder;
    private final InvitationService invitationService;

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);


    @PostMapping("/changePassword")
    public ResponseEntity<?> changePassword(@Valid @RequestBody ChangePasswordRequest changePasswordRequest) {
        final Map<String, Object> body = new HashMap<>();
        User user = userRepository.findUserById(changePasswordRequest.getId());
        if (user == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "User record not found !!");
            return ResponseEntity.badRequest().body(body);
        }
        if (!(matchCurrentPassword(changePasswordRequest.getCurrentPassword(), user))) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "Current Password doesn't not match !!");
            return ResponseEntity.badRequest().body(body);
        } else {
            if (changePasswordRequest.getPassword().equals(changePasswordRequest.getConfirmPassword())) {
                userService.updatePassword(user, changePasswordRequest.getPassword());
                body.put("status", HttpServletResponse.SC_OK);
                body.put("message", "User password changed successfully !!");
                body.put("user", authService.getUserDTO(user.getEmail()));
                return ResponseEntity.ok()
                        .header(HttpHeaders.SET_COOKIE,
                                authService.logIn(
                                        SignInRequest.builder()
                                                .email(user.getEmail())
                                                .password(changePasswordRequest.getPassword())
                                                .build()
                                ).toString())
                        .body(body);
            } else {
                body.put("status", HttpServletResponse.SC_CONFLICT);
                body.put("message", "Password and confirm password should be same !!");
                return ResponseEntity.badRequest().body(body);
            }
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> userDetails(@PathVariable("id") Long id) {
        final Map<String, Object> body = new HashMap<>();
        User user = userService.getUserById(id);
        if (user == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "User not found with the given ID");
            return ResponseEntity.badRequest().body(body);
        }
        return ResponseEntity.ok().body(userService.getUserProfileDataDTO(user));
    }

    @GetMapping("")
    public ResponseEntity<?> getUsers(UserFilter filter) {
        final Map<String, Object> body = new HashMap<>();
        body.put("status", HttpServletResponse.SC_OK);
        body.put("users", userService.getUserListResponse(filter));
        return ResponseEntity.ok(body);
    }

    //todo:: add permission check. @canCreateUser
    @PostMapping("")
    public ResponseEntity<?> createNewUser(RegistrationRequest registrationRequest) {
        if (userService.doesUserEmailExists(registrationRequest.getEmail())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email already registered!");
        }
        registrationRequest.setRegistrationSource("admin-panel");
        User user = userService.createUser(registrationRequest);
        if (user == null)
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Can not create user. Server Error!");
        return ResponseEntity.status(HttpStatus.CREATED).body("User created successfully!");
    }

    private boolean matchCurrentPassword(String currentPassword, User user) {
        return encoder.matches(currentPassword, user.getPassword());
    }


//--------------------------------------------------INVITATION APIs'---------------------------------------------------------------

    @PostMapping("/invite")
    public ResponseEntity<?> invite(@Valid @RequestBody InvitationRequest invitationRequest) {
        final Map<String, Object> body = new HashMap<>();

        if (invitationService.inviteExists(invitationRequest.getEmail()) || userService.doesUserEmailExists(invitationRequest.getEmail())) {
            body.put("status", HttpServletResponse.SC_FORBIDDEN);
            body.put("message", "Invitee email is already registered or user is already invited. Try using different Email.");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", invitationService.invite(invitationRequest) != null ? "invite sent to mail " + invitationRequest.getEmail() : "Error !! Check email.");
        return ResponseEntity.ok(body);
    }


    @PostMapping("/verifyInvitee")
    public ResponseEntity<?> verify(@RequestParam(name = "token") String token, @Valid @RequestBody RegistrationRequest registrationRequest) {
        final Map<String, Object> body = new HashMap<>();
        if (invitationService.verifyInvitation(token, registrationRequest) == null) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "token is not valid, User not verified. ");
            return ResponseEntity.status(HttpServletResponse.SC_BAD_REQUEST).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", "user verified !!");
        return ResponseEntity.status(HttpServletResponse.SC_OK).body(body);
    }


}
