package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.CPVMaster;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CPVMasterRepository extends JpaRepository<CPVMaster, String> {
    Page<CPVMaster> findAllByNameContainingIgnoreCase(String keyword, Pageable pageable);
}
