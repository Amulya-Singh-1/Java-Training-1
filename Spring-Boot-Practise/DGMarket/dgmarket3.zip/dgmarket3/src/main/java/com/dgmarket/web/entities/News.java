package com.dgmarket.web.entities;

import com.dgmarket.common.entities.Country;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString(of = {"id", "createDate"})
@Entity
@Table(name = "news")
public class News {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "news")
    @SequenceGenerator(name = "news", sequenceName = "ep_news_id_seq", allocationSize = 1)
    private Long id;

    @Column(name = "news_type")
    private String newsType;

    @Column
    private String headline;

    @Column
    private String text;

    @Column
    private String source;

    @Column(name = "create_date")
    private Date createDate;

    @OneToOne
    @JoinColumn(name = "country_iso")
    private Country country;

}