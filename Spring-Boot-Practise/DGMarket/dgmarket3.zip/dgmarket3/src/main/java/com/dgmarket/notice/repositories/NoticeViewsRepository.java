package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.NoticeViews;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NoticeViewsRepository extends JpaRepository<NoticeViews,Long> {
}
