package com.dgmarket.core.dto;

import com.dgmarket.core.entities.EmailChannel;
import com.dgmarket.core.entities.EmailType;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Builder
@Data
@ToString(of = {"subject", "body"})
public class EmailRequestDTO {
    //usually fromAddress is Constants.DG_DEFAULT_FROM_EMAIL
    //or dgMarket Support <dgmarket@dgmarket.in>
    String fromAddress;
    String subject;
    String body;
    List<String> toAddresses;
    EmailType emailType;
    EmailChannel emailChannel;
    boolean isHtml;
}
