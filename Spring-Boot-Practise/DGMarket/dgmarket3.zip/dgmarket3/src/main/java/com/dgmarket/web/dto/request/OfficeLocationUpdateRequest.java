package com.dgmarket.web.dto.request;

import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class OfficeLocationUpdateRequest {

    private String name;
    private String type;
    private Long orgId;
    private String country;
    private String pincode;
    private String city;
    private String state;
    private String flatNo;
    private String locality;
    private String contactNumber;
    private String email;

}
