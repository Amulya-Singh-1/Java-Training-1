package com.dgmarket.seller.repositories;

import com.dgmarket.seller.entities.Assignments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AssignmentsRepository extends JpaRepository<Assignments, Long> {
}
