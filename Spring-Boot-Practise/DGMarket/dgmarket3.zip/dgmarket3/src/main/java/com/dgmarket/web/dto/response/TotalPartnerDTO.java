package com.dgmarket.web.dto.response;

import com.dgmarket.web.dto.PartnerListDTO;
import lombok.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TotalPartnerDTO {
    private Long totalPartner;
    private List<PartnerListDTO> partnerList;
}
