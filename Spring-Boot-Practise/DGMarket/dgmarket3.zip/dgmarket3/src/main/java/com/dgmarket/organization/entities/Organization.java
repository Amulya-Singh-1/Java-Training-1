package com.dgmarket.organization.entities;

import lombok.*;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "organizations")
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class Organization {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "org_id")
    private Long orgId;
    private Integer orgType;
    private String orgName;
    private String orgDescription;
    private String orgEmail;
    private String orgReferenceNo;
    private String orgAddress;
    private String orgState;
    private String orgCountry;
    private String orgLanguage;
    private String orgPhone;
    private String orgFax;
    private String orgWebsite;
    private Long orgParentId;
    private Long orgCreatorId;
    private Integer orgStatus;
    private Date createdTime;
    private boolean isBuyer;
    private boolean isSeller;
    private String orgCity;
    private Date lastModifiedTime;
    private String countryOperation;

    public String getBuyerType() {
        if (isBuyer && isSeller)
            return "BOTH";
        if (isBuyer)
            return "BUYER";
        else
            return "SELLER";
    }

    public enum Status {
        DRAFT(0), APPROVED(1), REJECTED(2), SUSPENDED(3);
        int val;

        Status(int _val) {
            this.val = _val;
        }

        public int getVal() {
            return this.val;
        }
    }
}
