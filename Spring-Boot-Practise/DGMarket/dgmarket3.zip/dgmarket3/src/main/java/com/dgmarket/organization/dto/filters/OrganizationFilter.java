package com.dgmarket.organization.dto.filters;

import com.dgmarket.core.dto.request.BaseFilter;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class OrganizationFilter extends BaseFilter {
    String keywords;
    Status status;
    Type type;
    Long userId;
    Boolean isBuyer;
    Boolean isSeller;
    Long parentId;

    public boolean hasKeywords() {
        return StringUtils.isNotEmpty(this.keywords);
    }

    public boolean hasUserId() {
        return (userId != null);
    }

    public boolean hasParentId() {
        return (parentId != null);
    }

    public boolean hasStatus() {
        return (status != null);
    }

    public boolean hasType() {
        return (type != type);
    }

    public Integer getStatus() {
        return this.status.val;
    }

    public Integer getType() {
        return this.type.val;
    }

    enum Status {
        draft(0), approved(1), rejected(2), suspended(3);
        int val;

        Status(int _st) {
            this.val = _st;
        }
    }

    enum Type {
        gov(1), publicCompany(2),
        privateCompany(3), publicSector(4),
        ngo(5), llp(6), corporation(7);

        int val;

        Type(int _type) {
            this.val = _type;
        }
    }
}