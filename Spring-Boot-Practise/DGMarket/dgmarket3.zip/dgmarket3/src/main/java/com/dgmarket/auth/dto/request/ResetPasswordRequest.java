package com.dgmarket.auth.dto.request;

import com.dgmarket.auth.securities.constriant.ValidPassword;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ResetPasswordRequest {
    @Size(min = 8, max = 40)
    @ValidPassword
    @NotBlank(message = "Password can not be blank")
    private String password;

    @Size(min = 8, max = 40)
    @ValidPassword
    @NotBlank(message = "Confirm password can not be blank")
    private String confirmPassword;

    @NotBlank(message = "Token should not be blank")
    @NonNull
    private String token;

    @NotBlank(message = "Captcha should not be blank")
    private String captchaText;
}
