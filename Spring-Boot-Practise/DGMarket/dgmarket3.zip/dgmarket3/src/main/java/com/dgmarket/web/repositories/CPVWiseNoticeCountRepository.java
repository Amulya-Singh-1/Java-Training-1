package com.dgmarket.web.repositories;

import com.dgmarket.web.entities.views.CPVWiseNoticeCount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CPVWiseNoticeCountRepository extends JpaRepository<CPVWiseNoticeCount,String> {
}
