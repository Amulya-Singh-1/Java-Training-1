# Notice Package Overview
Before starting please download this intellij idea plugin 👉🏼 [RESTKit](https://plugins.jetbrains.com/plugin/14723-restkit).
This plugin automatically picks up all the routes/api and shows within intellij Idea.

Withing intellij Idea, double press **SHIFT** quickly, then type **RESTKit** and press Enter. On this new window, 
click on each route to check each API's accepted data fields

#CATEGORY / SECTOR
Notice package handles below routes:

* **/api/categories** (GET)
To get list of all available sectors. **Route is Protected** Login first and use the token to access this route

**API Request Header**
```
Cookie: dg3WebToken=eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0M0BkZ21hcmtldC5jb20iLCJpYXQiOjE2NDk5MzI0NzksImV4cCI6MTY1MDAxODg3OX0.AnFQczk0VzEbb4fy7K1FGJQebkeddr9asGM439mGDtCZhkbBzUbZr-avStxTrtO0vk5CINOWWkLGpqmArWeZIg
```
Add cookie in your request header

**API Response**
```
[
  {
    "id": 1,
    "name": "Agriculture and Food"
  },
  .....
  .....
  .....
]
```