package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.Notice;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface NoticeRepository extends JpaRepository<Notice,Long>, JpaSpecificationExecutor<Notice> {


    @Query("select n.id from Notice n where n.noticeTitle like concat('%', :searchKey, '%')")
    Page<Long> findNoticeIdsMatchingQueryKeyword(String searchKey, Pageable pageable);

    @Query("select n.id from Notice n where n.performanceCountry= :country and n.organization.orgId=:orgId and n.noticeTitle like concat('%', :searchKey, '%') ")
    Page<Long> findNoticeIdsMatchingQueryKeywordAndCountryAndOrg(String searchKey, String country, Long orgId, Pageable pageable);

    @Query("select n.id from Notice n where n.performanceCountry not in (:country) and n.organization.orgId=:orgId and n.noticeTitle like concat('%', :searchKey, '%') ")
    Page<Long> findNoticeIdsMatchingQueryKeywordAndNotCountryAndOrg(String searchKey, String country, Long orgId, Pageable pageable);

    @Query("select n.id from Notice n where n.id IS NOT NULL")
    Page<Long> findAllNoticeIds(Pageable pageable);

    @Query("select n.id from Notice n where n.performanceCountry= :country")
    Page<Long> findNoticeIdsMatchingQueryCountry(String country, Pageable pageable);

    @Query("select n.id from Notice n where n.performanceCountry not in (:country)")
    Page<Long> findNoticeIdsMatchingQueryNotCountry(String country, Pageable pageable);

    @Query("select n.id from Notice n where n.performanceCountry= :country and n.noticeTitle like concat('%', :searchKey, '%') ")
    Page<Long> findNoticeIdsMatchingQueryKeywordAndCountry(String searchKey, String country, Pageable pageable);

    @Query("select n.id from Notice n where n.performanceCountry not in (:country) and n.noticeTitle like concat('%', :searchKey, '%') ")
    Page<Long> findNoticeIdsMatchingQueryKeywordAndNotCountry(String searchKey, String country, Pageable pageable);

    @Query("select n.id from Notice n where n.performanceCountry= :country and n.organization.orgId=:orgId")
    Page<Long> findNoticeIdsMatchingQueryCountryAndOrg(Long orgId, String country, Pageable pageable);

    @Query("select n.id from Notice n where n.performanceCountry not in (:country) and n.organization.orgId=:orgId")
    Page<Long> findNoticeIdsMatchingQueryNotCountryAndOrg(Long orgId, String country, Pageable pageable);

    @Query("select n.id from Notice n where n.organization.orgId=:orgId and n.noticeTitle like concat('%', :searchKey, '%') ")
    Page<Long> findNoticeIdsMatchingQueryAndOrg(String searchKey, Long orgId, Pageable pageable);

    @Query("select n.id from Notice n where n.organization.orgId=:orgId")
    Page<Long> findNoticeIdsForOrg(Long orgId, Pageable pageable);

    Page<Notice> findAll(Specification<Notice> spec, Pageable pageable);

    @Query("SELECT count(n.id) as count FROM Notice n WHERE n.publishDate >=:date")
    Page<Long> countAllByPublishDateGreaterThan(Date date, Pageable pageable);

}
