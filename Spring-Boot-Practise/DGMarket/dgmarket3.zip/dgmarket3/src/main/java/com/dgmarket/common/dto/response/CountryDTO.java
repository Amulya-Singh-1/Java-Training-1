package com.dgmarket.common.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@AllArgsConstructor
@Builder
@Data
public class CountryDTO {
    String iso;
    String countryName;
}