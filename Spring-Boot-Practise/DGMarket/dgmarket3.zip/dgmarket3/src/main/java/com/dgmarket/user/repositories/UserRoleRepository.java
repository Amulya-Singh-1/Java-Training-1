package com.dgmarket.user.repositories;

import com.dgmarket.user.entities.User;
import com.dgmarket.user.entities.UserRoles;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRoleRepository extends CrudRepository<UserRoles, Long> {
    List<UserRoles> findAllByUserId(long userId);

    UserRoles findByUserIdAndOrgId(long userId, long orgId);

    Page<UserRoles> findAllByUserIdOrderByCreatedTimeDesc(Long userId, Pageable pageable);

    Page<UserRoles> findAllByUserIdAndRoleIdOrderByCreatedTimeDesc(Long userId, Long roleId, Pageable pageable);

    List<UserRoles> findAllByUserIdOrderByCreatedTimeDesc(Long userId);

    List<UserRoles> findAllByOrgId(Long orgId);
}
