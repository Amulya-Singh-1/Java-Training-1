package com.dgmarket.web.controller;

import com.dgmarket.web.dto.NewsPageDTO;
import com.dgmarket.web.dto.response.NewsListResponse;
import com.dgmarket.web.entities.News;
import com.dgmarket.web.services.NewsService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;


@RestController
@RequiredArgsConstructor
@RequestMapping("/api/news")
public class NewsController {

    private final NewsService newsService;

    private static final Logger logger = LoggerFactory.getLogger(News.class);

    @GetMapping("/")
    public ResponseEntity<?> getAllNewsList(NewsPageDTO newsPageDTO) {
        final Map<String , Object> body = new HashMap<>();
        NewsListResponse newsListResponse = newsService.prepareNewsList(newsPageDTO);
        if (newsListResponse.getNewsList() == null) {
            body.put("status",HttpServletResponse.SC_BAD_REQUEST);
            body.put("response",NewsListResponse.builder()
                    .currentPage(0)
                    .message("news list is empty!")
                    .totalInPage(0)
                    .build());
            logger.warn("No news found, news list is empty for news list api");
            return ResponseEntity.badRequest().body(body);
        } else {
            logger.info("fetched list of news from database. for news list api");
            logger.info("populating fields in NewsListResponse. for news list api");
            body.put("status",HttpServletResponse.SC_OK);
            body.put("response",NewsListResponse.builder()
                    .currentPage(newsPageDTO.getPageNo())
                    .newsList(newsListResponse.getNewsList())
                    .totalInPage(newsPageDTO.getPageSize())
                    .totalNewsCount(newsListResponse.getTotalNewsCount())
                    .build());
            return ResponseEntity.status(HttpServletResponse.SC_OK).body(body);
        }
    }

    @GetMapping("{id}")
    public ResponseEntity<?> getNewsDetailsById(@PathVariable("id") long id) {
        final Map<String, Object> body = new HashMap<>();
        News news = newsService.getNewsDetailsById(id);
        if(news != null){
            body.put("status", HttpServletResponse.SC_OK);
            body.put("news", newsService.populateNewsDto(news));
            return ResponseEntity.ok(body);
        }
        body.put("status", HttpServletResponse.SC_NOT_FOUND);
        body.put("message", "News not found for given ID !!.");
        return ResponseEntity.badRequest().body(body);
    }


}
