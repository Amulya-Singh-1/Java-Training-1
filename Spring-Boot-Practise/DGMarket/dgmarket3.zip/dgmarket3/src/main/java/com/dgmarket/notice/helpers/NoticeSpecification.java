package com.dgmarket.notice.helpers;

import com.dgmarket.notice.dto.filters.NoticeFilter;
import com.dgmarket.notice.entities.Notice;
import com.dgmarket.notice.entities.NoticeStatus;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import javax.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

@Component
public class NoticeSpecification {

    public Specification<Notice> findNotices(NoticeFilter filter) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            if(filter.hasCountryIso())
                predicates.add(criteriaBuilder.equal(root.get("performanceCountry"), filter.getCountryIso()));

            if(filter.hasLanguage())
                predicates.add(criteriaBuilder.equal((root.get("mainLanguage")), filter.getLanguage()));

            if(filter.hasNoticeType())
                predicates.add(criteriaBuilder.equal(root.get("noticeType").get("code"), filter.getNoticeType()));

            if(filter.hasNoticeStatus())
                predicates.add(criteriaBuilder.equal(root.get("status"), NoticeStatus.valueOf(filter.getNoticeStatus())));

            if(filter.hasOrgId())
                predicates.add(root.get("organization").in(filter.getOrgId()));

            query.orderBy(criteriaBuilder.desc(root.get("id")));
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

}
