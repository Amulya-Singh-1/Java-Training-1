package com.dgmarket.notice.service;

import com.dgmarket.notice.dto.request.DetailedInformationRequest;
import com.dgmarket.notice.entities.CompletedSteps;
import com.dgmarket.notice.entities.Notice;
import com.dgmarket.notice.entities.NoticeDetail;
import com.dgmarket.notice.repositories.NoticeDetailRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class NoticeDetailService {

    private final NoticeDetailRepository noticeDetailRepository;
    private final NoticeService noticeService;

    public void propagateAndSaveNoticeDetail(Notice notice, DetailedInformationRequest detailedInformationRequest) {
        NoticeDetail noticeDetail = noticeDetailRepository.save(NoticeDetail.builder()
                .notice(notice)
                .officalText(detailedInformationRequest.getTextOfNotice())
                .externalUrl(detailedInformationRequest.getExternalUrl())
                .build());
        if(noticeDetail != null){
            notice.setCompletedSteps(CompletedSteps.detail);
            noticeService.createNotice(notice);
        }
    }

    public NoticeDetail findNoticeDetailByNoticeId(Long noticeId) {
        return noticeDetailRepository.findByNoticeId(noticeId);
    }

    public void updateNoticeDetail(NoticeDetail noticeDetail, DetailedInformationRequest detailedInformationRequest) {
        noticeDetail.setOfficalText(detailedInformationRequest.getTextOfNotice());
        noticeDetail.setExternalUrl(detailedInformationRequest.getExternalUrl());
        noticeDetailRepository.save(noticeDetail);
    }
}
