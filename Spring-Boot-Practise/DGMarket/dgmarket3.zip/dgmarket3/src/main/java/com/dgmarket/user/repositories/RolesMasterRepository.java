package com.dgmarket.user.repositories;

import com.dgmarket.user.entities.RolesMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface RolesMasterRepository extends CrudRepository<RolesMaster, Long> {
}
