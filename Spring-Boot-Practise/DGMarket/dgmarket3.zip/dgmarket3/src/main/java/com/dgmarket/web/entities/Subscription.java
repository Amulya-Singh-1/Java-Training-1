package com.dgmarket.web.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.util.Date;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "subscriptions")
public class Subscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long orgId;
    private Long productId;
    private Long totalGlobalNotices;
    private Long remainingGlobalNotices;
    @Temporal(TemporalType.DATE)
    private Date startDate;
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(fallbackPatterns = "yyyy-MM-dd")
    private Date expirationDate;
    private String renewalStatus;
    private String transactionId;
    private Boolean autoRenew;
    private Boolean active;
}
