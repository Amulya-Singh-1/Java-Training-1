package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.LocalMessage;
import com.dgmarket.notice.entities.LocalMessagePK;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface LocalMessageRepository extends CrudRepository<LocalMessage, LocalMessagePK> {
    @Query("select m from LocalMessage m where m.id.siteId = '170028' and m.id.messageKey = concat('cpv:', :cpvCode) ")
    List<LocalMessage> getMessagesForCPVCode(@Param("cpvCode") String cpvCode);
}
