package com.dgmarket.notice.service;

import com.dgmarket.notice.dto.filters.CpvSearchFilter;
import com.dgmarket.notice.dto.response.CPVListResponse;
import com.dgmarket.notice.dto.response.CPVMasterDTO;
import com.dgmarket.notice.entities.CPVMaster;
import com.dgmarket.notice.repositories.CPVMasterRepository;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class CPVMasterService {

    private final CPVMasterRepository cpvMasterRepository;

    public List<CPVMaster> findAllCPVMaster() {
        return cpvMasterRepository.findAll();
    }

    public List<CPVMasterDTO> getCPVMasterDTOListFromCPVMasterList(List<CPVMaster> cpvMasterList) {
        List<CPVMasterDTO> cpvMasterDTOList = cpvMasterList.stream()
                .map(this::populateCPVMasterToDTO)
                .collect(Collectors.toList());
        return cpvMasterDTOList;
    }

    public CPVMasterDTO populateCPVMasterToDTO(CPVMaster cpvMaster) {
        return CPVMasterDTO.builder()
                .code(cpvMaster.getCode())
                .name(cpvMaster.getName())
                .parentCode(cpvMaster.getParentCode())
                .build();
    }

    public CPVListResponse getAllCpvsMaster(CpvSearchFilter filter) {
        Page<CPVMaster> cpvMasters = null;
        if(filter.hasKeyword())
            cpvMasters = cpvMasterRepository.findAllByNameContainingIgnoreCase(filter.getKeyword(), PageRequest.of(filter.getPage() - 1, filter.getPerPage()));

        else if(cpvMasters == null)
            cpvMasters = cpvMasterRepository.findAll(PageRequest.of(filter.getPage() - 1, filter.getPerPage()));

        CPVListResponse cpvListResponse = new CPVListResponse(
                (cpvMasters.getContent().size() == 0) ? "No CPV found!" : null,
                filter.getPage(),
                filter.getPerPage(),
                cpvMasters.getTotalElements(),
                cpvMasters.getContent()
        );
        return cpvListResponse;
    }

    public CPVMaster findById(String code) {
        return cpvMasterRepository.findById(code).orElse(null);
    }
}
