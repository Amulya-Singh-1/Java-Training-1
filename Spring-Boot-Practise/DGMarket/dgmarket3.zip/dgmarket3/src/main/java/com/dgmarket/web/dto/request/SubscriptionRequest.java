package com.dgmarket.web.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionRequest {
    @NotNull(message = "Org Id should not be null.")
    private Long orgId;
    @NotNull(message = "Product Id should not be null.")
    private Long productId;
    private Long totalGlobalNotices;
    @NotNull(message = "Remaining Global Notices should not be null.")
    private Long remainingGlobalNotices;
    @DateTimeFormat(fallbackPatterns = "yyyy-MM-dd")
    private Date expirationDate;
    private String renewalStatus;
    private String transactionId;
    @NotNull(message = "Auto Renew should not be null")
    private Boolean autoRenew;
    @NotNull(message = "Active should not be null.")
    private Boolean active;
    @DateTimeFormat(fallbackPatterns = "yyyy-MM-dd")
    @NotNull(message = "Start Date should not be null.")
    private Date startDate;
}
