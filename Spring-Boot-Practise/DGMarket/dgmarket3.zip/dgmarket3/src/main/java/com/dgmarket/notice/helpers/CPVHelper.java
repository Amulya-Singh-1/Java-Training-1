package com.dgmarket.notice.helpers;

import com.dgmarket.core.utility.NameValue;
import com.dgmarket.core.utility.StreamUtils;
import com.dgmarket.notice.entities.*;
import com.dgmarket.notice.repositories.CPVRepository;
import com.dgmarket.notice.repositories.CategoryRepository;
import com.dgmarket.notice.repositories.LocalMessageRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
@RequiredArgsConstructor
public class CPVHelper {
    private final LocalMessageRepository localMessageRepository;
    private final CategoryRepository categoryRepository;
    private final CPVRepository cpvRepository;
    private final CPVToCategoriesConverter cpvToCategoriesConverter;

    public String getCPVDisplayName(String cpvCode) {
        Optional<LocalMessage> localMessageOptional =
                localMessageRepository.findById(new LocalMessagePK("cpv:" + cpvCode, "en", "170028"));
        if (localMessageOptional.isEmpty())
            return "";
        else
            return localMessageOptional.get().getText();
    }

//    public List<Category> findCategories(Notice notice) {
//        Set<String> cpvCodes = notice.getNoticeCPVList().stream()
//                .map(NoticeCPV::getCpv)
//                .map(CPV::getCode)
//                .collect(Collectors.toSet());
//
//        return findCategories(cpvCodes);
//    }

    public List<Category> findCategories(Set<String> cpvCodes) {
        if (cpvCodes.stream().anyMatch(this::fakeCode))
            return Collections.emptyList();

        Set<Category> categoriesOfNotice = new HashSet<>();
        for (String cpvCode : cpvCodes) {
            List<Category> categoriesOfCPV = cpvToCategoriesConverter.findCategories(cpvCode);
            if (!CollectionUtils.isEmpty(categoriesOfCPV))
                categoriesOfNotice.addAll(categoriesOfCPV);
        }
        return new ArrayList<>(categoriesOfNotice);
    }

    public String commaSeparatedStringOfCategoryNames(String categoryIds) {
        return StreamUtils.commaSeparatedStringToList(categoryIds).stream()
                .map(categoryRepository::findById)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .map(Category::getCategoryName)
                .collect(Collectors.joining(", "));
    }

    /**
     * Formats CPV codes into "code: name" format.
     */
    public String commaSeparatedStringOfCPVNames(String cpvCodes) {
        if (StringUtils.isBlank(cpvCodes))
            return "";
        return Arrays.stream(cpvCodes.split(","))
                .map(cpvRepository::findByCode)
                .filter(Objects::nonNull)
                .map(cpv -> String.format("%s: %s", cpv.getCode(), cpv.displayName()))
                .collect(Collectors.joining(", "));
    }

    @Bean
    List<Category> noticeCategories() {
        return categoryRepository.findAll();
    }

    @Bean
    Map<Long, Category> noticeCategoriesAsMap() {
        return categoryRepository.findAll().stream().collect(Collectors.toMap(Category::getId, x -> x));
    }

    @Bean
    List<NameValue> noticeCategoriesForJS() {
        return categoryRepository.findAll().stream()
                .map(category -> new NameValue(category.getCategoryName(), category.getId().toString()))
                .collect(Collectors.toList());
    }

    public List<String> listOfCategoryNames(String categoryIds) {
        return StreamUtils.commaSeparatedStringToStream(categoryIds)
                .map(categoryRepository::findById)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .map(Category::getCategoryName)
                .collect(Collectors.toList());
    }

    public List<String> listOfCPVNames(String cpvCodes) {
        if (StringUtils.isBlank(cpvCodes))
            return Collections.emptyList();
        return Arrays.stream(cpvCodes.split(","))
                .map(cpvRepository::findByCode)
                .filter(Objects::nonNull)
                .map(cpv -> String.format("%s: %s", cpv.getCode(), cpv.displayName()))
                .collect(Collectors.toList());
    }

    public static String parentCPV(String cpv) {
        // Remove all 0 at the end
        while (cpv.length() > 2 && cpv.lastIndexOf("0") == cpv.length() - 1) {
            cpv = cpv.substring(0, cpv.length() - 1);
        }
        // Remove non-zero at the end
        if (cpv.length() > 2) {
            cpv = cpv.substring(0, cpv.length() - 1);
        }
        // Pad with 0
        cpv = StringUtils.rightPad(cpv, 8, '0');
        return cpv;
    }

    public static boolean isSameOrChildOfAny(String cpv, List<String> cpvsToCheckAgainst) {
        return cpvsToCheckAgainst.stream()
                .anyMatch(cpvToCheckAgainst -> cpv.startsWith(StringUtils.stripEnd(cpvToCheckAgainst, "0")));
    }

    private boolean fakeCode(String code) {
        return Objects.equals(code, "99900000") || Objects.equals(code, "99000000");
    }
}
