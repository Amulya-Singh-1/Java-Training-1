package com.dgmarket.auth.entities;

import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "user_reset_password")
@Data
@ToString(of = {"userId"})
public class ResetPassword {
    @Id
    @Column(name = "user_id")
    private Long userId;

    @Column(name = "reset_date")
    private Date resetDate;

    @Column(name = "code")
    private String code;

}

