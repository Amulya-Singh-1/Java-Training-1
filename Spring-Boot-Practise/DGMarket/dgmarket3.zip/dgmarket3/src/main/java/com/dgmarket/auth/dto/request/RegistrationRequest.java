package com.dgmarket.auth.dto.request;

import com.dgmarket.auth.entities.Role;
import com.dgmarket.auth.securities.constriant.ValidPassword;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.lang.Nullable;

import javax.persistence.Basic;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RegistrationRequest {

    @NotBlank(message = "First name is missing")
    @Size(min = 3, max = 20)
    private String firstName;

    @Basic(optional = true)
    private String lastName;

    @NotBlank(message = "Captcha should not be blank")
    private String captchaText;

    @NotBlank(message = "Organization name is missing")
    @Size(min = 3, max = 60)
    private String organizationName;

    @NotBlank(message = "Phone number is missing")
    @Size(min = 7, max = 15, message = "Phone number should be have 7-15 digits.")
    @Digits(message = "Phone Number should contain 7-15 digits only.", fraction = 0, integer = 15)
    private String phone;

    @NotBlank(message = "Email field is missing")
    @Size(max = 50)
    @Email(message = "Enter valid email id")
    private String email;

    @NotBlank(message = "Password is missing")
    @ValidPassword
    @Size(min = 8, max = 40)
    private String password;

    @NotBlank(message = "Confirm Password is missing")
    @ValidPassword
    @Size(min = 8, max = 40)
    private String confirmPassword;

    @NotBlank(message = "User Type is missing")
    @Value("BUYER")
    private String userType;

    @Nullable
    private String tendersInterestedIn;

    @Nullable
    private List<String> interestedSectors;

    private boolean termsCondition;

    private String registrationSource;

    public Role getUserRole() {
        return (userType.equalsIgnoreCase(Role.Enum.BUYER.name())) ? Role.fromEnum(Role.Enum.BUYER) : Role.fromEnum(Role.Enum.SELLER);
    }

    public boolean isBuyer(){
        return userType.equalsIgnoreCase(Role.Enum.BUYER.name());
    }

    public boolean isSeller(){
        return userType.equalsIgnoreCase(Role.Enum.SELLER.name());
    }

    public boolean isBuyerAndSellerBoth(){
        return isBuyer() && isSeller();
    }

}