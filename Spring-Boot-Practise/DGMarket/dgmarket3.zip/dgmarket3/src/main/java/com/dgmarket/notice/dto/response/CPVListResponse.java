package com.dgmarket.notice.dto.response;

import com.dgmarket.core.dto.response.BaseResponse;
import com.dgmarket.notice.entities.CPVMaster;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class CPVListResponse extends BaseResponse {

    List<CPVMaster> cpvList;

    public CPVListResponse(String _message, int _currentPage, int _perPage, long _total,
                           List<CPVMaster> _cpvList) {
        this.message = _message;
        this.currentPage = _currentPage;
        this.perPage = _perPage;
        this.total = _total;
        cpvList = _cpvList;
    }

}
