package com.dgmarket.web.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ContactUsRequest {

    @NotBlank(message = "Name should not be blank")
    @Size(min = 2, max = 60)
    private String name;

    @NotBlank(message = "Email should not be blank")
    @Size(max = 50)
    @Email(message = "Enter valid email id")
    private String email;

    @NotBlank(message = "Subject should not be blank")
    @Size(max = 120)
    private String subject;

    @NotBlank(message = "Message should not be blank")
    @Size(max = 255)
    private String message;

}
