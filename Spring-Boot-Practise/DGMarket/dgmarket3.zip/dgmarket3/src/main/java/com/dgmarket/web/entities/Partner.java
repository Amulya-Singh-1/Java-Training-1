package com.dgmarket.web.entities;

import com.dgmarket.common.entities.Country;
import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "partners")
@Data
public class Partner {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "partner_type")
    private String partnerType;

    @Column(name = "sites")
    private String sites; // Comma-separated sites on which this partner should be displayed

    @OneToOne
    @JoinColumn(name = "country_iso")
    private Country country;

    @Column(name = "url")
    private String url;

//    @Type(type = "org.hibernate.type.NumericBooleanType")
    private boolean active;
}