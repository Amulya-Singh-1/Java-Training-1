package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.NoticeDocuments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NoticeDocumentsRepository extends JpaRepository<NoticeDocuments, Long> {
    List<NoticeDocuments> findByNoticeId(Long noticeId);
}
