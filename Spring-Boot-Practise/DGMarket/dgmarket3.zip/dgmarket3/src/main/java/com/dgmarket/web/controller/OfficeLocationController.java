package com.dgmarket.web.controller;

import com.dgmarket.common.services.CountryService;
import com.dgmarket.organization.helper.OrganizationHelper;
import com.dgmarket.web.dto.request.OfficeLocationRequest;
import com.dgmarket.web.dto.request.OfficeLocationUpdateRequest;
import com.dgmarket.web.entities.OfficeLocation;
import com.dgmarket.web.services.OfficeLocationService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
@RequestMapping("/api/web/offices")
public class OfficeLocationController {
    final private OfficeLocationService officeLocationService;
    final private OrganizationHelper organizationHelper;
    final private CountryService countryService;

    @GetMapping("")
    public ResponseEntity<?> findByFilter(OfficeLocation officeLocation) {
        final Map<String, Object> body = new HashMap<>();
        List<?> list = officeLocationService.filterLocations(officeLocation);
        if (list.isEmpty()) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Not found.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", list);
        return ResponseEntity.ok(body);
    }

    @PostMapping("")
    public ResponseEntity<?> addOfficeLocation(@RequestBody @Valid OfficeLocationRequest officeLocationRequest) {
        final Map<String, Object> body = new HashMap<>();
        if (officeLocationRequest == null) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Request body should not be null.");
            return ResponseEntity.status(HttpServletResponse.SC_BAD_REQUEST).body(body);
        }
        if (organizationHelper.getOrganizationById(officeLocationRequest.getOrgId()) == null) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Organization with Id " + officeLocationRequest.getOrgId() + " does not exists.");
            return ResponseEntity.status(HttpServletResponse.SC_BAD_REQUEST).body(body);
        }
        if (!countryService.countryExists(officeLocationRequest.getCountry())) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Country with Iso " + officeLocationRequest.getCountry() + " does not exists.");
            return ResponseEntity.status(HttpServletResponse.SC_BAD_REQUEST).body(body);
        }
        try {
            officeLocationService.addOfficeLocation(officeLocationRequest);
        } catch (Exception e) {
            body.put("status", HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            body.put("message", "Location is not saved.");
            return ResponseEntity.status(HttpServletResponse.SC_INTERNAL_SERVER_ERROR).body(body);
        }

        body.put("status", HttpServletResponse.SC_CREATED);
        body.put("message", "Office Location has been saved successfully.");
        return ResponseEntity.status(HttpServletResponse.SC_CREATED).body(body);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateOfficeLocation(@RequestBody @Valid OfficeLocationUpdateRequest officeLocationUpdateRequest,@PathVariable(name = "id")Long id) {
        final Map<String, Object> body = new HashMap<>();
        if (!officeLocationService.officeLocationExists(id)) {
            body.put("status", HttpServletResponse.SC_BAD_REQUEST);
            body.put("message", "Invalid Id.");
            return ResponseEntity.status(HttpServletResponse.SC_BAD_REQUEST).body(body);
        }
        OfficeLocation officeLocation = officeLocationService.updateOfficeLocation(officeLocationUpdateRequest,id);
        if (officeLocation != null) {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "Location updated successfully.");
            return ResponseEntity.ok(body);
        }
        body.put("status", HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        body.put("message", "Location is not updated.");
        return ResponseEntity.status(HttpServletResponse.SC_INTERNAL_SERVER_ERROR).body(body);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteLocationById(@PathVariable(name = "id") Long id){
        final Map<String, Object> body = new HashMap<>();
        if(!officeLocationService.officeLocationExists(id)){
            body.put("status",HttpServletResponse.SC_BAD_REQUEST);
            body.put("message","Invalid Id, No office location found for the given Id.");
            return ResponseEntity.status(HttpServletResponse.SC_BAD_REQUEST).body(body);
        }
        officeLocationService.deleteOfficeLocation(id);
        body.put("status",HttpServletResponse.SC_OK);
        body.put("message","Office Location deleted successfully.");
        return ResponseEntity.ok(body);
    }
}
