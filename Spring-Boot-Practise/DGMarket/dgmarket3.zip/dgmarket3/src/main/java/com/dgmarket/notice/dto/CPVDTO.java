package com.dgmarket.notice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CPVDTO {
    private String name;
    private String code;
}
