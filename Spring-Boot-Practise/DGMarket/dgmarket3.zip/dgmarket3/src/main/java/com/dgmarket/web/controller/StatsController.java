package com.dgmarket.web.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/homepage")
public class StatsController {

    @GetMapping("/stats")
    public ResponseEntity<?> stateHomePage() {
        final Map<String, Object> body = new HashMap<>();
        body.put("totalTenders", "1010");
        body.put("totalRegisteredBuyer", "1470");
        body.put("totalRegisteredBidders", "2200");
        body.put("totalCountriesCovered", "30");
        return ResponseEntity.ok(body);
    }

}
