package com.dgmarket.user.services;

import com.dgmarket.user.entities.UserPreferences;
import com.dgmarket.user.enums.UserPreferenceKeys;
import com.dgmarket.user.repositories.UserPreferencesRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class UserPreferenceService {
    private final UserPreferencesRepository userPreferencesRepository;

    public void saveNewPreferenceForUser(long userId, String tendersInterestedIn, List<String> interestedSectors) {
        savePreference(userId, UserPreferenceKeys.USER_PREFS_INTERESTED_TENDERS.name(), tendersInterestedIn);
        interestedSectors.stream().forEach(value -> savePreference(userId, UserPreferenceKeys.USER_PREFS_INTERESTED_SECTORS.name(), value));
    }

    public List<String> getUserPreferenceForKey(long userId, String key) {
        List<UserPreferences> preferences = userPreferencesRepository.findAllByUserIdAndAndUserDataKey(userId, key);
        return preferences.stream().map(UserPreferences::getUserDataValue).collect(Collectors.toList());
    }

    private void savePreference(long userId, String key, String value) {
        userPreferencesRepository.save(
                UserPreferences.builder()
                        .userId(userId)
                        .userDataKey(key)
                        .userDataValue(value)
                        .build()
        );
    }
}