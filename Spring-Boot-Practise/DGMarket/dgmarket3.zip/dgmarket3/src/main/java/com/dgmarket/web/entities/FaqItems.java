package com.dgmarket.web.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@Builder
@Entity
@Table(name = "faq_items")
@AllArgsConstructor
@NoArgsConstructor
public class FaqItems {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "faq_Id")
    private Faq faq;

    @Column(name = "question")
    private String question;

    @Column(name = "answer")
    private String answer;

    @Column(name = "active")
    private boolean active;

    @Column(name = "created_time")
    private Date createdTime;

}
