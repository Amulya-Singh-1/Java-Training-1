package com.dgmarket.notice.service;

import com.dgmarket.notice.dto.request.NoticeDocumentsRequest;
import com.dgmarket.notice.dto.response.CPVListDTO;
import com.dgmarket.notice.dto.response.NoticeDocumentsDTO;
import com.dgmarket.notice.entities.CPV;
import com.dgmarket.notice.entities.NoticeDocuments;
import com.dgmarket.notice.repositories.NoticeDocumentsRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class NoticeDocumentsService {

    private final NoticeDocumentsRepository noticeDocumentsRepository;

    public void saveNoticeDocuments(NoticeDocuments noticeDocuments) {
        noticeDocumentsRepository.save(noticeDocuments);
    }

    public NoticeDocuments getNoticeDocumentsFromDTO(NoticeDocumentsRequest noticeDocumentsRequests, MultipartFile file) {
        return  NoticeDocuments.builder().
                fileName(file.getOriginalFilename()).
                noticeId(noticeDocumentsRequests.getNoticeId()).
                description(noticeDocumentsRequests.getDocumentDescription()).
                fileSize(file.getSize()).
                fileType(noticeDocumentsRequests.getDocumentType()).
                createdTime(new Date())
                .build();

    }

    public List<NoticeDocuments> findNoticeDocumentsListByNoticeId(Long noticeId) {
        return noticeDocumentsRepository.findByNoticeId(noticeId);
    }

    public NoticeDocumentsDTO propagateNoticeDocumentsDTO(NoticeDocuments noticeDocuments) {
        return NoticeDocumentsDTO.builder()
                .id(noticeDocuments.getId())
                .fileName(noticeDocuments.getFileName())
                .fileType(noticeDocuments.getFileType())
                .fileSize(noticeDocuments.getFileSize())
                .date(noticeDocuments.getCreatedTime().toString())
                .build();
    }

    public List<NoticeDocumentsDTO> getNoticeDocumentsDTOList(List<NoticeDocuments> noticeDocumentsList) {
        List<NoticeDocumentsDTO> noticeDocumentsDTOList = noticeDocumentsList.stream()
                .map(this::propagateNoticeDocumentsDTO)
                .collect(Collectors.toList());
        return noticeDocumentsDTOList;
    }

    public NoticeDocuments findNoticeDocumentById(Long documentId) {
        return noticeDocumentsRepository.findById(documentId).orElse(null);
    }

    public void deleteNoticeDocuments(NoticeDocuments noticeDocuments) {
        noticeDocumentsRepository.delete(noticeDocuments);
    }
}
