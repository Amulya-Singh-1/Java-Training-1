package com.dgmarket.web.services.noticeCountSevices;

import com.dgmarket.notice.repositories.NoticeRepository;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Date;

@AllArgsConstructor
@Service
public class NoticeCountByPeriodService {
    final private NoticeRepository noticeRepository;

    public Page<Long> countByPeriod(Date date) {
        return noticeRepository.countAllByPublishDateGreaterThan(date, Pageable.unpaged());
    }
}
