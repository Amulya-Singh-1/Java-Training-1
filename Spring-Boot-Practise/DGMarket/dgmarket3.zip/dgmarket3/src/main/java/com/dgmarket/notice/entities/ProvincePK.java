package com.dgmarket.notice.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProvincePK implements Serializable {
    @Column(name = "country_code")
    private String countryCode;

    @Column(name = "state_code")
    private String stateCode;
}
