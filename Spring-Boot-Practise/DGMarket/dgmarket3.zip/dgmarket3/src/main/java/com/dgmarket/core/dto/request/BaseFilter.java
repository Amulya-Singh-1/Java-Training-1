package com.dgmarket.core.dto.request;

import lombok.Data;

@Data
public class BaseFilter {
    int page = 0;
    int perPage = 10;
    SortBy sortBy;
    OrderBy orderBy;


    public enum SortBy{
        asc, desc
    }

    public enum OrderBy{
        id, date_created
    }
}
