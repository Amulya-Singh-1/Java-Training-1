package com.dgmarket.notice.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.persistence.Column;

@Data
@Builder
@AllArgsConstructor
public class ProcurementMethodDTO {

    private Integer id;
    private String methodName;

}
