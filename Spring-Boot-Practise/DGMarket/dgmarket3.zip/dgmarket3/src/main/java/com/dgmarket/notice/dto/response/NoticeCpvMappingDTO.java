package com.dgmarket.notice.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NoticeCpvMappingDTO {

    private Long id;
    private String name;
    private String code;
    private boolean isPrimary;

}
