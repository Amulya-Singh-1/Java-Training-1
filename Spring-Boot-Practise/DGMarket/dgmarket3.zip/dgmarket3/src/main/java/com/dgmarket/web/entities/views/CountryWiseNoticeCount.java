package com.dgmarket.web.entities.views;

import lombok.Data;
import org.hibernate.annotations.Immutable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Immutable
@Data
@Entity
@Table(name = "country_wise_notice_count")
public class CountryWiseNoticeCount {

    @Id
    private String iso;
    private String countryName;
    private Long count;
}
