package com.dgmarket.common.repositories;

import com.dgmarket.common.entities.Country;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CountryRepository extends CrudRepository<Country, String> {
    @Query("select c from Country c order by c.countryName")
    List<Country> findAllCountries();
}
