package com.dgmarket.web.services;

import com.dgmarket.web.dto.response.FaqItemsDTO;
import com.dgmarket.web.entities.FaqItems;
import com.dgmarket.web.repositories.FaqItemsRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class FaqItemsService {

    private final FaqItemsRepository faqItemsRepository;

    public List<FaqItems> findFaqItemsByFaqId(Long id) {
        return faqItemsRepository.findAllByFaq_Id(id);
    }

    public List<FaqItemsDTO> getFaqDTOListFromFaqItemsList(List<FaqItems> faqItemsList) {
        List<FaqItemsDTO> faqItemsDTOList = faqItemsList.stream()
                .map(this::populateFaqItemsToDTO)
                .collect(Collectors.toList());
        return faqItemsDTOList;
    }

    public FaqItemsDTO populateFaqItemsToDTO(FaqItems faqItems) {
        return FaqItemsDTO.builder().
                faqName(faqItems.getFaq().getName()).
                question(faqItems.getQuestion()).
                answer(faqItems.getAnswer()).
                build();
    }
}
