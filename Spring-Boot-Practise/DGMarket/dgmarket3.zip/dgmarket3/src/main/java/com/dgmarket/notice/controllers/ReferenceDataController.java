package com.dgmarket.notice.controllers;

import com.dgmarket.common.dto.response.CountryDTO;
import com.dgmarket.common.repositories.CountryRepository;
import com.dgmarket.notice.dto.CategoryDTO;
import com.dgmarket.notice.dto.filters.CpvSearchFilter;
import com.dgmarket.notice.entities.ProcurementMethods;
import com.dgmarket.notice.repositories.CategoryRepository;
import com.dgmarket.notice.service.*;
import com.dgmarket.web.services.CategoryService;
import com.dgmarket.web.services.LanguageService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
@AllArgsConstructor
public class ReferenceDataController {

    private final CategoryRepository categoryRepository;
    private final CountryRepository countryRepository;
    private final CategoryService categoryService;
    private final LanguageService languageService;
    private final CPVMasterService cpvMasterService;
    private final NoticeService noticeService;
    private final FundingAgencyService fundingAgencyService;
    private final ProcurementMethodsService procurementMethodsService;
    private final NoticeTypesService noticeTypesService;

    @GetMapping("/categories")
    public List<CategoryDTO> getCategoryList() {
        return categoryRepository.findAllByOrderByCategoryName().stream()
                .map(category -> new CategoryDTO(category.getId(), category.getCategoryName()))
                .collect(Collectors.toList());
    }

    @GetMapping("/category/topEight")
    public ResponseEntity<?> topEightSectors() {
        return ResponseEntity.ok().body(categoryService.topCategories());
    }

    @GetMapping("/noticeType")
    public ResponseEntity<?> noticeTypes() {
        final Map<String, Object> body = new HashMap<>();
        body.put("status", HttpServletResponse.SC_OK);
        body.put("noticeTypes", noticeTypesService.findAllNoticeTypes());
        return ResponseEntity.ok(body);
    }

    @GetMapping("/fundingAgencies")
    public ResponseEntity<?> fundingAgencies() {
        final Map<String, Object> body = new HashMap<>();
        body.put("status", HttpServletResponse.SC_OK);
        body.put("fundingAgencies", fundingAgencyService.findAllFundingAgencies());
        return ResponseEntity.ok(body);
    }

    @GetMapping("/currencies")
    public ResponseEntity<?> currencies() {
        final Map<String, Object> body = new HashMap<>();
        body.put("status", HttpServletResponse.SC_OK);
        body.put("currencyList", noticeService.findAllCurrencies());
        return ResponseEntity.ok(body);
    }

    @GetMapping("/procurementMethods")
    public ResponseEntity<?> getProcurementMethod() {
        final Map<String, Object> body = new HashMap<>();

        List<ProcurementMethods> procurementMethodsList = procurementMethodsService.getProcurementMethodList();
        if (!(procurementMethodsList.isEmpty())) {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("procurementMethods", procurementMethodsList);
            return ResponseEntity.ok().body(body);
        }
        body.put("status", HttpServletResponse.SC_NOT_FOUND);
        body.put("message", "Procurement Method list not found !!.");
        return ResponseEntity.badRequest().body(body);
    }

    @GetMapping("/countries")
    public List<CountryDTO> getAllCountries() {
        return countryRepository.findAllCountries().stream()
                .map(country -> new CountryDTO(country.getIso(), country.getCountryName()))
                .collect(Collectors.toList());
    }

    @GetMapping("/cpv")
    public ResponseEntity<?> cpvList(CpvSearchFilter filter) {
        return ResponseEntity.ok().body(cpvMasterService.getAllCpvsMaster(filter));
    }

    @GetMapping("/language")
    public ResponseEntity<Map<String, Object>> showAllLanguages() {
        final Map<String, Object> body = new HashMap<>();
        body.put("status", HttpServletResponse.SC_OK);
        body.put("languages", languageService.showAllLanguages());
        return ResponseEntity.ok(body);
    }

}
