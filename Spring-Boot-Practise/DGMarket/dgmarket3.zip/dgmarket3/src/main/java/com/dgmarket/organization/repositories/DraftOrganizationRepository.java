package com.dgmarket.organization.repositories;

import com.dgmarket.organization.entities.DraftOrganization;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DraftOrganizationRepository extends JpaRepository<DraftOrganization, Long> {
    Page<DraftOrganization> findAllByUserIdOrderByCreatedTimeDesc(Long userId, Pageable pageable);

    Page<DraftOrganization> findAllByUserIdAndOrgStatusOrderByCreatedTimeDesc(Long userId, int orgStatus, Pageable pageable);

    Page<DraftOrganization> findAllByOrgStatusOrderByOrganizationIdDesc(int orgStatus, Pageable pageable);
    //TODO :: should be removed?
    DraftOrganization findByUserId(Long userId);

    Boolean existsByOrgName(String orgName);
}
