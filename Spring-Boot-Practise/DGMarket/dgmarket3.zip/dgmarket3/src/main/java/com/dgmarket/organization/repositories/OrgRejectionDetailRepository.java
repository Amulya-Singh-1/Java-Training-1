package com.dgmarket.organization.repositories;

import com.dgmarket.organization.entities.OrgRejectionDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrgRejectionDetailRepository extends JpaRepository<OrgRejectionDetail,Long> {
}
