package com.dgmarket.auth.entities;

import lombok.Data;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;

@Data
public class Role {

    private Long id;

    private String name;

    @RequiredArgsConstructor
    public enum Enum {
        SuperAdmin(1),
        BUYER(2),
        SELLER(3);

        @Getter
        private final long id;

        public static Enum fromId(long id) {
            return Arrays.stream(values()).filter(anEnum -> anEnum.id == id).findFirst().orElse(null);
        }

        public static Enum fromRole(Role role) {
            return fromId(role.id);
        }
    }

    public Enum asEnum() {
        return Enum.fromRole(this);
    }

    public static Role fromEnum(Enum roleEnum) {
        if (roleEnum == null)
            return null;

        Enum re = Enum.fromId(roleEnum.id);
        Role role = new Role();
        role.setId(re.id);
        role.setName(re.name());
        return role;
    }

    public static Role fromId(long id) {
        Role role = new Role();
        role.setId(id);
        return role;
    }
}