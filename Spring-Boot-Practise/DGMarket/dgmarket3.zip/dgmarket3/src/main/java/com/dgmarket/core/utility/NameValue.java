package com.dgmarket.core.utility;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class NameValue {
    private String name;
    private String value;
}
