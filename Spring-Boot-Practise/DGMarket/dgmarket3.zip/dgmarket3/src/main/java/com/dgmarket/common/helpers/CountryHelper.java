package com.dgmarket.common.helpers;

import com.dgmarket.common.entities.Country;
import com.dgmarket.common.repositories.CountryRepository;
import com.dgmarket.core.utility.NameValue;
import com.dgmarket.notice.dto.RegionDTO;
import com.dgmarket.notice.entities.Province;
import com.dgmarket.notice.entities.ProvincePK;
import com.dgmarket.notice.repositories.ProvinceRepository;
import com.dgmarket.notice.repositories.RegionRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class CountryHelper {
    @Autowired
    private CountryRepository countryRepository;
    @Autowired
    private ProvinceRepository provinceRepository;
    @Autowired
    private RegionRepository regionRepository;

    private List<RegionDTO> regionsForSearch;
    private Map<String, RegionDTO> regionsMap;
    private Map<String, List<RegionDTO>> regionsOfCountries;

    @Bean
    public List<RegionDTO> regionsForSearch() {
        return regionsForSearch;
    }

    @Bean
    public List<Country> countriesForAssignment() {
        return countryRepository.findAllCountries()
                .stream()
                .sorted(Comparator.comparing(Country::getCountryName))
                .collect(Collectors.toList());
    }

    @Bean
    public List<NameValue> countriesWithRegionsForSearch() {
        List<NameValue> resultList = new ArrayList<>();
        resultList.addAll(regionsForSearch.stream()
                .map(region -> new NameValue(region.getDisplayName(), region.getCode()))
                .collect(Collectors.toList()));
        resultList.addAll(countryRepository.findAllCountries()
                .stream()
                .sorted(Comparator.comparing(Country::getCountryName))
                .map(country -> new NameValue(country.getCountryName(), country.getIso()))
                .collect(Collectors.toList()));
        return resultList;
    }

    public String getLocalityNames(String countryCode, String localityCodesCommaSeparated) {
        if (StringUtils.isEmpty(localityCodesCommaSeparated))
            return "";
        String localityNamesCommaSeparated = Arrays.stream(localityCodesCommaSeparated.split(","))
                .map(stateCode -> provinceRepository.findById(new ProvincePK(countryCode, stateCode)))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .map(Province::getStateName)
                .collect(Collectors.joining(", "));
        if (StringUtils.isEmpty(localityNamesCommaSeparated))
            return localityCodesCommaSeparated;
        else
            return localityNamesCommaSeparated;
    }

    @PostConstruct
    private void prepareRegions() {
        regionsForSearch = new ArrayList<>();
        regionsMap = new HashMap<>();
        regionsOfCountries = new HashMap<>();
        var regionsFromDB = regionRepository.findAllByOrderByName();
        for (var regionFromDB : regionsFromDB) {
            RegionDTO region = RegionDTO.fromRegionDB(regionFromDB);
            regionsForSearch.add(region);
            regionsMap.put(region.getCode(), region);
            for (String countryCode : regionFromDB.countriesAsList()) {
                regionsOfCountries.computeIfAbsent(countryCode, k -> new ArrayList<>()).add(region);
            }
        }
    }
}