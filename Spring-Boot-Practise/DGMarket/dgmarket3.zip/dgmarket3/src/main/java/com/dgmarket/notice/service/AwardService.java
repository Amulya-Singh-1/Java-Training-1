package com.dgmarket.notice.service;

import com.dgmarket.notice.dto.request.AwardRequest;
import com.dgmarket.notice.entities.Award;
import com.dgmarket.notice.repositories.AwardRepository;
import com.dgmarket.organization.helper.OrganizationHelper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class AwardService {
    private final AwardRepository awardRepository;
    private final OrganizationHelper organizationHelper;

    public List<Award> awards() {
        return awardRepository.findAll().stream().filter(award -> award.getStatus() == 1).collect(Collectors.toList());
    }

    public Award addAward(AwardRequest awardRequest) {
        Award award = awardRepository.save(populateAwardFromDto(awardRequest));
        log.info(award + "  is saved !!");
        return award;
    }

    public Award updateAward(Long awardId, AwardRequest awardRequest) {
        Optional<Award> optionalAward = awardRepository.findById(awardId);
        if (optionalAward.isEmpty()) {
            return null;
        }
        Award award = optionalAward.get();

//        award.setAwardDate(awardRequest.getAwardDate());
        if (awardRequest.getAddress() != null) {
            award.setAddress(awardRequest.getAddress());
        }
        if (awardRequest.getBidderName() != null) {
            award.setBidderName(awardRequest.getBidderName());
        }
        if (awardRequest.getBidRecieved() != null) {
            award.setBidRecieved(awardRequest.getBidRecieved().toString());
        }
        if (awardRequest.getContractDuration() != null) {
            award.setContractDuration(awardRequest.getContractDuration().toString());
        }
        if (awardRequest.getFinalEstimatedValue() != null) {
            award.setFinalEstimatedValue(awardRequest.getFinalEstimatedValue().toString());
        }
        if (awardRequest.getInitialEstimatedValue() != null) {
            award.setInitialEstimatedValue(awardRequest.getInitialEstimatedValue().toString());
        }
        if (awardRequest.getOrgId() != null) {
            award.setOrgId(organizationHelper.getOrganizationById(awardRequest.getOrgId()));
        }
        if (awardRequest.getStatus() != null) {
            award.setStatus(awardRequest.getStatus());
        }
        return awardRepository.save(award);
    }

    private Award populateAwardFromDto(AwardRequest awardRequest) {
        return Award.builder()
                .awardDate(awardRequest.getAwardDate())
                .address(awardRequest.getAddress())
                .bidderName(awardRequest.getBidderName())
                .bidRecieved(awardRequest.getBidRecieved().toString())
                .contractDuration(awardRequest.getContractDuration().toString())
                .finalEstimatedValue(awardRequest.getFinalEstimatedValue().toString())
                .initialEstimatedValue(awardRequest.getInitialEstimatedValue().toString())
                .orgId(organizationHelper.getOrganizationById(awardRequest.getOrgId()))
                .status(1)
                .build();
    }

    public boolean existsById(Long awardId) {
        return awardRepository.existsById(awardId);
    }

    public Award getById(Long awardId) {
        return awardRepository.findById(awardId).orElse(null);
    }

    public List<Award> getByOrgId(Long orgId) {
        return awardRepository.findAllByOrgId(organizationHelper.getOrganizationById(orgId)).stream().filter(award -> award.getStatus().equals(1)).collect(Collectors.toList());
    }
}
