package com.dgmarket.notice.dto.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@Builder
public class DetailedInformationRequest {

//    @NotNull(message = "User id should not be null")
//    private Long userId;

    @NotNull(message = "Notice id should not be blank")
    private Long noticeId;

    @NotBlank(message = "Text of notice should not be blank")
    private String textOfNotice;

    private String externalUrl;

}
