package com.dgmarket.web.controller;

import com.dgmarket.core.utility.StringUtil;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;

import static com.dgmarket.core.utility.StringUtil.generateStringWithRandaomNumbers;

@RestController
@RequestMapping("/api/captcha")
@AllArgsConstructor
public class CaptchaController {

    public static final String FILE_TYPE = "jpeg";

    @GetMapping("/")
    public void generateCaptcha(HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Cache-Control", "no-cache");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);
        response.setDateHeader("Max-Age", 0);
        if (!writeCaptchaImageToHeader(request, response, generateStringWithRandaomNumbers(6))) {
            try {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Captcha Generation Error!");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @PostMapping(value = "/")
    public ResponseEntity<String> getProfileById(@RequestParam("captchaText") String captchaText, HttpSession session) {
        String captcha = (String) session.getAttribute("CAPTCHA");
        System.out.println(captcha.equals(captchaText));
        if (StringUtils.isEmpty(captcha) || (!StringUtils.isEmpty(captcha) && !captcha.equals(captchaText))) {
            return ResponseEntity.ok("Captcha Invalid");
        } else return ResponseEntity.ok("Captcha Valid");
    }

    private boolean writeCaptchaImageToHeader(HttpServletRequest request, HttpServletResponse response, String captchaStr) {
        response.setContentType("image/jpeg");
        HttpSession session = request.getSession(true);
        session.setAttribute("CAPTCHA", captchaStr);
        try {
            OutputStream outputStream = response.getOutputStream();
            ImageIO.write(getCaptchaImage(captchaStr), FILE_TYPE, outputStream);
            outputStream.close();
        } catch (Exception ioException) {
            System.out.println("in");
            ioException.printStackTrace();
            System.out.println("out");
            return false;
        }
        return true;
    }

    private BufferedImage getCaptchaImage(String captchaStr) {
        int width = 210;
        int height = 80;
        Color bg = new Color(62, 42, 31);
        Color fg = new Color(205, 206, 128);
        Font font = new Font("Arial", Font.BOLD, 30);
        BufferedImage cpimg = new BufferedImage(width, height, BufferedImage.OPAQUE);
        Graphics g = cpimg.createGraphics();
        g.setFont(font);
        g.setColor(bg);
        g.fillRect(0, 0, width, height);
        g.setColor(fg);
        g.drawString(captchaStr, 30, 50);
        return cpimg;
    }
}
