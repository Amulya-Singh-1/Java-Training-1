package com.dgmarket.notice.entities;

import com.dgmarket.organization.entities.Organization;
import com.dgmarket.user.entities.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.*;
import java.util.Date;

@Slf4j
@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "notices")
public class Notice {
//    private static ObjectMapper jsonObjectMapper = new Jackson2ObjectMapperBuilder().build();

    @Id
    @Column(name = "notice_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "notice_no")
    private String noticeNo;// in dg2 system, we treat this as notice external source id

    @ManyToOne
    @JoinColumn(name = "notice_type")
    private NoticeTypes noticeType;

    @Column(name = "notice_title")
    private String noticeTitle;

    @Column(name = "main_language")
    private String mainLanguage;

    @Column(name = "notice_status")
    @Enumerated(EnumType.STRING)
    private NoticeStatus status;

    @Column(name = "performance_country")
    private String performanceCountry;

    @Column(name = "city")
    private String city;

    @Column(name = "est_amount")
    private Long estimatedAmount;

    @Column(name = "currency")
    private String currency;

    @Column(name = "procurement_method")
    private Integer procurementMethod;

    private String qualification;

    @Column(name = "notice_deadline")
    private Date noticeDeadline;

    @Column(name = "publish_date")
    private Date publishDate;

    @Column(name = "notice_source")
    private String noticeSource;

    @ManyToOne
    @JoinColumn(name = "creator_Id")
    private User creator;

    @ManyToOne
    @JoinColumn(name = "org_Id")
    private Organization organization;

    @Column(name = "is_publish_on_sibutu")
    private boolean isPublishOnSibutu;

    @Column(name = "document_fee")
    private String documentFee;

    @Enumerated(EnumType.STRING)
    @Column(name = "completed_steps")
    private CompletedSteps completedSteps;

}