package com.dgmarket.web.services;

import com.dgmarket.web.entities.LocaleLanguage;
import com.dgmarket.web.repositories.LangRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class LanguageService {

    private LangRepository languageRepository;

    public List<LocaleLanguage> showAllLanguages() {
        return languageRepository.findAll();
    }

    public LocaleLanguage findLocaleLanguageById(String id) {
        return languageRepository.getById(id);
    }
}
