package com.dgmarket.notice.dto;

import lombok.*;
import org.springframework.stereotype.Component;

@Component
@Data
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NoticeListItemDTO {
    private Long noticeId;
    private String noticeTitle;
    private String orgName;
    private String type;
    private Long estimatedValue;
    private String currency;
    private String country;
    private String deadline;
    private String publishedDate;
    private String language;
    private String noticeStatus;
}

