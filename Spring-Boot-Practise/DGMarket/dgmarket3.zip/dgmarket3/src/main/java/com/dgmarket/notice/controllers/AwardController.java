package com.dgmarket.notice.controllers;

import com.dgmarket.notice.dto.request.AwardRequest;
import com.dgmarket.notice.service.AwardService;
import com.dgmarket.organization.helper.OrganizationHelper;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

@AllArgsConstructor
@RestController
@RequestMapping("/api/awards")
public class AwardController {

    private final AwardService awardService;
    private final OrganizationHelper organizationHelper;

    @GetMapping("")
    public ResponseEntity<?> winners() {
        final Map<String, Object> body = new HashMap<>();
        if (awardService.awards().isEmpty()) {
            body.put("status", HttpServletResponse.SC_NO_CONTENT);
            body.put("message", "No awards exists.");
            return ResponseEntity.ok(body);
        }
        body.put("status", HttpServletResponse.SC_OK);
        body.put("response", awardService.awards());
        return ResponseEntity.ok(body);
    }

    @PostMapping("")
    public ResponseEntity<?> addWinner(@RequestBody AwardRequest awardRequest) {
        final Map<String, Object> body = new HashMap<>();
        body.put("status",HttpServletResponse.SC_CREATED);
        awardService.addAward(awardRequest);
        body.put("message","Award has been saved.");
        return ResponseEntity.ok(body);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateWinner(@PathVariable("id") Long awardId,@RequestBody AwardRequest awardRequest){
        final Map<String, Object> body = new HashMap<>();
        if(awardService.updateAward(awardId,awardRequest)==null){
            body.put("status",HttpServletResponse.SC_CONFLICT);
            body.put("message","Not a valid Id is provided");
            return ResponseEntity.status(HttpServletResponse.SC_CONFLICT).body(body);
        }
        body.put("status",HttpServletResponse.SC_OK);
        body.put("response",awardService.updateAward(awardId,awardRequest).getBidderName()+" is updated!!");
        return ResponseEntity.ok(body);
    }
    @GetMapping("/{id}")
    public ResponseEntity<?> getWinnerById(@PathVariable(name = "id")Long awardId){
        final Map<String,Object> body = new HashMap<>();
        if(!awardService.existsById(awardId)){
            body.put("status",HttpServletResponse.SC_NOT_FOUND);
            body.put("message","Award not found for the given Id.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status",HttpServletResponse.SC_OK);
        body.put("response",awardService.getById(awardId));
        return ResponseEntity.ok(body);
    }

    @GetMapping("/{id}/org")
    public ResponseEntity<?> getWinnerByOrgId(@PathVariable(name = "id")Long orgId){
        final Map<String,Object> body = new HashMap<>();
        if(awardService.getByOrgId(orgId).isEmpty() && organizationHelper.getOrganizationById(orgId)==null){
            body.put("status",HttpServletResponse.SC_NOT_FOUND);
            body.put("message","Award is not found for the given Id.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        }
        body.put("status",HttpServletResponse.SC_OK);
        body.put("response",awardService.getByOrgId(orgId));
        return ResponseEntity.ok(body);
    }
}
