package com.dgmarket.core.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "email_logs")
public class EmailLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String recipient;
    private String subject;
    private String body;
    private Date timeSent;
    @Enumerated(EnumType.STRING)
    private EmailChannel channel;
    private String messageId;
    @Enumerated(EnumType.STRING)
    private EmailType emailType;
}
