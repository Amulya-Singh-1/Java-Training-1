package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.NoticeDownloads;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NoticeDownloadsRepository extends JpaRepository<NoticeDownloads,Long> {
}
