package com.dgmarket.notice.dto.filters;

import com.dgmarket.core.dto.request.BaseFilter;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class NoticeFilter extends BaseFilter {

    String countryIso;
    String language;
    String noticeStatus;
    String noticeType;
    Long[] orgId;

    public boolean hasCountryIso() { return StringUtils.isNotEmpty((this.countryIso)); }
    public boolean hasLanguage() { return StringUtils.isNotEmpty((this.language)); }
    public boolean hasNoticeStatus() { return StringUtils.isNotEmpty((this.noticeStatus)); }
    public boolean hasNoticeType() { return StringUtils.isNotEmpty((this.noticeType)); }

    public boolean hasOrgId() {
        return orgId != null && orgId.length > 0;
    }

}
