package com.dgmarket.sibutu.repositories;

import com.dgmarket.notice.entities.Notice;
import com.dgmarket.sibutu.entities.SibutuTeam;
import com.dgmarket.user.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface SibutuTeamRepository extends JpaRepository<SibutuTeam, Long> {

    @Query("select s.id from SibutuTeam s where s.noticeId=:noticeId and s.role=:role and s.userId=:userId ")
    Optional<SibutuTeam> sibutuTeamExists(@Param("noticeId") Notice noticeId, @Param("role") SibutuTeam.Role role, @Param("userId") User userId);

}
