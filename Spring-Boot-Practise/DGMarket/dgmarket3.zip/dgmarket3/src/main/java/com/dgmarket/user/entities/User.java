package com.dgmarket.user.entities;

import com.dgmarket.user.dto.response.UserDTO;
import lombok.*;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "users",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = "email")
        })
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString(of = {"id", "email"})
public class User implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Email
    @NotBlank
    private String email;

    @NotBlank
    @Size(min = 8)
    private String password;

    @NotBlank
    private String firstName;

    private String lastName;

    private String mobile;

    private boolean active;

    private boolean emailVerified;

    private String emailVerificatonCode;

    private Date createdTime;

    private Date lastModifiedTime = new Date();

    private String registrationSource;

    public void setLastModifiedTime(){this.setLastModifiedTime(new Date());}

    public String getFullName() {
        return StringUtils.trimToEmpty(firstName) + " " + StringUtils.trimToEmpty(lastName);
    }

    public UserDTO toDTO(User user){
        return UserDTO.builder()
                .id(user.getId())
                .email(user.getEmail())
                .firstName(user.getFirstName())
                .lastName(user.getLastName())
                .mobile(user.getMobile())
                .active(user.isActive())
                .emailVerified(emailVerified)
                .registrationSource(registrationSource)
                .build();
    }
}