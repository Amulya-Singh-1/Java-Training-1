package com.dgmarket.exception;

public class SameNamedOrganizationExistsException extends Exception {
    public SameNamedOrganizationExistsException(String message) {
        super(message);
    }
}
