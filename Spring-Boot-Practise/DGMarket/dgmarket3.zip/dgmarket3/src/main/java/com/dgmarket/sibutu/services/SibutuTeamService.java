package com.dgmarket.sibutu.services;

import com.dgmarket.notice.service.NoticeService;
import com.dgmarket.sibutu.dto.request.SibutuTeamRequest;
import com.dgmarket.sibutu.dto.request.SibutuTeamUpdateRequest;
import com.dgmarket.sibutu.dto.response.SibutuResponse;
import com.dgmarket.sibutu.entities.SibutuTeam;
import com.dgmarket.sibutu.filters.SibutuTeamSearchFilter;
import com.dgmarket.sibutu.repositories.SibutuTeamRepository;
import com.dgmarket.user.services.UserService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
public class SibutuTeamService {
    private final SibutuTeamRepository sibutuTeamRepository;
    private final NoticeService noticeService;

    private final UserService userService;

    public SibutuTeam saveSibutuTeam(SibutuTeamRequest sibutuTeamRequest) {
        SibutuTeam sibutuTeam = SibutuTeam.builder()
                .noticeId(noticeService.findById(sibutuTeamRequest.getNoticeId()))
                .role(sibutuTeamRequest.getRole())
                .userId(userService.getUserById(sibutuTeamRequest.getUserId()))
                .build();
        return sibutuTeamRepository.save(sibutuTeam);
    }

    public boolean sibutuTeamExists(SibutuTeamRequest sibutuTeamRequest) {
        return sibutuTeamRepository.sibutuTeamExists(noticeService.findById(sibutuTeamRequest.getNoticeId()), sibutuTeamRequest.getRole(), userService.getUserById(sibutuTeamRequest.getUserId())).isPresent();
    }


    public void updateSibutuTeam(SibutuTeamUpdateRequest sibutuTeamUpdateRequest) {
        SibutuTeam sibutuTeam = sibutuTeamRepository.findById(sibutuTeamUpdateRequest.getId()).orElse(null);

        if (sibutuTeamUpdateRequest.getNoticeId() != sibutuTeam.getNoticeId().getId()) {
            sibutuTeam.setNoticeId(noticeService.findById(sibutuTeamUpdateRequest.getNoticeId()));
        }
        if (sibutuTeamUpdateRequest.getRole() != sibutuTeam.getRole()) {
            sibutuTeam.setRole(sibutuTeamUpdateRequest.getRole());
        }
        if (sibutuTeamUpdateRequest.getUserId() != sibutuTeam.getUserId().getId()) {
            sibutuTeam.setUserId(userService.getUserById(sibutuTeamUpdateRequest.getUserId()));
        }
        sibutuTeamRepository.save(sibutuTeam);
    }

    public boolean sibutuTeamExists(Long id) {
        return sibutuTeamRepository.existsById(id);
    }

    public List<SibutuResponse> searchByFilter(SibutuTeamSearchFilter sibutuTeamSearchFilter) {
        List<SibutuTeam> teams = sibutuTeamRepository.findAll();

        return teams.stream()
                .filter(sibutuTeam ->
                        sibutuTeam.getNoticeId().getId().equals(sibutuTeamSearchFilter.getNoticeId() == null ? sibutuTeam.getNoticeId().getId() : sibutuTeamSearchFilter.getNoticeId())
                                &&
                                sibutuTeam.getUserId().getId().equals(sibutuTeamSearchFilter.getUserId() == null ? sibutuTeam.getUserId().getId() : sibutuTeamSearchFilter.getUserId())
                                &&
                                sibutuTeam.getRole() == (sibutuTeamSearchFilter.getRole() == null ? sibutuTeam.getRole() : sibutuTeamSearchFilter.getRole())
                                &&
                                sibutuTeam.getId().equals(sibutuTeamSearchFilter.getId() == null ? sibutuTeam.getId() : sibutuTeamSearchFilter.getId()))
                .map(sibutuTeam -> new SibutuResponse(sibutuTeam.getId(), sibutuTeam.getUserId().getId(), sibutuTeam.getNoticeId().getId(), sibutuTeam.getRole().name()))
                .collect(Collectors.toList());
    }

}
