package com.dgmarket.seller.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
public class AssignmentsRequest {

    @NotNull(message = "Organization id should not be blank")
    private Long orgId;
    private String assignmentTitle;
    private String projectTitle;
    private String contractNumber;
    private String assignmentCountry;
    private String clientName;
    @DateTimeFormat(fallbackPatterns = "yyyy-MM-dd")
    private Date startDate;
    @DateTimeFormat(fallbackPatterns = "yyyy-MM-dd")
    private Date endDate;
    private String staffMonths;
    private String valueOfServices;
    private Integer fundedBy;
    private String description;

}
