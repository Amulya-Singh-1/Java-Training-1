package com.dgmarket.notice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NoticePageDTO {

    @NotNull(message = "page number should not be null and greater than 0")
    private Integer pageNo;
    @NotNull(message = "page size should not be null and greater than 0")
    private Integer pageSize;
}
