package com.dgmarket.seller.entities;

import com.dgmarket.notice.entities.FundingAgency;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name="assignments")
public class Assignments {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "org_id")
    private Long orgId;

    @Column(name = "assignment_title")
    private String assignmentTitle;

    @Column(name = "project_title")
    private String projectTitle;

    @Column(name = "contract_number")
    private String contractNumber;

    private String country;

    @Column(name = "client_name")
    private String clientName;

    @Column(name = "start_date")
    private Date startDate;

    @Column(name = "end_date")
    private Date endDate;

    @Column(name = "staff_months")
    private String staffMonths;

    @Column(name = "contract_value")
    private String contractValue;

    @ManyToOne
    @JoinColumn(name = "funding_agency")
    private FundingAgency fundingAgency;

    private String description;

}
