package com.dgmarket.auth.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.*;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ContactInformationRequest {

    @NotNull(message = "User Id should not be blank")
    private Long id;

    @NotBlank(message = "First Name should not be blank")
    @Size(min = 3, max = 20)
    private String firstName;

    private String lastName;

    @Size(max = 255)
    private String address;

    @Size(max = 60)
    private String city;

    @Size(max = 60)
    private String state;

    @Size(max = 2)
    private String country;

    @NotBlank(message = "Phone number should not be blank")
    @Size(min = 7, max = 15, message = "Phone number should be have 7-15 digits.")
    @Digits(message = "Phone Number should contain 7-15 digits only.", fraction = 0, integer = 15)
    private String phone;

    //@Size(min = 5, max = 15)
    private String fax;

    @NotBlank(message = "Email should not be blank")
    @Size(max = 50)
    @Email(message = "Enter valid email id")
    private String email;

    @Size(max = 120)
    private String website;

}
