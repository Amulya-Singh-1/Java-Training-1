package com.dgmarket.sibutu.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class SibutuResponse {

    private long id;
    private long userId;
    private long noticeId;
    private String role;
}
