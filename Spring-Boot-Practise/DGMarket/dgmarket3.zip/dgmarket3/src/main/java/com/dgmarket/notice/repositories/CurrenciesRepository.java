package com.dgmarket.notice.repositories;

import com.dgmarket.notice.entities.Currencies;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CurrenciesRepository extends JpaRepository<Currencies,String> {
    List<Currencies> findAll();
}
