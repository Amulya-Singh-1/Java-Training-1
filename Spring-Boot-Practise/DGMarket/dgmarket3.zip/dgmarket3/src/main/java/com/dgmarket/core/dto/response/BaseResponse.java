package com.dgmarket.core.dto.response;

public class BaseResponse {
    public String message;
    public int currentPage;
    public int perPage;
    public long total;
}
