package com.dgmarket.organization.dto.request;

import lombok.Builder;
import lombok.Data;
import lombok.Value;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@Builder
public class OrganizationCreateUpdateRequest {
    private Long userId;
    private Long createdBy;
    private Long roleId;
    @NotBlank(message = "organization name should not be blank")
    private String orgName;
    @Digits(fraction = 0, integer = 20)
    private String referenceNumber;
    private String countryOfOperations;
    private String defaultLanguage;
    private String orgDescription;
    private Long parentOrganizationId;
    private Integer status;
    private Boolean isBuyer;
    private Boolean isSeller;

    public Boolean getIsBuyer() {
        return (isBuyer == null) ? false : isBuyer;
    }

    public Boolean getIsSeller() {
        return (isSeller == null) ? false : isSeller;
    }

}
