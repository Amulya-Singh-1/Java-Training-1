package com.dgmarket.notice.entities;


import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "procurement_methods")
public class ProcurementMethods {

    @Id
    @Column(name = "method_id")
    private Integer id;

    @Column(name = "method_name")
    private String methodName;

}
