package com.dgmarket.core.entities;

public enum EmailChannel {
    SMTP, Amazon;

    public String getName() {
        return name();
    }
}
