package com.dgmarket.web.repositories;

import com.dgmarket.web.entities.views.TypeWiseNoticeCount;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TypeWiseNoticeCountRepository extends JpaRepository<TypeWiseNoticeCount,String> {
    List<TypeWiseNoticeCount>findAllByNameContainingIgnoreCase(String name);
}
