package com.dgmarket.notice.service;

import com.dgmarket.notice.entities.Notice;
import com.dgmarket.notice.entities.NoticeFunding;
import com.dgmarket.notice.repositories.NoticeFundingRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class NoticeFundingService {

    private final FundingAgencyService fundingAgencyService;
    private final NoticeFundingRepository noticeFundingRepository;

    public void saveFundingAgencyForNotice(Notice notice, List<String> fundingAgency) {
        if(fundingAgency.isEmpty()){
            noticeFundingRepository.save(NoticeFunding.builder()
                    .notice(notice)
                    .fundingAgency(fundingAgencyService.findFundingAgencyById(0)).build());
        } else {
            fundingAgency.stream().forEach(fundingAgencyId -> saveNoticeFunding(notice, fundingAgencyId));
        }
    }

    public void saveNoticeFunding(Notice notice, String fundingAgencyId){
        noticeFundingRepository.save(NoticeFunding.builder()
                    .notice(notice)
                    .fundingAgency(fundingAgencyService.findFundingAgencyById(Integer.parseInt(fundingAgencyId))).build());

    }

    public List<NoticeFunding> findNoticeFundingListByNoticeId(Long noticeId){
        return noticeFundingRepository.findAllByNoticeId(noticeId);
    }

}
