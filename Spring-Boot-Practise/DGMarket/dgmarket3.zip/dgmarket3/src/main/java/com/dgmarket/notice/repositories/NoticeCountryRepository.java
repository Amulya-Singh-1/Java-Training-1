package com.dgmarket.notice.repositories;

import com.dgmarket.common.entities.Country;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NoticeCountryRepository extends JpaRepository<Country,String> {
}
