package com.dgmarket.common.services;

import com.dgmarket.common.dto.response.CountryDTO;
import com.dgmarket.common.entities.Country;
import com.dgmarket.common.repositories.CountryRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class CountryService {

    private final CountryRepository countryRepository;

    public Country getCountryForId(String id) {
        return countryRepository.findById(id).get();
    }

    public CountryDTO propagateCountryDTO(Country country){
        return CountryDTO.builder()
                .iso(country.getIso())
                .countryName(country.getCountryName())
                .build();
    }

    public boolean countryExists(String iso){
        return countryRepository.existsById(iso);
    }
}