package com.dgmarket.user.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
@AllArgsConstructor
public class UserRoleResponse {
    private String userName;
    private Long roleId;
    private Long userId;
    private String userEmail;
}
