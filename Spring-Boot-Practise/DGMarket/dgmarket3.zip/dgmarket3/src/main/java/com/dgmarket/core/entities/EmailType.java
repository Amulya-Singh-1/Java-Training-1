package com.dgmarket.core.entities;

public enum EmailType {
    targeted, subscription, marketing;
}
