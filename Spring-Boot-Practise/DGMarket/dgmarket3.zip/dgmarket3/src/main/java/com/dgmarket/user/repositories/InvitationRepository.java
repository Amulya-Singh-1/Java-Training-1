package com.dgmarket.user.repositories;

import com.dgmarket.user.entities.Invitation;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface InvitationRepository extends JpaRepository<Invitation,Long> {
    Optional<Invitation> findByConfirmationCode(String code);
    boolean existsByInviteeEmail(String email);
}
