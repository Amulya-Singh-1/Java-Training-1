package com.dgmarket.notice.service;


import com.dgmarket.notice.dto.response.CPVListDTO;
import com.dgmarket.notice.entities.CPV;
import com.dgmarket.notice.repositories.CPVRepository;
import lombok.AllArgsConstructor;
import lombok.NonNull;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class CPVService {
    private final CPVRepository cpvRepository;

    public CPV findParent(@NonNull CPV cpv) {
        // No parent for two-digit CPV
        if (cpv.getMainPartLength() <= 2)
            return null;
        CPV parentCpv = cpv.getParentCPV();
        if (parentCpv == null)
            return null;
        CPV parent = cpvRepository.findByCode(parentCpv.getCode());
        return (parent != null) ? parent : findParent(parentCpv);
    }

    public List<CPV> findChildren(@NonNull CPV cpv) {
        String pattern = StringUtils.rightPad(cpv.getMainPart() + "_", 8, '0');
        return cpvRepository.findByPattern(pattern).stream()
                .filter(c -> !c.getCode().equals(cpv.getCode()))
                .collect(Collectors.toList());
    }

    public List<CPV> findSiblings(@NonNull CPV cpv) {
        return findChildren(cpv.getParentCPV()).stream()
                .filter(c -> !c.getCode().equals(cpv.getCode()))
                .collect(Collectors.toList());
    }

    public List<CPV> findAllCPV(){
        return cpvRepository.findAll();
    }

    public CPVListDTO getDTOList(CPV cpv) {
        return CPVListDTO.builder()
                .id(cpv.getId())
                .friendlyName(cpv.getFriendlyName())
                .children(cpv.getChildren())
                .code(cpv.getCode())
                .indent(cpv.getIndent())
                .build();
    }

    public List<CPVListDTO> populateCpvListToDTO(List<CPV> cpvList) {
        List<CPVListDTO> cpvListDTOList = cpvList.stream()
                    .map(this::getDTOList)
                    .collect(Collectors.toList());
        return cpvListDTOList;
    }
}