package com.dgmarket.user.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@Table(name = "roles_master")
@AllArgsConstructor
@NoArgsConstructor
/**
 * Global Admin,true
 * Admin,true
 * Editor,true
 * Viewer,true
 * */
public class RolesMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private boolean active;
}