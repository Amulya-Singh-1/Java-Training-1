package com.dgmarket.notice.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CPVMasterDTO {

    private String code;
    private String name;
    private String parentCode;

}
