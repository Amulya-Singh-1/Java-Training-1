package com.dgmarket.notice.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NoticeDocumentsDTO {

    private Long id;
    private String fileName;
    private String fileType;
    private Long fileSize;
    private String date;

}
