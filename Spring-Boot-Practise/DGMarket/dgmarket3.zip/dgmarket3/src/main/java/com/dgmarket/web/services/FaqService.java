package com.dgmarket.web.services;

import com.dgmarket.web.dto.request.SaveFaqRequest;
import com.dgmarket.web.dto.request.UpdateFAQRequest;
import com.dgmarket.web.entities.Faq;
import com.dgmarket.web.repositories.FaqRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class FaqService {

    private final FaqRepository faqRepository;

    public void updateFaqById(UpdateFAQRequest updateFaqRequest) {
    }

    public void saveFaq(SaveFaqRequest saveFaqRequest) {
    }

    public Faq findById(Long id) {
        return faqRepository.findById(id).isEmpty() ? null : faqRepository.findById(id).get();
    }

}






