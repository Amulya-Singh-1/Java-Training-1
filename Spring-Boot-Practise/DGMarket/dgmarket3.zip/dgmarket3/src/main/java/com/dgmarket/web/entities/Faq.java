


package com.dgmarket.web.entities;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name = "faq")
@Data
public class Faq {

    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY, generator = "dg_faq_id_seq")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @SequenceGenerator(name = "dg_faq_id_seq", allocationSize = 1)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "org_id")
    private Integer orgId;

    @Column(name = "active")
    private boolean active;

    @Column(name = "created_time")
    private Date createdTime;

}








