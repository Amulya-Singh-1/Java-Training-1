# AUTH Package Overview

Before starting please download this intellij idea plugin
👉🏼 [RESTKit](https://plugins.jetbrains.com/plugin/14723-restkit). This plugin automatically picks up all the
routes/api and shows within intellij Idea.

Withing intellij Idea, double press **SHIFT** quickly, then type **RESTKit** and press Enter. On this new window, click
on each route to check each API's accepted data fields

Auth package contains all the mechanism for the authentication. Controller of this package handles below routes:

* **/api/auth/signup** : Any new user needs to be registered through this route. After successful registration check
  header cookies to find the cookie named **dg3WebToken**. Any subsequent request needs to have the **dg3WebToken** in
  header for accessing any protected route. Example: user profile update, u

**Signup Request**

```
FOR BUYER
  {
         "firstName": "John",
         "lastName": "Doe",
         "captchaText": "chu chu",
         "organizationName": "dgMarket",
         "phone": "+8801711445566",
         "email": "johndoe@dgmarket.com",
         "password": "Dg@12345",
         "confirmPassword": "Dg@12345",
         "userType": "BUYER",
         "tendersInterestedIn": "road and bikes",
         "interestedSectors": [
          "Agriculture and Food"
         ],
         "termsCondition": true
    }
```

```
FOR SELLER
{
         "firstName": "John",
         "lastName": "Doe",
         "captchaText": "chu chu",
         "organizationName": "dgMarket",
         "phone": "+8801711445566",
         "email": "johndoe@dgmarket.com",
         "password": "Dg@12345",
         "confirmPassword": "Dg@12345",
         "userType": "SELLER",
         "tendersInterestedIn": "road and bikes",
         "interestedSectors": [
          "Agriculture and Food"
         ],
         "termsCondition": true
    }
```

**After Successful Registration**

```
{
    "message": "User registered successfully!",
     user": {
         "id": 10038214,
         "username": "test6 user",
         "email": "test6@dgmarket.com",
         "organizationName": "dgMarket",
         "tendersInterestedIn": "road and bikes",
         "interestedSectors": [
           "Agriculture and Food"
         ],
         "userType": [
            {
              "id": 1,
              "name": "BUYER",
              },
              {
               "id": 2,
              "name": "SELLER"
            }
       ]
     },
     "status": 201
}
```

Also check the response header.

```
request header:
HTTP/1.1 200 
Vary: Origin
Vary: Access-Control-Request-Method
Vary: Access-Control-Request-Headers
Set-Cookie: dg3WebToken=eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0M0BkZ21hcmtldC5jb20iLCJpYXQiOjE2NDk3NTY4NjksImV4cCI6MTY0OTg0MzI2OX0.2yRBfALNhs1Ty4aNsq6h9WO5o0yZBmIaTLwO2KTSDkkgS8ysZ-sELYfQ3GTq4UgvuEQA13eVnAxqTIai-G1AXQ; Path=/api; Max-Age=86400; Expires=Wed, 13 Apr 2022 09:47:49 GMT; HttpOnly
X-Content-Type-Options: nosniff
X-XSS-Protection: 1; mode=block
Cache-Control: no-cache, no-store, max-age=0, must-revalidate
Pragma: no-cache
Expires: 0
X-Frame-Options: DENY
Content-Type: application/json
Transfer-Encoding: chunked
Date: Tue, 12 Apr 2022 09:47:50 GMT
Keep-Alive: timeout=60
Connection: keep-alive
```

take a note of the ``Set-Cookie: dg3WebToken=eyJhbGciOiJIU...`` After successful registration, system automatically logs
in the user and issues a new jwt token. Use this cookie/token in any subsequent request. Add cookie in the request
header for any protected route.
``Cookie: dg3WebToken=eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ0ZXN0M0BkZ21hcmtldC5jb20iLCJpYXQiOjE2NDk3NTY4NjksImV4cCI6MTY0OTg0MzI2OX0.2yRBfALNhs1Ty4aNsq6h9WO5o0yZBmIaTLwO2KTSDkkgS8ysZ-sELYfQ3GTq4UgvuEQA13eVnAxqTIai-G1AXQ``

If appropriate cookie is not found in the header then below response will be shown

```
{
  "error": "Unauthorized",
  "message": "Full authentication is required to access this resource",
  "status": 401
}
```

**ERROR RESPONSES**

**Email Already Registered**

```
{
  "message": "Email already registered!",
  "status": 409
}
```

* **/api/auth/signin**: Before accessing any protected route, user needs to be properly signed with a valid email and
  password. Please reffer the below example

```

Login request:
{
  "email": "test3@dgmarket.com",
  "password": "123!@#Asd"
}


login okay response:
{
  "id": 10038214,
  "username": "test6 user",
  "email": "test6@dgmarket.com",
  "organizationName": "dgmarket int",
  "tendersInterestedIn": "road and bikes",
  "interestedSectors": [
    "Agriculture and Food"
  ]
  "userType": [
    {
      "id": 2,
      "name": "BUYER"
    }
  ]
}

login failed:
{
  "error": "Unauthorized",
  "message": "User with test3@dgmarket.coms not found!",
  "status": 401
}
```