package com.dgmarket.notice.entities;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "d2_provinces")
@Data
public class Province implements Serializable {
    @EmbeddedId
    private ProvincePK id;

    @Column(name = "state_name")
    private String stateName;
}
