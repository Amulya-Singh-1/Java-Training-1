package com.dgmarket.organization.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrganizationTreeResponse {
    private Long orgParentId;
    private Long id;
    private String orgName;
    private List<OrganizationTreeResponse> childOrganizations;

    public void addChildOrg(OrganizationTreeResponse child) {
        if (childOrganizations == null) childOrganizations = new ArrayList<>();
        this.childOrganizations.add(child);
    }
}
