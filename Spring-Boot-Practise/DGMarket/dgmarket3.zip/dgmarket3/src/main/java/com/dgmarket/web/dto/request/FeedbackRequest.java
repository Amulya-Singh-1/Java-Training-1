package com.dgmarket.web.dto.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FeedbackRequest {

    @NotBlank(message = "Name should not be blank")
    @Size(min = 2, max = 60)
    private String name;

    @NotBlank(message = "Email should not be blank")
    @Size(max = 50)
    @Email(message = "Enter valid email id")
    private String email;

    @NotBlank(message = "Category should not be blank")
    private String category;

    @NotBlank(message = "Sub-Category should not be blank")
    private String subCategory;

    @NotBlank(message = "Message should not be blank")
    @Size(max = 255)
    private String message;

    @NotBlank(message = "Captcha should not be blank")
    private String captchaText;

}
