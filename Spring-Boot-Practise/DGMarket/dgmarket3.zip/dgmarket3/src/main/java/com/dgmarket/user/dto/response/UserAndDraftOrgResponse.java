package com.dgmarket.user.dto.response;

import com.dgmarket.organization.entities.DraftOrganization;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserAndDraftOrgResponse {
    private String firstName;
    private String lastName;
    private String email;
    private String mobile;
    private DraftOrganization draftOrganization;
}
