package com.dgmarket.notice.dto.request;

import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@Builder
public class NoticeViewsAndDownloadRequest {

    @NotNull(message = "user Id should not be null.")
    private Long userId;
    @NotNull(message = "notice Id should not be null.")
    private Long noticeId;
}
