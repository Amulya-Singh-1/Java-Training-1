package com.dgmarket.notice.dto;

import lombok.*;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Component
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
public class TotalNoticeDTO {
    private Long totalNotices;
    private List<NoticeListItemDTO> noticeList;
}
