package com.dgmarket.organization.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "org_status_master")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrganizationStatusMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private int code;
}
