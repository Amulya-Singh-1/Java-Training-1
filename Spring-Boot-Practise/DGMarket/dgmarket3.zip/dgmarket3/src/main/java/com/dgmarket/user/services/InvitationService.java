package com.dgmarket.user.services;

import com.dgmarket.auth.dto.request.RegistrationRequest;
import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.core.config.Constants;
import com.dgmarket.core.dto.EmailRequestDTO;
import com.dgmarket.core.entities.EmailChannel;
import com.dgmarket.core.entities.EmailType;
import com.dgmarket.core.mail.MailUtility;
import com.dgmarket.organization.repositories.OrganizationRepository;
import com.dgmarket.user.dto.request.InvitationRequest;
import com.dgmarket.user.entities.Invitation;
import com.dgmarket.user.entities.User;
import com.dgmarket.user.entities.UserRoles;
import com.dgmarket.user.repositories.InvitationRepository;
import com.dgmarket.user.repositories.RolesMasterRepository;
import com.dgmarket.user.repositories.UserRoleRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.UUID;

@AllArgsConstructor
@Slf4j
@Service
public class InvitationService {


    private final InvitationRepository invitationRepository;
    private final UserRoleRepository userRoleRepository;
    private final MailUtility mailUtility;
    private final OrganizationRepository organizationRepository;
    private final RolesMasterRepository rolesMasterRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    static final String BASE_SITE_URL = "http://dg3-docker.dgmarket.com/";


    public Invitation invite(InvitationRequest invitationRequest) {

        String orgName = organizationRepository.findById(invitationRequest.getOrgId()).get().getOrgName();

        String token = UUID.randomUUID().toString();
        log.info("token generated is : " + token);
        String joinURL = BASE_SITE_URL + "/verifyInvitee?token=" + token;
        try {

            EmailRequestDTO emailRequestDTO = EmailRequestDTO.builder()
                    .toAddresses(List.of(invitationRequest.getEmail()))
                    .fromAddress(Constants.DG_DEFAULT_NOTIFICATION_EMAIL)
                    .emailType(EmailType.targeted)
                    .isHtml(false)
                    .subject("Invitation to join " + orgName)
                    .body("join " + orgName + " as " + rolesMasterRepository.findById(invitationRequest.getRoleId()).get().getName() + "\n" + " join link " + joinURL)
                    .emailChannel(EmailChannel.SMTP)
                    .build();
            mailUtility.sendEmail(emailRequestDTO);

        } catch (Exception e) {
            e.printStackTrace();
            log.info("mail not sent to " + invitationRequest.getEmail());
            return null;
        }

        Invitation invitation = Invitation.builder()
                .confirmationCode(token)
                .createdTime(new Date())
                .inviterId(userRepository.findUserById(invitationRequest.getUserId()))
                .inviteeEmail(invitationRequest.getEmail())
                .organization(organizationRepository.getById(invitationRequest.getOrgId()))
                .roleId(rolesMasterRepository.findById(invitationRequest.getRoleId()).get())
                .build();
        return invitationRepository.save(invitation);
    }


    public UserRoles verifyInvitation(String token, RegistrationRequest registrationRequest) {
        if (invitationRepository.findByConfirmationCode(token).isPresent()) {
            User user = User.builder()
                    .email(registrationRequest.getEmail())
                    .password(passwordEncoder.encode(registrationRequest.getPassword()))
                    .mobile(registrationRequest.getPhone())
                    .firstName(registrationRequest.getFirstName())
                    .lastName(registrationRequest.getLastName())
                    .emailVerified(true)
                    .active(true)
                    .lastModifiedTime(new Date())
                    .createdTime(new Date())
                    .emailVerificatonCode(token)
                    .registrationSource("Invite")
                    .build();

            user = userRepository.save(user);
            Invitation invitation = invitationRepository.findByConfirmationCode(token).get();
            return userRoleRepository.save(
                    UserRoles.builder()
                            .orgId(invitation.getOrganization().getOrgId())
                            .role(invitation.getRoleId())
                            .user(user)
                            .createdTime(new Date())
                            .build()
            );
        }
        return null;
    }
    public boolean inviteExists(String email){
        return invitationRepository.existsByInviteeEmail(email);
    }
}
