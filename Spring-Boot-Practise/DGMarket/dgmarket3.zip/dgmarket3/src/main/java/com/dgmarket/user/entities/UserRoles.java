package com.dgmarket.user.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user_roles")
public class UserRoles {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_Id")
    @JsonIgnore
    private User user;

    @OneToOne
    @JoinColumn(name = "role_Id")
    @JsonIgnore
    private RolesMaster role;

    private Long orgId;

    @Column(name = "created_time")
    private Date createdTime;
}
