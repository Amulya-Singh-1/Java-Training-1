package com.dgmarket.organization.helper;

import com.dgmarket.auth.repositories.UserRepository;
import com.dgmarket.exception.SameNamedOrganizationExistsException;
import com.dgmarket.organization.dto.filters.OrganizationFilter;
import com.dgmarket.organization.dto.request.ContactInfoDTO;
import com.dgmarket.organization.dto.request.OrganizationCreateUpdateRequest;
import com.dgmarket.organization.dto.response.OrganizationListItemDTO;
import com.dgmarket.organization.dto.response.OrganizationListResponse;
import com.dgmarket.organization.dto.response.OrganizationParents;
import com.dgmarket.organization.dto.response.OrganizationTreeResponse;
import com.dgmarket.organization.entities.Organization;
import com.dgmarket.organization.repositories.OrganizationRepository;
import com.dgmarket.user.entities.RolesMaster;
import com.dgmarket.user.entities.UserRoles;
import com.dgmarket.user.repositories.RolesMasterRepository;
import com.dgmarket.user.repositories.UserRoleRepository;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@Component
public class OrganizationHelper {
    private final OrganizationRepository organizationRepository;
    private final UserRoleRepository userRoleRepository;
    private final UserRepository userRepository;
    private final RolesMasterRepository rolesMasterRepository;

    public Organization prepareOrganization(Organization organization, OrganizationCreateUpdateRequest organizationCreateUpdateRequest) throws SameNamedOrganizationExistsException {
        if (doesOrganizationExistsWithSameName(organizationCreateUpdateRequest.getOrgName()))
            throw new SameNamedOrganizationExistsException(String.format("%s is already present in db", organizationCreateUpdateRequest.getOrgName()));
        if (StringUtils.isNotEmpty(organizationCreateUpdateRequest.getOrgName()))
            organization.setOrgName(organizationCreateUpdateRequest.getOrgName());

        if (StringUtils.isNotEmpty(organizationCreateUpdateRequest.getOrgDescription()))
            organization.setOrgDescription(organizationCreateUpdateRequest.getOrgDescription());

        if (StringUtils.isNotEmpty(organizationCreateUpdateRequest.getReferenceNumber()))
            organization.setOrgReferenceNo(organizationCreateUpdateRequest.getReferenceNumber());

        if (StringUtils.isNotEmpty(organizationCreateUpdateRequest.getCountryOfOperations()))
            organization.setCountryOperation(organizationCreateUpdateRequest.getCountryOfOperations());

        if (StringUtils.isNotEmpty(organizationCreateUpdateRequest.getDefaultLanguage()))
            organization.setOrgLanguage(organizationCreateUpdateRequest.getDefaultLanguage());

        if (organizationCreateUpdateRequest.getParentOrganizationId() != null && organizationCreateUpdateRequest.getParentOrganizationId() > 0)
            organization.setOrgParentId(organizationCreateUpdateRequest.getParentOrganizationId());

        return organization;
    }

    public OrganizationListResponse prepareOrganizationListForUserId(OrganizationFilter filter) {
        Page<UserRoles> userRoles = userRoleRepository.findAllByUserIdOrderByCreatedTimeDesc(filter.getUserId(), PageRequest.of(filter.getPage(), filter.getPerPage()));
        List<OrganizationListItemDTO> listItemDTOS = userRoles.stream().map(userRole ->
                new OrganizationListItemDTO().getDTOFromEntity(organizationRepository.findById(userRole.getOrgId()).get())
        ).collect(Collectors.toList());

        OrganizationListResponse organizationListResponse = new OrganizationListResponse(
                null,
                filter.getPage(),
                filter.getPerPage(),
                userRoles.getTotalElements(),
                listItemDTOS
        );

        return organizationListResponse;
    }

    public Organization processOrganizationContactInfo(Organization organization, ContactInfoDTO contactInfoDTO) {
        if (StringUtils.isNotEmpty(contactInfoDTO.getAddress()))
            organization.setOrgAddress(contactInfoDTO.getAddress());
        if (StringUtils.isNotEmpty(contactInfoDTO.getCity()))
            organization.setOrgCity(contactInfoDTO.getCity());
        if (StringUtils.isNotEmpty(contactInfoDTO.getState()))
            organization.setOrgState(contactInfoDTO.getState());
        if (StringUtils.isNotEmpty(contactInfoDTO.getCountry()))
            organization.setOrgCountry(contactInfoDTO.getCountry());
        if (StringUtils.isNotEmpty(contactInfoDTO.getPhone()))
            organization.setOrgPhone(contactInfoDTO.getPhone());
        if (StringUtils.isNotEmpty(contactInfoDTO.getFax()))
            organization.setOrgFax(contactInfoDTO.getFax());
        if (StringUtils.isNotEmpty(contactInfoDTO.getEmail()))
            organization.setOrgEmail(contactInfoDTO.getEmail());
        if (StringUtils.isNotEmpty(contactInfoDTO.getWebsite()))
            organization.setOrgWebsite(contactInfoDTO.getWebsite());

        organization.setLastModifiedTime(new Date());

        return organization;
    }

    public UserRoles processUserRole(Long orgId, Long userId, Long roleId) {
        UserRoles userRole = getUserRoleByUserIdAndOrgId(orgId, userId);

        if (userRole == null) {
            userRole = new UserRoles();
            userRole.setCreatedTime(new Date());
            userRole.setOrgId(orgId);
            userRole.setUser(userRepository.findById(userId).get());
            userRole.setRole(rolesMasterRepository.findById(roleId).get());
        } else {
            if (roleId != null && (roleId != userRole.getRole().getId()))
                userRole.setRole(rolesMasterRepository.findById(roleId).get());
        }
        return userRoleRepository.save(userRole);
    }

    public boolean hasIncompleteOrganization(long userId) {
        Page<UserRoles> userRoles = userRoleRepository.findAllByUserIdAndRoleIdOrderByCreatedTimeDesc(userId, 1l, PageRequest.ofSize(1));
        return userRoles.stream()
                .anyMatch(userRole -> {
                    Organization organization = organizationRepository.findById(userRole.getOrgId()).orElse(null);
                    return (organization.getOrgType() == null) || (organization.getOrgEmail() == null);
                });
    }

    //todo:: create user role service and move all user role relate stuff there
    public UserRoles getUserRoleById(long userRoleId) {
        return userRoleRepository.findById(userRoleId).orElse(null);
    }

    public boolean isIdInChildrenTree(Long parentId, Long idToLookFor) {
        if (parentId == null || idToLookFor == null)
            return false;
        OrganizationTreeResponse organizationTreeResponse = getOrganizationChildTree(parentId);
        if (organizationTreeResponse.getChildOrganizations() != null && organizationTreeResponse.getChildOrganizations().size() > 0) {
            return organizationTreeResponse.getChildOrganizations().stream().filter(otr -> (idToLookFor == otr.getId())).findAny().isPresent();
        }
        return false;
    }

    public OrganizationListItemDTO getOrganizationWithChildren(long orgId) {
        Organization organization = organizationRepository.findById(orgId).orElse(null);
        if (organization != null) {
            return processChildTree(new OrganizationListItemDTO().getDTOFromEntity(organization));
        } else {
            return null;
        }
    }

    public OrganizationTreeResponse getOrganizationChildTree(long orgId) {
        Organization organization = organizationRepository.findById(orgId).orElse(null);
        if (organization != null) {
            return processChildTree(OrganizationTreeResponse.builder().id(organization.getOrgId()).orgName(organization.getOrgName()).build());
        } else {
            return null;
        }
    }

    public OrganizationTreeResponse processChildTree(OrganizationTreeResponse parent) {
        Page<Organization> childOrganizations = organizationRepository.findAllByOrgParentId(parent.getId(), Pageable.unpaged());
        childOrganizations.forEach(organization -> {
            OrganizationTreeResponse itemDTO = OrganizationTreeResponse.builder()
                    .orgName(organization.getOrgName())
                    .orgParentId(organization.getOrgParentId())
                    .id(organization.getOrgId())
                    .build();
            processChildTree(itemDTO);
            parent.addChildOrg(itemDTO);
        });
        return parent;
    }


    public OrganizationListItemDTO processChildTree(OrganizationListItemDTO organizationListItemDTO) {
        Page<Organization> childOrganizations = organizationRepository.findAllByOrgParentId(organizationListItemDTO.getId(), Pageable.unpaged());
        childOrganizations.forEach(organization -> {
            OrganizationListItemDTO itemDTO = new OrganizationListItemDTO().getDTOFromEntity(organization);
            processChildTree(itemDTO);
            organizationListItemDTO.addChildOrg(itemDTO);
        });
        return organizationListItemDTO;
    }

    public Organization getOrganizationById(long orgId) {
        return organizationRepository.findById(orgId).orElse(null);
    }


    public boolean doesOrganizationExistsWithSameName(String name) {
        return !organizationRepository.findByOrgNameIgnoreCase(name).isEmpty();
    }

    public Boolean organizationExists(Long userId) {
        return !organizationRepository.findById(userId).isEmpty();
    }

    public UserRoles getUserRoleByUserIdAndOrgId(long orgId, long userId) {
        return userRoleRepository.findByUserIdAndOrgId(userId, orgId);
    }

    public UserRoles getUserRolesByUserId(Long userId) {
        return userRoleRepository.findAllByUserIdOrderByCreatedTimeDesc(userId).isEmpty() ? null : userRoleRepository.findAllByUserIdOrderByCreatedTimeDesc(userId).get(0);
    }

    public RolesMaster getRoleById(Long roleId) {
        return rolesMasterRepository.findById(roleId).orElse(null);
    }


    public Organization processParents(Organization child, List<OrganizationParents> parents, Long childId) {
        if (child.getOrgParentId() == null || child.getOrgParentId() == 0) {
            OrganizationParents organizationParents = OrganizationParents.builder()
                    .id(child.getOrgId())
                    .parentId(null)
                    .orgName(child.getOrgName())
                    .build();
            parents.add(organizationParents);
            return child;
        }
        processParents(getOrganizationById(child.getOrgParentId()), parents, childId);
        if (child.getOrgId() != childId) {
            OrganizationParents organizationParents = OrganizationParents.builder()
                    .id(child.getOrgId())
                    .parentId(child.getOrgParentId())
                    .orgName(child.getOrgName())
                    .build();
            parents.add(organizationParents);
        }
        return child;
    }

    public boolean hasParentOrg(Long childId) {
        Organization organization = organizationRepository.findById(childId).orElse(null);
        return organization != null && organization.getOrgParentId() != null && organization.getOrgParentId() != 0;
    }

    public Long countAllParents(Organization child) {

        return (child.getOrgParentId() == null || child.getOrgParentId() == 0) ? 0 : countAllParents(getOrganizationById(child.getOrgParentId())) + 1;
    }

    public int countAllChildren(Organization parent, int count) {
        List<Organization> list = organizationRepository.findAllByOrgParentId(parent.getOrgId(), Pageable.unpaged()).getContent();
        count += list.size();
        for (Organization organization : list) {
            count = countAllChildren(organization, count);
        }
        return count;
    }

}
