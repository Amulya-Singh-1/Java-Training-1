package com.dgmarket.organization.entities;

import com.dgmarket.user.entities.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "org_rejection_detail")
public class OrgRejectionDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
    @Column(name = "reason")
    private String reason;
    @OneToOne
    @JoinColumn(name = "org_id")
    private DraftOrganization orgId;
    @OneToOne
    @JoinColumn(name = "rejected_by")
    private User rejectedBy;
    @Column(name = "created_time")
    private Date createdTime;
}
