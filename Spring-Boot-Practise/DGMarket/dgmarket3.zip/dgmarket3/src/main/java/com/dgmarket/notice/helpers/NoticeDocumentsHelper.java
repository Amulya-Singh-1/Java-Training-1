package com.dgmarket.notice.helpers;

import com.dgmarket.core.config.Constants;
import com.dgmarket.core.utility.S3Util;
import com.dgmarket.notice.dto.request.NoticeDocumentsRequest;
import com.dgmarket.notice.entities.NoticeDocuments;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Component
public class NoticeDocumentsHelper {

    private static final Logger logger = LoggerFactory.getLogger(NoticeDocumentsHelper.class);

    public boolean noticeDocumentUpload(MultipartFile file){
        boolean uploadFileStatus = false;
        try{
            uploadFileStatus = S3Util.uploadFile(file.getOriginalFilename(), file.getInputStream());
//            Files.copy(file.getInputStream(), Paths.get(Constants.UPLOAD_DIR + File.separator + file.getOriginalFilename()), StandardCopyOption.REPLACE_EXISTING);
//            uploadFileStatus = true;
        } catch(Exception e){
            logger.error("While uploading document : {}", e.getMessage());
        }
        return uploadFileStatus;
    }

    public NoticeDocumentsRequest getNoticeDocumentRequestJson(String noticeDocumentRequestJson) {
        NoticeDocumentsRequest noticeDocumentRequest = new NoticeDocumentsRequest();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            noticeDocumentRequest = objectMapper.readValue(noticeDocumentRequestJson, NoticeDocumentsRequest.class);
        } catch (IOException err) {
            logger.error("Error occuring while converting Json into object : {}", err.getMessage());
        }
        return noticeDocumentRequest;
    }

    public boolean deleteDocumentFileFromStorage(NoticeDocuments noticeDocuments) {
        boolean result = false;
        try {
            result = S3Util.deleteFile(noticeDocuments.getFileName());
//            result = Files.deleteIfExists(Paths.get(filePath));
//            return  result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return  result;
    }

    public byte[] downloadFileFromStorage(NoticeDocuments noticeDocuments){
        try {
            byte[] bytes = S3Util.downloadFileFromS3(noticeDocuments.getFileName());
            return bytes;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public Resource getFileAsResource(String fileName) throws IOException {
        Path dirPath = Paths.get(Constants.UPLOAD_DIR + "//" + fileName);;
        if(Files.exists(dirPath))
            return new UrlResource(dirPath.toUri());

        return null;
    }

    public boolean checkFilePermittedExtensions(String originalFilename) {
        String fileExtension = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        if(fileExtension.equalsIgnoreCase("pdf") || fileExtension.equalsIgnoreCase("jpg") || fileExtension.equalsIgnoreCase("jpeg") || fileExtension.equalsIgnoreCase("png") || fileExtension.equalsIgnoreCase("xlsx")){
            return true;
        } else {
            return false;
        }
    }

}
