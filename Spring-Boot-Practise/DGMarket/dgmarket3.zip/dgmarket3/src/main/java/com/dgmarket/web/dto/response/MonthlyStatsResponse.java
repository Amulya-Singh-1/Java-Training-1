package com.dgmarket.web.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MonthlyStatsResponse {
    private String monthName;
    private Double TendersCount;
}
