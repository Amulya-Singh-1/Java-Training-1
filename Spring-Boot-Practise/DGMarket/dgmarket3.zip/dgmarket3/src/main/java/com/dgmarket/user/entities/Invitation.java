package com.dgmarket.user.entities;

import com.dgmarket.organization.entities.Organization;
import com.dgmarket.user.entities.RolesMaster;
import com.dgmarket.user.entities.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;

@Builder
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "invitation_to_register")
public class Invitation {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToOne
    @JoinColumn(name = "inviter_id")
    private User inviterId;
    @Column(name = "invitee_email")
    private String inviteeEmail;
    @Column(name = "confirmation_code")
    private String confirmationCode;
    @OneToOne
    @JoinColumn(name = "role_id")
    private RolesMaster roleId;
    @OneToOne
    @JoinColumn(name = "org_id")
    private Organization organization;
    @Column(name = "created_time")
    private Date createdTime;
}
