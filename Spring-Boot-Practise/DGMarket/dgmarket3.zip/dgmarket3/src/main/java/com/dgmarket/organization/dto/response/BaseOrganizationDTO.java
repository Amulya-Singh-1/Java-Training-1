package com.dgmarket.organization.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BaseOrganizationDTO {
    Long id;
    String orgName;
    String orgDescription;
    String orgType;
    Integer orgStatus;
    Long roleId;
    String roleName;
}
