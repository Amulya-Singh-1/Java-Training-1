package com.dgmarket.notice.dto.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NoticeSearchRequest {
    Integer pageNumber;
    Integer noticePerPage;
    String keywords;
    String tenderType;

    public Integer getNoticePerPage() {
        return (noticePerPage == null || noticePerPage == 0) ? 10 : noticePerPage;
    }

    public Integer getPageNumber() {
        return (pageNumber == null || pageNumber == 0 || pageNumber == 1) ? 1 : pageNumber;
    }
}
