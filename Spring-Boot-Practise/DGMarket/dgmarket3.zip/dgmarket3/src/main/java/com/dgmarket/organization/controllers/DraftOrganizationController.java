package com.dgmarket.organization.controllers;

import com.dgmarket.organization.dto.filters.DraftOrganizationFilter;
import com.dgmarket.organization.dto.request.DraftOrganizationCreateUpdateRequest;
import com.dgmarket.organization.dto.request.DraftRejectionDTO;
import com.dgmarket.organization.entities.DraftOrganization;
import com.dgmarket.organization.services.DraftOrganizationService;
import com.dgmarket.user.services.UserService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/organization/drafts")
@AllArgsConstructor
public class DraftOrganizationController {
    private static final Logger logger = LoggerFactory.getLogger(DraftOrganizationController.class);

    private final DraftOrganizationService draftOrganizationService;
    private final UserService userService;

    @GetMapping("")
    public ResponseEntity<?> getAllDraftOrganizationList(DraftOrganizationFilter filter) {
        return ResponseEntity.ok().body(draftOrganizationService.showAllDrafts(filter));
    }

    @GetMapping("{id}")
    public ResponseEntity<?> getDraftOrganizationDetails(@PathVariable("id") Long id) {
        final Map<String, Object> body = new HashMap<>();
        DraftOrganization draftOrganization = draftOrganizationService.findById(id);
        if (draftOrganization == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Draft Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        } else {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("draft_organization", draftOrganization);
            return ResponseEntity.ok(body);
        }
    }

    @PostMapping("")
    public ResponseEntity<?> createDraftOrganization(@Valid @RequestBody DraftOrganizationCreateUpdateRequest draftOrganizationCreateUpdateRequest) {
        final Map<String, Object> body = new HashMap<>();

        if(draftOrganizationService.draftNameExists(draftOrganizationCreateUpdateRequest.getOrgName())){
            body.put("status",HttpServletResponse.SC_CONFLICT);
            body.put("message","Organization name already exists, use a different name.");
            return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
        }
        draftOrganizationService.create(draftOrganizationCreateUpdateRequest);
        body.put("status", HttpServletResponse.SC_CREATED);
        body.put("message", "draft organization created !!");
        return ResponseEntity.ok(body);
    }

    @PutMapping("{id}")
    public ResponseEntity<?> updateDraftOrganization(@PathVariable("id") Long id, @Valid @RequestBody DraftOrganizationCreateUpdateRequest draftOrganizationCreateUpdateRequest) {
        final Map<String, Object> body = new HashMap<>();
        DraftOrganization draftOrganization = draftOrganizationService.findById(id);
        if (draftOrganization == null) {
            body.put("status", HttpServletResponse.SC_NOT_FOUND);
            body.put("message", "Draft Organization doesn't exists.");
            return ResponseEntity.status(HttpServletResponse.SC_NOT_FOUND).body(body);
        } else {
            draftOrganization = draftOrganizationService.updateDraftOrganizaton(id, draftOrganizationCreateUpdateRequest);
            if (draftOrganization != null) {
                body.put("status", HttpServletResponse.SC_OK);
                body.put("message", "Draft organization updated");
                return ResponseEntity.ok(body);
            } else {
                body.put("message", "Draft Organization update failed");
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
            }
        }
    }

    @PostMapping("/reject")
    public ResponseEntity<?> rejectDraft(@Valid @RequestBody DraftRejectionDTO draftRejectionDTO) {
        final Map<String, Object> body = new HashMap<>();

        if (!userService.isAdmin(draftRejectionDTO.getRejectedBy())) {
            body.put("status", HttpServletResponse.SC_UNAUTHORIZED);
            body.put("message", "Only Global Admin has the rights to reject a draft Organization.");
            return ResponseEntity.status(HttpServletResponse.SC_UNAUTHORIZED).body(body);
        }
        if (draftOrganizationService.isRejected(draftRejectionDTO.getOrgId())) {
            body.put("status", HttpServletResponse.SC_CONFLICT);
            body.put("message", "Organization is already rejected. ");
            return ResponseEntity.status(HttpServletResponse.SC_CONFLICT).body(body);
        }

        if (draftOrganizationService.rejectDraft(draftRejectionDTO)) {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "Draft Organization successfully rejected.");
            return ResponseEntity.ok(body);
        } else {
            body.put("status", HttpServletResponse.SC_OK);
            body.put("message", "Draft is not updated, check orgId and rejectedBy");
            return ResponseEntity.ok(body);
        }
    }
}
