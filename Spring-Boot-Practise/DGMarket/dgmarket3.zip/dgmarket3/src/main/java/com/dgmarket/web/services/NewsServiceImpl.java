package com.dgmarket.web.services;

import com.dgmarket.web.dto.NewsListDTO;
import com.dgmarket.web.dto.NewsPageDTO;
import com.dgmarket.web.dto.response.NewsListResponse;
import com.dgmarket.web.entities.News;
import com.dgmarket.web.repositories.NewsRepository;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class NewsServiceImpl implements NewsService {

    private final NewsRepository newsRepository;

    @Override
    public List<NewsListDTO> getAllNewsList() {
        List<NewsListDTO> dtoList = new ArrayList<>();
        List<News> newsList = newsRepository.findAll();
        for (News news : newsList) {
            dtoList.add(populateNewsDto(news));
        }
        return dtoList;
    }

    @Override
    public News getNewsDetailsById(long id) {
        return newsRepository.findById(id).get();
    }

    @Override
    public Page newsPage(Integer pageNo, Integer pageSize) {
        Sort sort = Sort.by("id").descending();
        Pageable pageable = PageRequest.of(pageNo - 1, pageSize, sort);
        return newsRepository.findAll(pageable);
    }

    @Override
    public NewsListDTO populateNewsDto(News news) {
        NewsListDTO newsListDto = new NewsListDTO();
        newsListDto.setNewsType(news.getNewsType());
        newsListDto.setHeadline(news.getHeadline());
        newsListDto.setText(news.getText());
        newsListDto.setSource(news.getSource());
        newsListDto.setCreateDate(news.getCreateDate());
        newsListDto.setId(news.getId());
//        newsListDto.setCountry(news.getCountry().getCountryName());
        newsListDto.setCountry(news.getCountry() != null ? news.getCountry().getCountryName() : "");
        return newsListDto;
    }

    @Override
    public Long totalNewsData() {
        return newsRepository.count();
    }

    @Override
    public NewsListResponse prepareNewsList(NewsPageDTO newsPageDTO) {
        Page<News> newsList = newsRepository.findAll(PageRequest.of(newsPageDTO.getPageNo() - 1, newsPageDTO.getPageSize()));
        return  NewsListResponse.builder()
                .currentPage(newsPageDTO.getPageNo())
                .newsList(prepareNews(newsList.toList()))
                .totalInPage(newsPageDTO.getPageSize())
                .totalNewsCount(newsList.getTotalElements())
                .build();
    }

    private List<NewsListDTO> prepareNews(List<News> newsList) {
        List<NewsListDTO> newsListDTOList  = newsList.stream()
                .map(this::populateNewsDto)
                .collect(Collectors.toList());

        return newsListDTOList;
    }

}
