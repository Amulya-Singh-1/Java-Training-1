package com.dgmarket.web.repositories;

import com.dgmarket.web.entities.views.FundingAgenciesNoticeCount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FundingAgenciesNoticeCountRepository extends JpaRepository<FundingAgenciesNoticeCount,Long> {
}
