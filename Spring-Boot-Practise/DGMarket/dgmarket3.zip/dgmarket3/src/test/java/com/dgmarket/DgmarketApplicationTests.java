package com.dgmarket;

class DgmarketApplicationTests {


	void contextLoads() {
	}

}
